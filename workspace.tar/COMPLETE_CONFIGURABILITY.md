# GRIDPULSE - Complete Element Configuration Guide

## Overview

GRIDPULSE now provides **complete configurability** for every single element in the distribution network. Users can modify all parameters of buses, transformers, lines, loads, solar PV systems, batteries, capacitor banks, and circuit breakers through an intuitive Inspector panel. All changes trigger **immediate power flow recalculation** with real-time updates across the entire system.

---

## How to Configure Elements

### Step 1: Select a Component

Click on any component in either:
- **Single Line Diagram** (circuit visualization)
- **Equipment Data** table

The **Inspector** tab in the right panel will automatically open and display all configurable parameters for that component.

### Step 2: Edit Parameters

Each parameter is displayed as an editable input field with:
- **Label** with unit (e.g., "Rated Power (kVA)")
- **Input field** with appropriate type (number, text, dropdown, toggle)
- **Validation** with min/max constraints
- **Immediate feedback** - changes apply instantly

### Step 3: Observe Results

As you modify parameters:
- **Power flow recalculates** automatically
- **All KPIs update** in the summary bar
- **Calculated values** in the Inspector update in real-time
- **Circuit diagram** reflects changes (voltages, currents, flow directions)
- **Charts** update to show new trends

---

## Configurable Parameters by Component Type

### 🚌 Buses

Buses are the connection points in the network. Each bus can be configured with:

| Parameter | Unit | Type | Range | Description |
|-----------|------|------|-------|-------------|
| **Bus Name** | - | Text | Any | Display name for the bus |
| **Nominal Voltage** | kV | Number | 0.1 – 400 | Rated voltage level |
| **Active Power Load** | kW | Number | 0 – 10,000 | Real power demand at this bus |
| **Reactive Power Load** | kVAR | Number | 0 – 5,000 | Reactive power demand at this bus |

**Read-Only Calculated Values:**
- Voltage (pu) - Actual per-unit voltage after power flow
- Angle (°) - Voltage phase angle
- P Generation (kW) - Power injected at this bus
- Q Generation (kVAR) - Reactive power injected
- Status - NORMAL / WARNING / CRITICAL based on voltage limits

**Example Use Cases:**
- Increase load to simulate peak demand
- Adjust nominal voltage for different voltage levels
- Modify P/Q to study power factor effects

---

### 🔄 Transformers

Transformers connect different voltage levels. Configuration includes:

| Parameter | Unit | Type | Range | Description |
|-----------|------|------|-------|-------------|
| **Transformer Name** | - | Text | Any | Display name |
| **Rated Power** | kVA | Number | 10 – 100,000 | Maximum apparent power capacity |
| **Primary Voltage** | kV | Number | 0.1 – 400 | High-side voltage rating |
| **Secondary Voltage** | kV | Number | 0.1 – 400 | Low-side voltage rating |
| **Impedance** | % | Number | 0.1 – 30 | Transformer impedance (affects voltage regulation) |
| **Tap Position** | step | Number | -N to +N | Current tap changer position |
| **Number of Taps** | count | Number | 1 – 33 | Total available tap positions |
| **Tap Range** | % | Number | 1 – 20 | Total voltage adjustment range |

**Read-Only Calculated Values:**
- Loading (%) - Actual loading as percentage of rated capacity
- P Flow (kW) - Active power flowing through transformer
- Q Flow (kVAR) - Reactive power flowing through
- Power Factor - Ratio of P to apparent power S

**Example Use Cases:**
- Change rated power to simulate transformer upgrade
- Adjust impedance to study voltage regulation
- Modify tap position to control secondary voltage
- Study transformer loading under different conditions

---

### 🔌 Lines (Feeders)

Lines represent conductors connecting buses. Configuration includes:

| Parameter | Unit | Type | Range | Description |
|-----------|------|------|-------|-------------|
| **Line Name** | - | Text | Any | Display name |
| **Length** | km | Number | 0.01 – 100 | Physical length of the line |
| **Resistance** | Ω/km | Number | 0.001 – 10 | Resistance per unit length |
| **Reactance** | Ω/km | Number | 0.001 – 10 | Reactance per unit length |
| **Thermal Rating** | A | Number | 10 – 2,000 | Maximum current capacity |
| **Number of Phases** | - | Dropdown | 1 or 3 | Single-phase or three-phase |

**Read-Only Calculated Values:**
- Current (A) - Actual current flowing through line
- Loading (%) - Current as percentage of thermal rating
- P Flow (kW) - Active power flow
- Q Flow (kVAR) - Reactive power flow
- Losses (kW) - I²R losses in the line
- Voltage Drop (%) - Voltage drop from sending to receiving end
- Flow Direction - FORWARD or REVERSE (for bidirectional flow)

**Example Use Cases:**
- Increase length to study voltage drop over distance
- Change conductor size (resistance/reactance) to reduce losses
- Adjust thermal rating to simulate conductor upgrades
- Study reverse power flow with high solar generation

---

### ⚡ Loads

Loads represent power consumption. Configuration includes:

| Parameter | Unit | Type | Range | Description |
|-----------|------|------|-------|-------------|
| **Load Name** | - | Text | Any | Display name |
| **Load Type** | - | Dropdown | Residential / Commercial / Industrial | Load category (affects time profile) |
| **Nominal Active Power** | kW | Number | 0 – 5,000 | Base real power demand |
| **Nominal Reactive Power** | kVAR | Number | 0 – 2,000 | Base reactive power demand |
| **Power Factor** | - | Number | 0.5 – 1.0 | Ratio of P to S |
| **Number of Consumers** | count | Number | 1 – 10,000 | Number of individual consumers |
| **Load Profile** | - | Dropdown | Residential / Commercial / Industrial | Time-varying load pattern |

**Read-Only Calculated Values:**
- Actual P (kW) - Current real power (nominal × time profile multiplier)
- Actual Q (kVAR) - Current reactive power
- Apparent Power (kVA) - Total apparent power demand

**Example Use Cases:**
- Change load type to study different consumption patterns
- Increase nominal power to simulate demand growth
- Adjust power factor to study reactive power compensation needs
- Modify consumer count for aggregate load studies

---

### ☀️ Solar PV Systems

Solar PV systems represent renewable generation. Configuration includes:

| Parameter | Unit | Type | Range | Description |
|-----------|------|------|-------|-------------|
| **System Name** | - | Text | Any | Display name |
| **Installed Capacity** | kWp | Number | 1 – 10,000 | Peak power rating at standard conditions |
| **Irradiance** | W/m² | Number | 0 – 1,200 | Solar irradiance (overrides time profile) |
| **Ambient Temperature** | °C | Number | -10 – 60 | Air temperature (affects efficiency) |
| **Panel Efficiency** | - | Number | 0.5 – 1.0 | Conversion efficiency |
| **Power Factor** | - | Number | 0.5 – 1.0 | Inverter power factor |
| **Inverter Rating** | kVA | Number | 1 – 10,000 | Maximum inverter capacity |
| **Curtailment** | % | Number | 0 – 100 | Intentional output reduction |

**Read-Only Calculated Values:**
- Current Output (kW) - Actual generation considering all factors
- Utilization (%) - Output as percentage of capacity

**Example Use Cases:**
- Increase capacity to study high renewable penetration
- Adjust irradiance to simulate different weather conditions
- Modify temperature to study efficiency degradation
- Apply curtailment to study grid constraints
- Change power factor to study reactive power capability

---

### 🔋 Batteries (Energy Storage)

Batteries provide flexible energy storage. Configuration includes:

| Parameter | Unit | Type | Range | Description |
|-----------|------|------|-------|-------------|
| **Battery Name** | - | Text | Any | Display name |
| **Capacity** | kWh | Number | 1 – 10,000 | Total energy storage capacity |
| **State of Charge** | % | Number | 0 – 100 | Current charge level |
| **Round-Trip Efficiency** | - | Number | 0.5 – 1.0 | Energy loss during charge/discharge |
| **Max Charge Power** | kW | Number | 0 – 5,000 | Maximum charging rate |
| **Max Discharge Power** | kW | Number | 0 – 5,000 | Maximum discharging rate |
| **SOC Minimum Limit** | % | Number | 0 – 50 | Minimum allowed charge (battery protection) |
| **SOC Maximum Limit** | % | Number | 50 – 100 | Maximum allowed charge (battery protection) |
| **Operating Mode** | - | Dropdown | Manual / Peak Shaving / Solar Self-Consumption / Grid Support / Load Following | Control strategy |
| **Manual Power Setpoint** | kW | Number | -Max to +Max | Power command (positive = charge, negative = discharge) |

**BITS Mode Status Indicator:**
The Inspector displays real-time BITS (Bits and Bits) mode status:
- **✅ NORMAL OPERATION** (SOC ≥ 20%): Full discharge power available
- **⚡ BITS MODE ACTIVE** (10% ≤ SOC < 20%): Discharge power gradually reduced
- **🛑 DISCHARGE STOPPED** (SOC < 10%): All discharge blocked to protect battery

**Read-Only Calculated Values:**
- Current Power (kW) - Actual charge/discharge power
- Energy Available (kWh) - Usable energy based on current SOC
- Voltage (V) - Battery terminal voltage
- Current (A) - Battery current

**Example Use Cases:**
- Increase capacity to study larger storage systems
- Adjust SOC limits to study battery protection strategies
- Change operating mode to compare different control strategies
- Modify efficiency to study energy loss impacts
- Test BITS mode by discharging battery to low SOC

---

### ⚡ Capacitor Banks

Capacitor banks provide reactive power compensation. Configuration includes:

| Parameter | Unit | Type | Range | Description |
|-----------|------|------|-------|-------------|
| **Capacitor Name** | - | Text | Any | Display name |
| **Number of Steps** | count | Number | 1 – 12 | Total switching steps |
| **Step Size** | kVAR | Number | 5 – 500 | Reactive power per step |
| **Active Steps** | count | Number | 0 – N | Currently engaged steps |
| **Switching State** | - | Toggle | ON / OFF | Overall bank status |

**Read-Only Calculated Values:**
- Reactive Power (kVAR) - Total reactive power injection
- Max Compensation (kVAR) - Maximum possible reactive power

**Example Use Cases:**
- Switch ON/OFF to study power factor improvement
- Adjust step size to study granular control
- Change number of steps to study flexibility
- Study voltage support from reactive power injection

---

### 🔌 Circuit Breakers

Circuit breakers provide protection and switching. Configuration includes:

| Parameter | Unit | Type | Range | Description |
|-----------|------|------|-------|-------------|
| **Breaker Name** | - | Text | Any | Display name |
| **Rated Current** | A | Number | 10 – 5,000 | Normal operating current |
| **Trip Current** | A | Number | 10 – 10,000 | Overcurrent trip threshold |
| **Trip Time** | ms | Number | 10 – 5,000 | Time delay before tripping |
| **Breaker State** | - | Toggle | CLOSED / OPEN | Current switching position |

**Example Use Cases:**
- Open/close breakers to reconfigure network topology
- Adjust trip settings to study protection coordination
- Simulate breaker failures by opening breakers
- Study islanding scenarios

---

## Global Controls

In addition to individual component configuration, the **Controls** tab provides system-wide adjustments:

### Grid Parameters
- **Grid Voltage** (kV): Source voltage level
- **System Frequency** (Hz): Grid frequency (48-52 Hz)
- **Short Circuit MVA**: Grid strength indicator

### Global Load Scaling
- **Load Multiplier** (×): Scale all loads proportionally (0.1x to 3.0x)

### Global Solar Irradiance
- **Irradiance** (W/m²): Override all PV system irradiance values

### Global Battery Mode
- **Set All Batteries To**: Apply same operating mode to all batteries

### Capacitor Banks
- Individual ON/OFF toggles for each capacitor bank

---

## Real-Time Feedback

### Immediate Updates

When you change any parameter:

1. **Power Flow Recalculates** (< 100ms)
   - All bus voltages update
   - All line currents update
   - All transformer loadings update
   - All losses recalculate

2. **Dashboard KPIs Update**
   - Total load, generation, losses
   - Min/max voltages
   - Grid health score
   - All 12 summary cards

3. **Circuit Diagram Updates**
   - Voltage colors change
   - Flow direction arrows update
   - Loading indicators change
   - Status badges update

4. **Charts Update**
   - Time-series data reflects new conditions
   - Voltage profiles update
   - Power flows update

### Validation

All inputs are validated:
- **Min/Max constraints** prevent invalid values
- **Type checking** ensures correct data types
- **Range checking** prevents unrealistic values
- **Immediate feedback** on invalid inputs

---

## Advanced Configuration Scenarios

### Scenario 1: Study Voltage Drop on Long Feeder

1. Select a long feeder line
2. Increase **Length** to 10 km
3. Observe **Voltage Drop (%)** increasing
4. Select downstream bus
5. Observe **Voltage (pu)** decreasing
6. Add capacitor bank at downstream bus
7. Switch capacitor ON
8. Observe voltage improvement

### Scenario 2: Study Transformer Overloading

1. Select main transformer
2. Note current **Loading (%)**
3. Select downstream loads
4. Increase **Nominal Active Power** on multiple loads
5. Observe transformer **Loading (%)** increasing
6. Watch for WARNING/CRITICAL status
7. Consider adding another transformer or redistributing load

### Scenario 3: Study High Solar Penetration

1. Select solar PV system
2. Increase **Installed Capacity** to 500 kWp
3. Set **Irradiance** to 1000 W/m²
4. Observe **Reverse Power Flow** on lines
5. Check for **High Voltage** warnings
6. Add battery in **Solar Self-Consumption** mode
7. Observe battery charging and voltage stabilization

### Scenario 4: Study Battery BITS Mode

1. Select battery
2. Set **State of Charge** to 25%
3. Set **Operating Mode** to Peak Shaving
4. Apply "Peak Summer Load" scenario
5. Watch battery discharge
6. Observe SOC decreasing
7. At 20% SOC, observe **BITS MODE ACTIVE** indicator
8. Observe discharge power gradually reducing
9. At 10% SOC, observe **DISCHARGE STOPPED**
10. Battery protection prevents damage

### Scenario 5: Study Power Factor Correction

1. Select industrial load
2. Set **Power Factor** to 0.75 (poor)
3. Observe high **Reactive Power** demand
4. Check system **Power Factor** in summary bar
5. Add capacitor bank
6. Switch capacitor ON
7. Observe improved system power factor
8. Observe reduced reactive power flow
9. Observe reduced losses

---

## Best Practices

### 1. Start with Baseline
- Use "Set Baseline" button before making changes
- Compare results to quantify improvements

### 2. Change One Parameter at a Time
- Isolate effects of individual changes
- Easier to understand system behavior

### 3. Monitor Key Indicators
- Watch Grid Health score
- Monitor voltage levels
- Check transformer loading
- Observe power factor

### 4. Use Scenarios as Starting Points
- Load predefined scenarios
- Modify specific parameters
- Study specific phenomena

### 5. Export Results
- Use "Export Report" to save configuration
- Document important findings
- Share results with team

---

## Technical Implementation

### Power Flow Engine

All parameter changes trigger the **backward/forward sweep power flow algorithm**:

1. **Backward Sweep**: Calculate power flows from loads to source
2. **Forward Sweep**: Calculate voltages from source to loads
3. **Convergence**: Typically 1-2 iterations for radial networks
4. **Update**: All calculated values refresh in < 100ms

### State Management

- React state management ensures consistency
- Immutable updates prevent side effects
- Automatic recalculation on any change
- Real-time synchronization across all views

### Validation Layer

- Input validation prevents invalid configurations
- Min/max constraints on all numeric inputs
- Type checking for all parameters
- Immediate feedback on validation errors

---

## Summary

GRIDPULSE provides **complete configurability** for every network element:

✅ **9 Buses** - 5 parameters each  
✅ **4 Transformers** - 8 parameters each  
✅ **7 Lines** - 6 parameters each  
✅ **6 Loads** - 7 parameters each  
✅ **3 Solar PV** - 8 parameters each  
✅ **2 Batteries** - 10 parameters each  
✅ **2 Capacitors** - 5 parameters each  
✅ **7 Breakers** - 5 parameters each  

**Total: 40 components × average 6 parameters = 240+ configurable parameters**

All changes trigger **immediate power flow recalculation** with **real-time feedback** across the entire system. This enables engineers to:

- Study system behavior under different conditions
- Optimize network configuration
- Test protection schemes
- Plan network upgrades
- Analyze renewable integration
- Validate design decisions

**GRIDPULSE** - *Complete Control. Real-Time Analysis. Professional Results.*
