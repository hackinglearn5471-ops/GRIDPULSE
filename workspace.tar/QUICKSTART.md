# GRIDPULSE - Quick Start Guide

## 🎯 What You Built

**GRIDPULSE** is a complete, professional-grade electrical distribution grid simulation platform with:

✅ **Real power flow calculations** (not random numbers)  
✅ **Dual visualization modes** (Network View + Circuit/SLD View)  
✅ **24-hour time-series simulation** with realistic profiles  
✅ **12 predefined engineering scenarios**  
✅ **Fault injection & protection simulation**  
✅ **AI-powered analysis** with actionable insights  
✅ **Before/after comparison** tool  
✅ **Interactive charts** (5 categories)  
✅ **Export functionality** (JSON)  
✅ **Grid health scoring** (0-100)  

---

## 📍 Where is the Circuit View?

The **Circuit View** (Single Line Diagram) is located in the **main visualization area**. 

### How to Access It:

1. Look at the **top-right corner** of the network visualization area
2. You'll see a toggle with two buttons:
   - **🗺️ Network** - Block diagram view
   - **📐 Circuit** - Single Line Diagram (SLD) view ← **THIS IS THE CIRCUIT VIEW**

3. Click **📐 Circuit** to switch to the circuit diagram

### What You'll See in Circuit View:

- **Grid Symbol** (33kV source) at the top
- **Main Transformer** (33/11kV) with dual-circle symbol
- **11kV Bus Bar** (horizontal line)
- **Three Feeders** with:
  - Circuit breaker symbols (small squares)
  - Distribution transformers (11/0.415kV)
  - Low voltage bus bars
  - Load symbols (arrows pointing down)
  - Solar PV symbols (panel icons)
  - Battery symbols (battery icons)
  - Capacitor symbols (parallel lines)
- **Animated power flow** particles
- **Voltage annotations** on each bus
- **Fault indicators** when faults are active

---

## 🚀 Quick Start

### 1. Run the Application

```bash
npm install  # Install dependencies (first time only)
npm run dev  # Start development server
```

Open your browser to **http://localhost:5173**

### 2. Explore the Interface

**Top Section:**
- Simulation controls (Play/Pause/Reset/Speed)
- Time slider (00:00 - 24:00)
- Grid health indicator

**Left Side:**
- **Dashboard** - 12 real-time KPIs
- **Network Visualization** - Toggle between Network/Circuit views
- **Charts** - 5 interactive chart categories

**Right Side:**
- **Control Panel** with 4 tabs:
  - **Inspect** - Click any component to view details
  - **Controls** - Adjust parameters
  - **Scenarios** - Load predefined scenarios
  - **Faults** - Inject and manage faults
- **AI Analysis** - Intelligent insights and recommendations

### 3. Try These Actions

#### View the Circuit Diagram
1. Click **📐 Circuit** button (top-right of visualization)
2. Observe the single line diagram with standard electrical symbols
3. Click any component to inspect it

#### Run a Scenario
1. Click **Scenarios** tab (right panel)
2. Click "Peak Summer Load" or any scenario
3. Watch the network respond in real-time
4. Observe KPI changes and AI insights

#### Inject a Fault
1. Click **Faults** tab
2. Select "Feeder 3" as target
3. Choose "Three-Phase (LLL)" fault
4. Set resistance to 0.5 Ω
5. Click **Inject Fault**
6. Watch the fault animation and protection response

#### Compare Before/After
1. Configure network to desired state
2. Click **Compare** button (header)
3. Apply a different scenario
4. View the comparison panel showing improvements

#### Simulate 24 Hours
1. Click **Play** button (simulation bar)
2. Watch the time advance
3. Observe how load, solar, and battery change throughout the day
4. Watch charts update in real-time

---

## 📊 Key Features Demonstrated

### 1. Real Power Flow
All values are calculated using actual electrical equations:
- Voltage drops: ΔV = I(R·cosφ + X·sinφ)·L
- Losses: P_loss = 3·I²·R
- Current: I = S/(√3·V)

### 2. Time-Varying Simulation
- Load profiles change throughout the day
- Solar generation follows irradiance curve
- Battery charges/discharges based on mode
- Voltage profiles update dynamically

### 3. Renewable Integration
- Solar PV with temperature derating
- Reverse power flow when solar > load
- Battery storage optimization
- Curtailment capabilities

### 4. Protection System
- Circuit breaker states
- Fault current calculations
- Automatic fault clearing
- System reconfiguration

### 5. AI Analysis
The AI analyzes actual simulation results and provides:
- Voltage violation warnings
- Overload alerts
- Loss reduction suggestions
- Power factor recommendations
- Battery optimization tips

---

## 🎨 Two Visualization Modes

### Network View (Block Diagram)
- Modern, clean interface
- Animated power flow particles
- Color-coded voltage status
- Easy to understand topology

### Circuit View (Single Line Diagram)
- Industry-standard electrical symbols
- Professional engineering representation
- Transformer dual-circle symbols
- Circuit breaker symbols
- Bus bar representations
- Suitable for technical documentation

**Toggle between them** using the buttons in the top-right of the visualization area.

---

## 📁 Project Structure

```
GRIDPULSE/
├── src/
│   ├── App.tsx                    # Main application
│   ├── components/
│   │   ├── NetworkView.tsx        # Block diagram view
│   │   ├── CircuitView.tsx        # Single line diagram view ← CIRCUIT VIEW
│   │   ├── Dashboard.tsx          # KPI dashboard
│   │   ├── Charts.tsx             # Interactive charts
│   │   ├── ControlPanel.tsx       # Parameter controls
│   │   ├── SimulationBar.tsx      # Time controls
│   │   └── AIAnalysis.tsx         # AI insights
│   └── engine/
│       ├── types.ts               # TypeScript definitions
│       ├── calculations.ts        # Power flow engine
│       ├── network.ts             # Default network model
│       ├── timeSeries.ts          # 24-hour profiles
│       └── scenarios.ts           # Predefined scenarios
├── README.md                      # Full documentation
└── package.json                   # Dependencies
```

---

## 🔧 Customization

### Modify the Default Network

Edit `src/engine/network.ts` to change:
- Number of buses
- Transformer ratings
- Line parameters
- Load sizes
- Solar capacity
- Battery size

### Add New Scenarios

Edit `src/engine/scenarios.ts` to add:
- Custom load profiles
- Special operating conditions
- Fault scenarios
- Renewable scenarios

### Adjust Time Profiles

Edit `src/engine/timeSeries.ts` to modify:
- Load shape (residential/commercial/industrial)
- Solar irradiance curve
- Temperature profile

---

## 💡 Tips

1. **Click components** in either view to inspect detailed parameters
2. **Use scenarios** to quickly see different operating conditions
3. **Compare before/after** to quantify improvements
4. **Read AI insights** for actionable recommendations
5. **Try fault injection** to see protection system behavior
6. **Adjust time** to see how the network responds to different conditions
7. **Switch views** to see both block diagram and circuit diagram

---

## 🎓 Learning Objectives

This platform demonstrates:
- Power flow analysis in distribution networks
- Voltage profile management
- Loss calculation and reduction
- Renewable energy integration challenges
- Battery storage optimization
- Protection system coordination
- Power quality issues
- Grid health assessment

---

## 📞 Need Help?

- **Full Documentation**: See `README.md`
- **Technical Details**: Power flow algorithms in `src/engine/calculations.ts`
- **Network Model**: Default network in `src/engine/network.ts`

---

**Enjoy exploring GRIDPULSE!** 🎉

The circuit view is just one click away in the top-right of the visualization area.
