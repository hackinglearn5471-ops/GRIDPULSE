// GRIDPULSE - Time Series Profiles
// Realistic 24-hour load, solar, and temperature profiles

import type { TimeSeriesPoint, SimulationState } from './types';
import { calculateSolarOutput, calculateBatteryPower, updateBatterySOC, calculateGridHealth } from './calculations';

// Residential load profile (fraction of peak)
const RESIDENTIAL_PROFILE = [
  0.35, 0.30, 0.28, 0.25, 0.25, 0.28, 0.35, 0.55, 0.70, 0.65,
  0.55, 0.50, 0.48, 0.45, 0.42, 0.45, 0.55, 0.75, 0.90, 1.00,
  0.95, 0.80, 0.60, 0.45
];

// Commercial load profile
const COMMERCIAL_PROFILE = [
  0.20, 0.18, 0.18, 0.18, 0.18, 0.20, 0.30, 0.55, 0.80, 0.95,
  1.00, 0.98, 0.95, 0.97, 1.00, 0.98, 0.90, 0.70, 0.45, 0.30,
  0.25, 0.22, 0.20, 0.20
];

// Industrial load profile
const INDUSTRIAL_PROFILE = [
  0.60, 0.58, 0.58, 0.58, 0.58, 0.60, 0.70, 0.85, 0.95, 1.00,
  1.00, 1.00, 0.95, 1.00, 1.00, 1.00, 0.95, 0.85, 0.70, 0.60,
  0.60, 0.58, 0.58, 0.60
];

// Solar irradiance profile (W/m²)
const SOLAR_PROFILE = [
  0, 0, 0, 0, 0, 10, 50, 150, 350, 550,
  720, 850, 920, 950, 900, 800, 650, 450, 250, 80,
  10, 0, 0, 0
];

// Temperature profile (°C)
const TEMPERATURE_PROFILE = [
  18, 17, 16, 16, 16, 17, 19, 22, 25, 28,
  31, 33, 35, 36, 36, 35, 33, 31, 28, 25,
  23, 21, 19, 18
];

export function getLoadProfileMultiplier(loadType: string, hour: number): number {
  const h = Math.floor(hour) % 24;
  switch (loadType) {
    case 'residential': return RESIDENTIAL_PROFILE[h];
    case 'commercial': return COMMERCIAL_PROFILE[h];
    case 'industrial': return INDUSTRIAL_PROFILE[h];
    default: return RESIDENTIAL_PROFILE[h];
  }
}

export function getSolarIrradiance(hour: number): number {
  const h = Math.floor(hour) % 24;
  return SOLAR_PROFILE[h];
}

export function getTemperature(hour: number): number {
  const h = Math.floor(hour) % 24;
  return TEMPERATURE_PROFILE[h];
}

// Generate time series data for 24 hours
export function generateTimeSeries(baseState: SimulationState): TimeSeriesPoint[] {
  const points: TimeSeriesPoint[] = [];
  
  for (let hour = 0; hour < 24; hour += 0.25) { // 15-min intervals
    const h = Math.floor(hour) % 24;
    const irradiance = getSolarIrradiance(hour);
    const temperature = getTemperature(hour);
    
    // Calculate load at this hour
    let totalLoadP = 0;
    baseState.loads.forEach(load => {
      const multiplier = getLoadProfileMultiplier(load.profileType, hour);
      totalLoadP += load.pNominal * multiplier;
    });
    
    // Calculate solar generation
    let totalSolarGen = 0;
    baseState.solarPV.forEach(pv => {
      const tempCoeff = -0.004;
      const tempDerating = 1 + tempCoeff * (temperature - 25);
      const irrFactor = irradiance / 1000;
      let output = pv.capacity * irrFactor * tempDerating * pv.efficiency;
      output = Math.min(output, pv.inverterRating * pv.powerFactor);
      totalSolarGen += Math.max(0, output);
    });
    
    // Battery power (simplified)
    const netLoad = totalLoadP - totalSolarGen;
    let batteryPower = 0;
    baseState.batteries.forEach(bat => {
      if (bat.mode === 'PEAK_SHAVING') {
        if (netLoad > 500) batteryPower -= Math.min(bat.maxDischargePower, (netLoad - 500) * 0.4);
        else if (netLoad < 200) batteryPower += Math.min(bat.maxChargePower, 80);
      } else if (bat.mode === 'SOLAR_SELF_CONSUMPTION') {
        if (totalSolarGen > totalLoadP) batteryPower += Math.min(bat.maxChargePower, (totalSolarGen - totalLoadP) * 0.6);
        else batteryPower -= Math.min(bat.maxDischargePower, (totalLoadP - totalSolarGen) * 0.3);
      }
    });
    
    // Grid import/export
    const gridFlow = totalLoadP - totalSolarGen - batteryPower;
    const gridImport = gridFlow > 0 ? gridFlow : 0;
    const gridExport = gridFlow < 0 ? Math.abs(gridFlow) : 0;
    
    // Losses (simplified: proportional to I²)
    const losses = Math.max(5, gridImport * 0.03 + 10);
    
    // Voltage (simplified)
    const loading = gridImport / 2000;
    const minVoltage = Math.max(0.90, 1.0 - loading * 0.08);
    const maxVoltage = Math.min(1.10, 1.0 + (totalSolarGen > totalLoadP ? 0.03 : 0));
    
    // Transformer loading
    const txLoading = Math.min(120, (gridImport / 10000) * 100 + 20);
    
    // Power factor
    const pf = 0.92 + (irradiance > 200 ? 0.03 : 0);
    
    // Grid health
    let health = 100;
    if (minVoltage < 0.95) health -= (0.95 - minVoltage) * 200;
    if (txLoading > 80) health -= (txLoading - 80) * 0.5;
    if (losses > 50) health -= 5;
    health = Math.max(0, Math.min(100, health));
    
    // Battery SOC (simplified tracking)
    const batSOC = baseState.batteries.length > 0 ? 
      Math.max(10, Math.min(90, 50 + batteryPower * 0.1)) : 50;
    
    const timeStr = `${String(Math.floor(hour)).padStart(2, '0')}:${String(Math.round((hour % 1) * 60)).padStart(2, '0')}`;
    
    points.push({
      time: timeStr,
      hour,
      totalLoadP: Math.round(totalLoadP),
      totalGenP: Math.round(totalSolarGen),
      solarGen: Math.round(totalSolarGen),
      batteryPower: Math.round(batteryPower),
      gridImport: Math.round(gridImport),
      gridExport: Math.round(gridExport),
      losses: Math.round(losses),
      minVoltage: Math.round(minVoltage * 1000) / 1000,
      maxVoltage: Math.round(maxVoltage * 1000) / 1000,
      transformerLoading: Math.round(txLoading),
      powerFactor: Math.round(pf * 100) / 100,
      gridHealth: Math.round(health),
      batterySOC: Math.round(batSOC)
    });
  }
  
  return points;
}

// Get current hour's load multiplier for a specific load type
export function getCurrentLoadMultiplier(loadType: string, hour: number): number {
  return getLoadProfileMultiplier(loadType, hour);
}
