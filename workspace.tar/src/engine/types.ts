// GRIDPULSE - Core Type Definitions

export type ComponentStatus = 'NORMAL' | 'WARNING' | 'CRITICAL' | 'OFFLINE' | 'FAULT';
export type VoltageStatus = 'LOW' | 'NORMAL' | 'HIGH' | 'CRITICAL_LOW' | 'CRITICAL_HIGH';
export type FlowDirection = 'FORWARD' | 'REVERSE' | 'NONE';
export type BatteryMode = 'MANUAL' | 'LOAD_FOLLOWING' | 'PEAK_SHAVING' | 'SOLAR_SELF_CONSUMPTION' | 'GRID_SUPPORT';
export type LoadType = 'RESIDENTIAL' | 'COMMERCIAL' | 'INDUSTRIAL';
export type FaultType = 'SLG' | 'LL' | 'DLG' | 'LLL' | 'HIF';
export type ProtectionState = 'CLOSED' | 'OPEN' | 'TRIPPED';

export interface Bus {
  id: string;
  name: string;
  voltage: number; // kV nominal
  voltagePU: number; // per unit
  voltageAngle: number; // degrees
  voltageStatus: VoltageStatus;
  pLoad: number; // kW
  qLoad: number; // kVAR
  pGen: number; // kW generation
  qGen: number; // kVAR generation
  x: number;
  y: number;
  type: 'source' | 'distribution' | 'load' | 'generation';
}

export interface Transformer {
  id: string;
  name: string;
  ratedPower: number; // kVA
  primaryVoltage: number; // kV
  secondaryVoltage: number; // kV
  impedance: number; // %
  tapPosition: number;
  numTaps: number;
  tapRange: number; // +/- %
  loading: number; // %
  currentP: number; // kW
  currentQ: number; // kVAR
  powerFactor: number;
  status: ComponentStatus;
  fromBus: string;
  toBus: string;
  x: number;
  y: number;
}

export interface Line {
  id: string;
  name: string;
  fromBus: string;
  toBus: string;
  length: number; // km
  resistance: number; // ohm/km
  reactance: number; // ohm/km
  thermalRating: number; // A
  current: number; // A
  loading: number; // %
  pFlow: number; // kW
  qFlow: number; // kVAR
  losses: number; // kW
  voltageDrop: number; // %
  flowDirection: FlowDirection;
  status: ComponentStatus;
  phases: number;
}

export interface Load {
  id: string;
  name: string;
  busId: string;
  type: LoadType;
  pNominal: number; // kW
  qNominal: number; // kVAR
  pActual: number; // kW
  qActual: number; // kVAR
  powerFactor: number;
  numConsumers: number;
  profileType: string;
  status: ComponentStatus;
}

export interface SolarPV {
  id: string;
  name: string;
  busId: string;
  capacity: number; // kWp
  irradiance: number; // W/m² (0-1000)
  temperature: number; // °C
  efficiency: number;
  powerFactor: number;
  currentOutput: number; // kW
  inverterRating: number; // kVA
  curtailment: number; // %
  status: ComponentStatus;
}

export interface Battery {
  id: string;
  name: string;
  busId: string;
  capacity: number; // kWh
  soc: number; // %
  maxChargePower: number; // kW
  maxDischargePower: number; // kW
  efficiency: number;
  currentPower: number; // kW (+charge, -discharge)
  mode: BatteryMode;
  socMin: number;
  socMax: number;
  voltage: number;
  current: number;
  status: ComponentStatus;
}

export interface CapacitorBank {
  id: string;
  name: string;
  busId: string;
  numSteps: number;
  stepSize: number; // kVAR
  activeSteps: number;
  totalQ: number; // kVAR
  switchedOn: boolean;
  status: ComponentStatus;
}

export interface CircuitBreaker {
  id: string;
  name: string;
  lineId: string;
  state: ProtectionState;
  ratedCurrent: number; // A
  tripCurrent: number; // A
  tripTime: number; // ms
}

export interface Fault {
  id: string;
  componentId: string;
  componentType: 'bus' | 'line' | 'transformer';
  faultType: FaultType;
  faultResistance: number; // ohm
  duration: number; // ms
  active: boolean;
  faultCurrent: number; // A
  startTime: number;
}

export interface SimulationState {
  buses: Bus[];
  transformers: Transformer[];
  lines: Line[];
  loads: Load[];
  solarPV: SolarPV[];
  batteries: Battery[];
  capacitors: CapacitorBank[];
  breakers: CircuitBreaker[];
  faults: Fault[];
  totalLoadP: number;
  totalLoadQ: number;
  totalGenP: number;
  totalGenQ: number;
  totalLossesP: number;
  totalLossesQ: number;
  gridImport: number;
  gridExport: number;
  minVoltage: number;
  maxVoltage: number;
  systemFrequency: number;
  powerFactor: number;
  gridHealth: number;
  converged: boolean;
  solverMessage: string;
}

export interface TimeSeriesPoint {
  time: string;
  hour: number;
  totalLoadP: number;
  totalGenP: number;
  solarGen: number;
  batteryPower: number;
  gridImport: number;
  gridExport: number;
  losses: number;
  minVoltage: number;
  maxVoltage: number;
  transformerLoading: number;
  powerFactor: number;
  gridHealth: number;
  batterySOC: number;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  icon: string;
  loadMultiplier: number;
  solarMultiplier: number;
  batteryEnabled: boolean;
  capacitorEnabled: boolean;
  faultActive: boolean;
  faultConfig?: Partial<Fault>;
  timeHour: number;
}

export interface SimulationConfig {
  gridVoltage: number; // kV
  gridFrequency: number; // Hz
  gridShortCircuitMVA: number;
  simulationSpeed: number;
  currentTime: number; // hours (0-24)
  isRunning: boolean;
  selectedComponent: string | null;
  selectedComponentType: string | null;
}
