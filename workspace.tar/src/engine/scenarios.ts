// GRIDPULSE - Predefined Scenarios

import type { Scenario, SimulationState, Bus, Load, SolarPV, Battery } from './types';

export const SCENARIOS: Scenario[] = [
  {
    id: 'normal', name: 'Normal Grid Operation', description: 'Standard daytime operation with moderate load and solar generation',
    icon: '⚡', loadMultiplier: 1.0, solarMultiplier: 1.0, batteryEnabled: true, capacitorEnabled: true, faultActive: false, timeHour: 12
  },
  {
    id: 'peak_summer', name: 'Peak Summer Load', description: 'Hot summer afternoon with maximum AC demand and high solar',
    icon: '☀️', loadMultiplier: 1.4, solarMultiplier: 1.2, batteryEnabled: true, capacitorEnabled: true, faultActive: false, timeHour: 15
  },
  {
    id: 'high_solar', name: 'High Solar Generation', description: 'Maximum solar output exceeding local demand - reverse power flow',
    icon: '🌞', loadMultiplier: 0.5, solarMultiplier: 1.5, batteryEnabled: true, capacitorEnabled: true, faultActive: false, timeHour: 12
  },
  {
    id: 'solar_battery', name: 'Solar + Battery Dispatch', description: 'Solar generation with battery peak shaving active',
    icon: '🔋', loadMultiplier: 1.0, solarMultiplier: 1.0, batteryEnabled: true, capacitorEnabled: true, faultActive: false, timeHour: 18
  },
  {
    id: 'transformer_overload', name: 'Transformer Overload', description: 'Heavy loading causing transformer to exceed rated capacity',
    icon: '🔥', loadMultiplier: 1.8, solarMultiplier: 0.3, batteryEnabled: false, capacitorEnabled: true, faultActive: false, timeHour: 19
  },
  {
    id: 'feeder_fault', name: 'Feeder Fault', description: 'Three-phase fault on Feeder 3',
    icon: '⚠️', loadMultiplier: 1.0, solarMultiplier: 0.8, batteryEnabled: true, capacitorEnabled: true, faultActive: true, timeHour: 14
  },
  {
    id: 'voltage_drop', name: 'Voltage Drop', description: 'Long feeder with heavy load causing low voltage at end',
    icon: '📉', loadMultiplier: 1.5, solarMultiplier: 0.2, batteryEnabled: false, capacitorEnabled: false, faultActive: false, timeHour: 20
  },
  {
    id: 'reverse_flow', name: 'Reverse Power Flow', description: 'Solar generation exceeds demand, power flows back to grid',
    icon: '↩️', loadMultiplier: 0.3, solarMultiplier: 1.8, batteryEnabled: false, capacitorEnabled: true, faultActive: false, timeHour: 11
  },
  {
    id: 'capacitor_comp', name: 'Capacitor Compensation', description: 'Capacitor banks improving power factor and voltage',
    icon: '🔧', loadMultiplier: 1.2, solarMultiplier: 0.5, batteryEnabled: false, capacitorEnabled: true, faultActive: false, timeHour: 16
  },
  {
    id: 'ev_charging', name: 'EV Charging Surge', description: 'Evening EV charging causing demand spike',
    icon: '🚗', loadMultiplier: 1.6, solarMultiplier: 0.0, batteryEnabled: true, capacitorEnabled: true, faultActive: false, timeHour: 19
  },
  {
    id: 'night_base', name: 'Night Base Load', description: 'Late night minimal load conditions',
    icon: '🌙', loadMultiplier: 0.3, solarMultiplier: 0.0, batteryEnabled: true, capacitorEnabled: true, faultActive: false, timeHour: 2
  },
  {
    id: 'morning_ramp', name: 'Morning Ramp Up', description: 'Morning demand increase as commercial activity starts',
    icon: '🌅', loadMultiplier: 0.7, solarMultiplier: 0.4, batteryEnabled: true, capacitorEnabled: true, faultActive: false, timeHour: 8
  }
];

export function applyScenario(state: SimulationState, scenario: Scenario): SimulationState {
  const newState = JSON.parse(JSON.stringify(state)) as SimulationState;
  
  // Apply load multiplier
  newState.loads = newState.loads.map(load => ({
    ...load,
    pActual: load.pNominal * scenario.loadMultiplier,
    qActual: load.qNominal * scenario.loadMultiplier,
    pLoad: load.pNominal * scenario.loadMultiplier,
    qLoad: load.qNominal * scenario.loadMultiplier
  }));
  
  // Update bus loads based on connected loads
  newState.buses = newState.buses.map(bus => {
    const busLoads = newState.loads.filter(l => l.busId === bus.id);
    const totalP = busLoads.reduce((sum, l) => sum + l.pActual, 0);
    const totalQ = busLoads.reduce((sum, l) => sum + l.qActual, 0);
    return { ...bus, pLoad: totalP, qLoad: totalQ };
  });
  
  // Apply solar multiplier
  newState.solarPV = newState.solarPV.map(pv => ({
    ...pv,
    irradiance: Math.min(1000, pv.irradiance * scenario.solarMultiplier)
  }));
  
  // Battery state
  if (!scenario.batteryEnabled) {
    newState.batteries = newState.batteries.map(bat => ({
      ...bat, currentPower: 0, status: 'OFFLINE' as const
    }));
  }
  
  // Capacitor state
  if (!scenario.capacitorEnabled) {
    newState.capacitors = newState.capacitors.map(cap => ({
      ...cap, switchedOn: false, totalQ: 0
    }));
  }
  
  // Fault injection
  if (scenario.faultActive) {
    newState.faults = [{
      id: 'fault_scenario',
      componentId: 'line3',
      componentType: 'line',
      faultType: 'LLL',
      faultResistance: 0.5,
      duration: 500,
      active: true,
      faultCurrent: 0,
      startTime: 0
    }];
  } else {
    newState.faults = [];
  }
  
  return newState;
}
