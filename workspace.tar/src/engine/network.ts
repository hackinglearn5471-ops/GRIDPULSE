// GRIDPULSE - Default Demo Network Model
// 33kV Grid → 33/11kV Substation → 11kV Feeder → LV Distribution

import type {
  Bus, Transformer, Line, Load, SolarPV, Battery, CapacitorBank,
  CircuitBreaker, Fault, SimulationState, SimulationConfig
} from './types';
import { calculatePowerFlow } from './calculations';

export function createDefaultNetwork(): SimulationState {
  const buses: Bus[] = [
    {
      id: 'grid', name: 'Grid Source (33kV)', voltage: 33, voltagePU: 1.0,
      voltageAngle: 0, voltageStatus: 'NORMAL', pLoad: 0, qLoad: 0,
      pGen: 0, qGen: 0, x: 400, y: 40, type: 'source'
    },
    {
      id: 'sub_bus', name: 'Substation Bus (11kV)', voltage: 11, voltagePU: 0.99,
      voltageAngle: -0.5, voltageStatus: 'NORMAL', pLoad: 0, qLoad: 0,
      pGen: 0, qGen: 0, x: 400, y: 130, type: 'distribution'
    },
    {
      id: 'bus1', name: 'Feeder 1 - Bus 1', voltage: 11, voltagePU: 0.98,
      voltageAngle: -1.0, voltageStatus: 'NORMAL', pLoad: 450, qLoad: 180,
      pGen: 0, qGen: 0, x: 150, y: 240, type: 'distribution'
    },
    {
      id: 'bus2', name: 'Feeder 2 - Bus 2', voltage: 11, voltagePU: 0.97,
      voltageAngle: -1.5, voltageStatus: 'NORMAL', pLoad: 380, qLoad: 150,
      pGen: 200, qGen: 50, x: 400, y: 240, type: 'distribution'
    },
    {
      id: 'bus3', name: 'Feeder 3 - Bus 3', voltage: 11, voltagePU: 0.96,
      voltageAngle: -2.0, voltageStatus: 'NORMAL', pLoad: 620, qLoad: 280,
      pGen: 0, qGen: 0, x: 650, y: 240, type: 'distribution'
    },
    {
      id: 'bus4', name: 'LV Bus 4 (Residential)', voltage: 0.415, voltagePU: 0.97,
      voltageAngle: -2.5, voltageStatus: 'NORMAL', pLoad: 180, qLoad: 60,
      pGen: 50, qGen: 10, x: 80, y: 370, type: 'load'
    },
    {
      id: 'bus5', name: 'LV Bus 5 (Commercial)', voltage: 0.415, voltagePU: 0.96,
      voltageAngle: -3.0, voltageStatus: 'NORMAL', pLoad: 280, qLoad: 120,
      pGen: 150, qGen: 40, x: 300, y: 370, type: 'load'
    },
    {
      id: 'bus6', name: 'LV Bus 6 (Industrial)', voltage: 0.415, voltagePU: 0.95,
      voltageAngle: -3.5, voltageStatus: 'NORMAL', pLoad: 520, qLoad: 240,
      pGen: 0, qGen: 0, x: 550, y: 370, type: 'load'
    },
    {
      id: 'bus7', name: 'LV Bus 7 (Solar Farm)', voltage: 0.415, voltagePU: 1.02,
      voltageAngle: -1.5, voltageStatus: 'NORMAL', pLoad: 50, qLoad: 20,
      pGen: 400, qGen: 80, x: 750, y: 370, type: 'generation'
    }
  ];

  const transformers: Transformer[] = [
    {
      id: 'tx1', name: 'Main Transformer (33/11kV)',
      ratedPower: 10000, primaryVoltage: 33, secondaryVoltage: 11,
      impedance: 12.5, tapPosition: 0, numTaps: 17, tapRange: 10,
      loading: 65, currentP: 1450, currentQ: 610, powerFactor: 0.92,
      status: 'NORMAL', fromBus: 'grid', toBus: 'sub_bus', x: 400, y: 85
    },
    {
      id: 'tx2', name: 'Distribution TX 1 (11/0.415kV)',
      ratedPower: 500, primaryVoltage: 11, secondaryVoltage: 0.415,
      impedance: 4.5, tapPosition: 0, numTaps: 5, tapRange: 5,
      loading: 72, currentP: 230, currentQ: 70, powerFactor: 0.96,
      status: 'NORMAL', fromBus: 'bus1', toBus: 'bus4', x: 115, y: 305
    },
    {
      id: 'tx3', name: 'Distribution TX 2 (11/0.415kV)',
      ratedPower: 750, primaryVoltage: 11, secondaryVoltage: 0.415,
      impedance: 4.0, tapPosition: 0, numTaps: 5, tapRange: 5,
      loading: 57, currentP: 430, currentQ: 80, powerFactor: 0.98,
      status: 'NORMAL', fromBus: 'bus2', toBus: 'bus5', x: 350, y: 305
    },
    {
      id: 'tx4', name: 'Distribution TX 3 (11/0.415kV)',
      ratedPower: 1000, primaryVoltage: 11, secondaryVoltage: 0.415,
      impedance: 5.0, tapPosition: 0, numTaps: 5, tapRange: 5,
      loading: 52, currentP: 520, currentQ: 240, powerFactor: 0.91,
      status: 'NORMAL', fromBus: 'bus3', toBus: 'bus6', x: 600, y: 305
    }
  ];

  const lines: Line[] = [
    {
      id: 'line1', name: 'Feeder 1 (11kV)', fromBus: 'sub_bus', toBus: 'bus1',
      length: 3.2, resistance: 0.35, reactance: 0.38, thermalRating: 300,
      current: 28, loading: 9.3, pFlow: 450, qFlow: 180, losses: 0.84,
      voltageDrop: 1.2, flowDirection: 'FORWARD', status: 'NORMAL', phases: 3
    },
    {
      id: 'line2', name: 'Feeder 2 (11kV)', fromBus: 'sub_bus', toBus: 'bus2',
      length: 2.8, resistance: 0.35, reactance: 0.38, thermalRating: 300,
      current: 22, loading: 7.3, pFlow: 180, qFlow: 100, losses: 0.52,
      voltageDrop: 0.9, flowDirection: 'FORWARD', status: 'NORMAL', phases: 3
    },
    {
      id: 'line3', name: 'Feeder 3 (11kV)', fromBus: 'sub_bus', toBus: 'bus3',
      length: 4.5, resistance: 0.35, reactance: 0.38, thermalRating: 400,
      current: 45, loading: 11.3, pFlow: 620, qFlow: 280, losses: 2.68,
      voltageDrop: 2.1, flowDirection: 'FORWARD', status: 'NORMAL', phases: 3
    },
    {
      id: 'line4', name: 'LV Line 4', fromBus: 'bus1', toBus: 'bus4',
      length: 0.8, resistance: 0.50, reactance: 0.12, thermalRating: 200,
      current: 85, loading: 42.5, pFlow: 130, qFlow: 50, losses: 2.89,
      voltageDrop: 1.8, flowDirection: 'FORWARD', status: 'NORMAL', phases: 3
    },
    {
      id: 'line5', name: 'LV Line 5', fromBus: 'bus2', toBus: 'bus5',
      length: 0.6, resistance: 0.50, reactance: 0.12, thermalRating: 250,
      current: 110, loading: 44.0, pFlow: 130, qFlow: 80, losses: 3.63,
      voltageDrop: 1.5, flowDirection: 'FORWARD', status: 'NORMAL', phases: 3
    },
    {
      id: 'line6', name: 'LV Line 6', fromBus: 'bus3', toBus: 'bus6',
      length: 1.0, resistance: 0.50, reactance: 0.12, thermalRating: 300,
      current: 145, loading: 48.3, pFlow: 520, qFlow: 240, losses: 10.5,
      voltageDrop: 2.5, flowDirection: 'FORWARD', status: 'NORMAL', phases: 3
    },
    {
      id: 'line7', name: 'Solar Connection', fromBus: 'bus2', toBus: 'bus7',
      length: 0.4, resistance: 0.50, reactance: 0.12, thermalRating: 200,
      current: 55, loading: 27.5, pFlow: -350, qFlow: -60, losses: 1.82,
      voltageDrop: -1.2, flowDirection: 'REVERSE', status: 'NORMAL', phases: 3
    }
  ];

  const loads: Load[] = [
    {
      id: 'load1', name: 'Residential Block A', busId: 'bus4', type: 'RESIDENTIAL',
      pNominal: 180, qNominal: 60, pActual: 180, qActual: 60,
      powerFactor: 0.95, numConsumers: 120, profileType: 'residential', status: 'NORMAL'
    },
    {
      id: 'load2', name: 'Commercial Center', busId: 'bus5', type: 'COMMERCIAL',
      pNominal: 280, qNominal: 120, pActual: 280, qActual: 120,
      powerFactor: 0.92, numConsumers: 45, profileType: 'commercial', status: 'NORMAL'
    },
    {
      id: 'load3', name: 'Industrial Plant', busId: 'bus6', type: 'INDUSTRIAL',
      pNominal: 520, qNominal: 240, pActual: 520, qActual: 240,
      powerFactor: 0.91, numConsumers: 1, profileType: 'industrial', status: 'NORMAL'
    },
    {
      id: 'load4', name: 'Smart Homes', busId: 'bus1', type: 'RESIDENTIAL',
      pNominal: 270, qNominal: 100, pActual: 270, qActual: 100,
      powerFactor: 0.96, numConsumers: 80, profileType: 'residential', status: 'NORMAL'
    },
    {
      id: 'load5', name: 'Office Complex', busId: 'bus3', type: 'COMMERCIAL',
      pNominal: 350, qNominal: 150, pActual: 350, qActual: 150,
      powerFactor: 0.93, numConsumers: 30, profileType: 'commercial', status: 'NORMAL'
    },
    {
      id: 'load6', name: 'Solar Farm Aux Load', busId: 'bus7', type: 'COMMERCIAL',
      pNominal: 50, qNominal: 20, pActual: 50, qActual: 20,
      powerFactor: 0.93, numConsumers: 5, profileType: 'commercial', status: 'NORMAL'
    }
  ];

  const solarPV: SolarPV[] = [
    {
      id: 'pv1', name: 'Rooftop Solar (Bus 5)', busId: 'bus5',
      capacity: 150, irradiance: 750, temperature: 35, efficiency: 0.95,
      powerFactor: 0.95, currentOutput: 107, inverterRating: 160,
      curtailment: 0, status: 'NORMAL'
    },
    {
      id: 'pv2', name: 'Solar Farm (Bus 7)', busId: 'bus7',
      capacity: 500, irradiance: 800, temperature: 32, efficiency: 0.97,
      powerFactor: 0.98, currentOutput: 388, inverterRating: 500,
      curtailment: 0, status: 'NORMAL'
    },
    {
      id: 'pv3', name: 'Rooftop Solar (Bus 4)', busId: 'bus4',
      capacity: 60, irradiance: 720, temperature: 38, efficiency: 0.93,
      powerFactor: 0.95, currentOutput: 40, inverterRating: 65,
      curtailment: 0, status: 'NORMAL'
    }
  ];

  const batteries: Battery[] = [
    {
      id: 'bat1', name: 'Community BESS', busId: 'bus5',
      capacity: 200, soc: 72, maxChargePower: 100, maxDischargePower: 150,
      efficiency: 0.92, currentPower: -45, mode: 'PEAK_SHAVING',
      socMin: 10, socMax: 90, voltage: 400, current: 65, status: 'NORMAL'
    },
    {
      id: 'bat2', name: 'Solar Farm BESS', busId: 'bus7',
      capacity: 500, soc: 55, maxChargePower: 200, maxDischargePower: 250,
      efficiency: 0.94, currentPower: 80, mode: 'SOLAR_SELF_CONSUMPTION',
      socMin: 15, socMax: 85, voltage: 800, current: 100, status: 'NORMAL'
    }
  ];

  const capacitors: CapacitorBank[] = [
    {
      id: 'cap1', name: 'Capacitor Bank (Bus 3)', busId: 'bus3',
      numSteps: 4, stepSize: 50, activeSteps: 2, totalQ: 100,
      switchedOn: true, status: 'NORMAL'
    },
    {
      id: 'cap2', name: 'Capacitor Bank (Bus 6)', busId: 'bus6',
      numSteps: 3, stepSize: 75, activeSteps: 1, totalQ: 75,
      switchedOn: true, status: 'NORMAL'
    }
  ];

  const breakers: CircuitBreaker[] = [
    { id: 'cb1', name: 'Breaker F1', lineId: 'line1', state: 'CLOSED', ratedCurrent: 300, tripCurrent: 450, tripTime: 200 },
    { id: 'cb2', name: 'Breaker F2', lineId: 'line2', state: 'CLOSED', ratedCurrent: 300, tripCurrent: 450, tripTime: 200 },
    { id: 'cb3', name: 'Breaker F3', lineId: 'line3', state: 'CLOSED', ratedCurrent: 400, tripCurrent: 600, tripTime: 150 },
    { id: 'cb4', name: 'Breaker LV4', lineId: 'line4', state: 'CLOSED', ratedCurrent: 200, tripCurrent: 300, tripTime: 100 },
    { id: 'cb5', name: 'Breaker LV5', lineId: 'line5', state: 'CLOSED', ratedCurrent: 250, tripCurrent: 375, tripTime: 100 },
    { id: 'cb6', name: 'Breaker LV6', lineId: 'line6', state: 'CLOSED', ratedCurrent: 300, tripCurrent: 450, tripTime: 100 },
    { id: 'cb7', name: 'Breaker Solar', lineId: 'line7', state: 'CLOSED', ratedCurrent: 200, tripCurrent: 300, tripTime: 80 }
  ];

  const faults: Fault[] = [];

  // Calculate initial state
  let state: SimulationState = {
    buses, transformers, lines, loads, solarPV, batteries, capacitors, breakers, faults,
    totalLoadP: 0, totalLoadQ: 0, totalGenP: 0, totalGenQ: 0,
    totalLossesP: 0, totalLossesQ: 0, gridImport: 0, gridExport: 0,
    minVoltage: 1.0, maxVoltage: 1.0, systemFrequency: 50.0,
    powerFactor: 0.95, gridHealth: 100, converged: true,
    solverMessage: 'Initial state'
  };

  // Run initial power flow
  state = calculatePowerFlow(state);

  return state;
}

export function getDefaultConfig(): SimulationConfig {
  return {
    gridVoltage: 33,
    gridFrequency: 50,
    gridShortCircuitMVA: 250,
    simulationSpeed: 1,
    currentTime: 12, // noon
    isRunning: false,
    selectedComponent: null,
    selectedComponentType: null
  };
}
