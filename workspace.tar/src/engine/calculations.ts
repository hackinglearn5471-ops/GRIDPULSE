// GRIDPULSE - Power Flow Calculation Engine
// Implements simplified but physically meaningful power flow calculations
// Based on backward/forward sweep method for radial distribution networks

import type {
  Bus, Transformer, Line, Load, SolarPV, Battery, CapacitorBank,
  CircuitBreaker, Fault, SimulationState, VoltageStatus, ComponentStatus,
  FlowDirection, BatteryMode
} from './types';

// Constants
const BASE_VOLTAGE_LV = 0.415; // kV
const BASE_VOLTAGE_MV = 11; // kV
const BASE_VOLTAGE_HV = 33; // kV
const V_NOMINAL = 1.0; // pu
const V_LOW_LIMIT = 0.95; // pu
const V_HIGH_LIMIT = 1.05; // pu
const V_CRITICAL_LOW = 0.90; // pu
const V_CRITICAL_HIGH = 1.10; // pu
const TRANSFORMER_LOADING_WARNING = 80; // %
const TRANSFORMER_LOADING_CRITICAL = 100; // %
const LINE_LOADING_WARNING = 80; // %
const LINE_LOADING_CRITICAL = 100; // %

export function getVoltageStatus(vpu: number): VoltageStatus {
  if (vpu <= V_CRITICAL_LOW) return 'CRITICAL_LOW';
  if (vpu < V_LOW_LIMIT) return 'LOW';
  if (vpu > V_CRITICAL_HIGH) return 'CRITICAL_HIGH';
  if (vpu > V_HIGH_LIMIT) return 'HIGH';
  return 'NORMAL';
}

export function getComponentStatus(loading: number, warningThreshold: number = 80, criticalThreshold: number = 100): ComponentStatus {
  if (loading >= criticalThreshold) return 'CRITICAL';
  if (loading >= warningThreshold) return 'WARNING';
  return 'NORMAL';
}

export function getFlowDirection(pFlow: number): FlowDirection {
  if (Math.abs(pFlow) < 0.1) return 'NONE';
  return pFlow > 0 ? 'FORWARD' : 'REVERSE';
}

// Calculate solar output based on irradiance and temperature
export function calculateSolarOutput(pv: SolarPV): number {
  const tempCoeff = -0.004; // typical for crystalline silicon (%/°C)
  const tempDerating = 1 + tempCoeff * (pv.temperature - 25);
  const irradianceFactor = pv.irradiance / 1000;
  let output = pv.capacity * irradianceFactor * tempDerating * pv.efficiency;
  
  // Apply inverter limit
  output = Math.min(output, pv.inverterRating * pv.powerFactor);
  
  // Apply curtailment
  output = output * (1 - pv.curtailment / 100);
  
  return Math.max(0, output);
}

// Calculate battery power based on mode and conditions
export function calculateBatteryPower(battery: Battery, netLoad: number, solarOutput: number): number {
  let power = 0;
  
  // Safety threshold - battery stops discharging below this SOC
  const SAFE_DISCHARGE_LIMIT = 20; // %
  const CRITICAL_SOC_LIMIT = 10; // % - absolute minimum
  
  // Gradual discharge factor - reduces power as SOC approaches limit
  const getDischargeFactor = (soc: number): number => {
    if (soc <= CRITICAL_SOC_LIMIT) return 0; // Stop completely
    if (soc <= SAFE_DISCHARGE_LIMIT) {
      // Linear reduction from 100% to 0% between 20% and 10%
      return (soc - CRITICAL_SOC_LIMIT) / (SAFE_DISCHARGE_LIMIT - CRITICAL_SOC_LIMIT);
    }
    return 1; // Full power above safe limit
  };
  
  const dischargeFactor = getDischargeFactor(battery.soc);
  
  switch (battery.mode) {
    case 'MANUAL':
      power = battery.currentPower;
      // Apply safety limit to manual discharge
      if (power < 0) {
        power = power * dischargeFactor;
      }
      break;
    case 'LOAD_FOLLOWING':
      // Battery follows load - charges when load is low, discharges when high
      if (netLoad > 0) {
        // Discharge in controlled bits (max 30% of net load)
        const desiredDischarge = netLoad * 0.3;
        power = -Math.min(battery.maxDischargePower, desiredDischarge) * dischargeFactor;
      } else {
        power = Math.min(battery.maxChargePower, Math.abs(netLoad) * 0.5);
      }
      break;
    case 'PEAK_SHAVING':
      // Discharge during peak, charge during off-peak
      if (netLoad > 500) {
        // Discharge in bits - max 60% of excess load
        const excessLoad = netLoad - 500;
        const desiredDischarge = excessLoad * 0.6;
        power = -Math.min(battery.maxDischargePower, desiredDischarge) * dischargeFactor;
      } else if (netLoad < 200) {
        power = Math.min(battery.maxChargePower, 100);
      }
      break;
    case 'SOLAR_SELF_CONSUMPTION':
      // Store excess solar, use stored energy when solar is insufficient
      if (solarOutput > netLoad && solarOutput > 0) {
        const excess = solarOutput - netLoad;
        power = Math.min(battery.maxChargePower, excess * 0.8);
      } else if (netLoad > solarOutput) {
        const deficit = netLoad - solarOutput;
        // Discharge in controlled bits - max 50% of deficit
        const desiredDischarge = deficit * 0.5;
        power = -Math.min(battery.maxDischargePower, desiredDischarge) * dischargeFactor;
      }
      break;
    case 'GRID_SUPPORT':
      // Support grid voltage - inject reactive/active when voltage is low
      if (netLoad > 800) {
        // Discharge in bits - max 40% of load
        const desiredDischarge = netLoad * 0.4;
        power = -Math.min(battery.maxDischargePower, desiredDischarge) * dischargeFactor;
      } else {
        power = Math.min(battery.maxChargePower, 50);
      }
      break;
  }
  
  // Hard SOC limits (safety cutoff)
  if (battery.soc <= CRITICAL_SOC_LIMIT && power < 0) {
    power = 0; // Completely stop discharge
  }
  if (battery.soc >= battery.socMax && power > 0) {
    power = 0; // Stop charging when full
  }
  
  // Round to nearest integer for cleaner display
  return Math.round(power);
}

// Update battery SOC
export function updateBatterySOC(battery: Battery, power: number, dt: number): number {
  // dt in hours, power in kW
  const energyChange = power * dt; // kWh
  const efficiency = power > 0 ? battery.efficiency : 1 / battery.efficiency;
  const newSOC = battery.soc + (energyChange * efficiency / battery.capacity) * 100;
  return Math.max(0, Math.min(100, newSOC));
}

// Calculate capacitor reactive power
export function calculateCapacitorOutput(cap: CapacitorBank): number {
  if (!cap.switchedOn) return 0;
  return cap.activeSteps * cap.stepSize;
}

// Simplified power flow calculation using backward/forward sweep
export function calculatePowerFlow(state: SimulationState): SimulationState {
  const newState = { ...state };
  
  // Step 1: Calculate generation at each bus
  const busGeneration: Record<string, { p: number; q: number }> = {};
  state.buses.forEach(b => { busGeneration[b.id] = { p: 0, q: 0 }; });
  
  // Solar generation
  state.solarPV.forEach(pv => {
    const output = calculateSolarOutput(pv);
    const pOut = output;
    const qOut = pOut * Math.tan(Math.acos(pv.powerFactor));
    if (busGeneration[pv.busId]) {
      busGeneration[pv.busId].p += pOut;
      busGeneration[pv.busId].q += qOut;
    }
  });
  
  // Battery power
  state.batteries.forEach(bat => {
    const pBat = -bat.currentPower; // negative = discharging = generation
    if (busGeneration[bat.busId]) {
      busGeneration[bat.busId].p += pBat;
    }
  });
  
  // Capacitor reactive power
  state.capacitors.forEach(cap => {
    const qCap = calculateCapacitorOutput(cap);
    if (busGeneration[cap.busId]) {
      busGeneration[cap.busId].q += qCap;
    }
  });
  
  // Step 2: Calculate net power at each bus
  const busNetPower: Record<string, { p: number; q: number }> = {};
  state.buses.forEach(b => {
    const gen = busGeneration[b.id] || { p: 0, q: 0 };
    busNetPower[b.id] = {
      p: gen.p - b.pLoad,
      q: gen.q - b.qLoad
    };
  });
  
  // Step 3: Calculate line flows and losses (forward sweep from source)
  let totalLossesP = 0;
  let totalLossesQ = 0;
  
  // Sort lines by distance from source (simplified: use order in array)
  const sortedLines = [...state.lines].sort((a, b) => a.fromBus.localeCompare(b.fromBus));
  
  // Accumulated power flowing through each line
  const lineFlows: Record<string, { p: number; q: number }> = {};
  
  // Calculate power flowing from source through network
  // Start from the last buses and work backward to accumulate loads
  const busAccumulatedPower: Record<string, { p: number; q: number }> = {};
  state.buses.forEach(b => {
    busAccumulatedPower[b.id] = { p: 0, q: 0 };
  });
  
  // Backward sweep: accumulate power from leaves to source
  for (let i = sortedLines.length - 1; i >= 0; i--) {
    const line = sortedLines[i];
    const toBusPower = busAccumulatedPower[line.toBus] || { p: 0, q: 0 };
    const netPower = busNetPower[line.toBus] || { p: 0, q: 0 };
    
    busAccumulatedPower[line.fromBus] = {
      p: (busAccumulatedPower[line.fromBus]?.p || 0) + netPower.p + toBusPower.p,
      q: (busAccumulatedPower[line.fromBus]?.q || 0) + netPower.q + toBusPower.q
    };
  }
  
  // Add source bus load
  const sourceBus = state.buses.find(b => b.type === 'source');
  if (sourceBus) {
    const srcNet = busNetPower[sourceBus.id] || { p: 0, q: 0 };
    busAccumulatedPower[sourceBus.id] = {
      p: (busAccumulatedPower[sourceBus.id]?.p || 0) + srcNet.p,
      q: (busAccumulatedPower[sourceBus.id]?.q || 0) + srcNet.q
    };
  }
  
  // Forward sweep: calculate currents and losses
  sortedLines.forEach(line => {
    const pFlow = busAccumulatedPower[line.toBus]?.p || 0;
    const qFlow = busAccumulatedPower[line.toBus]?.q || 0;
    
    // Add the load at the to-bus
    const busLoad = busNetPower[line.toBus] || { p: 0, q: 0 };
    const totalP = Math.abs(pFlow) + Math.abs(busLoad.p < 0 ? busLoad.p : 0);
    const totalQ = Math.abs(qFlow) + Math.abs(busLoad.q < 0 ? busLoad.q : 0);
    
    // Calculate apparent power
    const sFlow = Math.sqrt(pFlow * pFlow + qFlow * qFlow);
    
    // Calculate current (simplified: I = S / (sqrt(3) * V))
    const toBus = state.buses.find(b => b.id === line.toBus);
    const vNom = toBus ? toBus.voltage : 11;
    const current = (sFlow * 1000) / (Math.sqrt(3) * vNom * 1000);
    
    // Calculate losses: P_loss = I² * R * L
    const totalR = line.resistance * line.length;
    const totalX = line.reactance * line.length;
    const lossesP = 3 * current * current * totalR / 1000; // kW
    const lossesQ = 3 * current * current * totalX / 1000; // kVAR
    
    // Voltage drop: ΔV = I * (R*cos(φ) + X*sin(φ)) * L
    const powerFactor = sFlow > 0 ? pFlow / sFlow : 1;
    const sinPhi = Math.sqrt(1 - powerFactor * powerFactor);
    const voltageDrop = (current * (totalR * powerFactor + totalX * sinPhi)) / (vNom * 1000) * 100;
    
    const loading = (current / line.thermalRating) * 100;
    
    // Update line in state
    const lineIdx = newState.lines.findIndex(l => l.id === line.id);
    if (lineIdx >= 0) {
      newState.lines[lineIdx] = {
        ...newState.lines[lineIdx],
        current: Math.abs(current),
        pFlow: pFlow,
        qFlow: qFlow,
        losses: lossesP,
        voltageDrop: voltageDrop,
        loading: loading,
        flowDirection: getFlowDirection(pFlow),
        status: getComponentStatus(loading, LINE_LOADING_WARNING, LINE_LOADING_CRITICAL)
      };
    }
    
    totalLossesP += lossesP;
    totalLossesQ += lossesQ;
  });
  
  // Step 4: Calculate bus voltages
  // Start from source bus (1.0 pu) and calculate voltage drops along feeders
  const busVoltages: Record<string, number> = {};
  if (sourceBus) {
    busVoltages[sourceBus.id] = V_NOMINAL;
  }
  
  // Forward voltage calculation
  sortedLines.forEach(line => {
    const fromV = busVoltages[line.fromBus] || V_NOMINAL;
    const lineData = newState.lines.find(l => l.id === line.id);
    const voltageDropPU = (lineData?.voltageDrop || 0) / 100;
    
    // Voltage at to-bus = voltage at from-bus - voltage drop
    // For reverse flow, voltage rises
    let toV: number;
    if (lineData?.flowDirection === 'REVERSE') {
      toV = fromV + voltageDropPU * 0.5; // Voltage rise from reverse power flow
    } else {
      toV = fromV - voltageDropPU;
    }
    
    busVoltages[line.toBus] = Math.max(0.8, Math.min(1.2, toV));
  });
  
  // Update bus voltages
  newState.buses = newState.buses.map(bus => {
    const vpu = busVoltages[bus.id] || V_NOMINAL;
    const vStatus = getVoltageStatus(vpu);
    const gen = busGeneration[bus.id] || { p: 0, q: 0 };
    return {
      ...bus,
      voltagePU: vpu,
      voltageAngle: -(1 - vpu) * 5, // Simplified angle calculation
      voltageStatus: vStatus,
      pGen: gen.p,
      qGen: gen.q
    };
  });
  
  // Step 5: Calculate transformer loading
  newState.transformers = newState.transformers.map(tx => {
    const fromBus = newState.buses.find(b => b.id === tx.fromBus);
    const toBus = newState.buses.find(b => b.id === tx.toBus);
    
    // Power through transformer = load on secondary side + losses
    const secondaryLoad = newState.lines
      .filter(l => l.fromBus === tx.toBus || (fromBus && l.fromBus === fromBus.id))
      .reduce((sum, l) => sum + Math.abs(l.pFlow), 0);
    
    // Total power through transformer
    const totalBusLoad = newState.buses
      .filter(b => b.id !== tx.fromBus && b.id !== tx.toBus)
      .reduce((sum, b) => sum + Math.abs(b.pLoad), 0);
    
    // Simplified: transformer carries all downstream load
    const txP = newState.buses
      .filter(b => {
        // Find buses downstream of transformer
        const path = findDownstreamBuses(tx.toBus, newState.lines, newState.buses);
        return path.includes(b.id);
      })
      .reduce((sum, b) => sum + b.pLoad - b.pGen, 0);
    
    const txQ = newState.buses
      .filter(b => {
        const path = findDownstreamBuses(tx.toBus, newState.lines, newState.buses);
        return path.includes(b.id);
      })
      .reduce((sum, b) => sum + b.qLoad - b.qGen, 0);
    
    const txS = Math.sqrt(txP * txP + txQ * txQ);
    const loading = (txS / tx.ratedPower) * 100;
    const pf = txS > 0 ? txP / txS : 1;
    
    return {
      ...tx,
      loading: Math.abs(loading),
      currentP: txP,
      currentQ: txQ,
      powerFactor: pf,
      status: getComponentStatus(Math.abs(loading), TRANSFORMER_LOADING_WARNING, TRANSFORMER_LOADING_CRITICAL)
    };
  });
  
  // Step 6: Handle faults
  if (state.faults.some(f => f.active)) {
    newState.faults = state.faults.map(fault => {
      if (!fault.active) return fault;
      
      // Calculate fault current
      let faultCurrent = 0;
      const sourceBus = newState.buses.find(b => b.type === 'source');
      const vSource = sourceBus ? sourceBus.voltage * 1000 : 33000;
      
      switch (fault.faultType) {
        case 'SLG': // Single line to ground
          faultCurrent = vSource / (Math.sqrt(3) * (fault.faultResistance + 0.5));
          break;
        case 'LL': // Line to line
          faultCurrent = vSource / (2 * (fault.faultResistance + 0.3));
          break;
        case 'DLG': // Double line to ground
          faultCurrent = vSource / (Math.sqrt(3) * (fault.faultResistance + 0.4));
          break;
        case 'LLL': // Three phase
          faultCurrent = vSource / (Math.sqrt(3) * (fault.faultResistance + 0.2));
          break;
        case 'HIF': // High impedance fault
          faultCurrent = vSource / (fault.faultResistance + 100);
          break;
      }
      
      // Reduce voltage at faulted bus
      if (fault.componentType === 'bus') {
        const busIdx = newState.buses.findIndex(b => b.id === fault.componentId);
        if (busIdx >= 0) {
          newState.buses[busIdx] = {
            ...newState.buses[busIdx],
            voltagePU: 0.1 + fault.faultResistance * 0.01,
            voltageStatus: 'CRITICAL_LOW'
          };
        }
      }
      
      return { ...fault, faultCurrent };
    });
  }
  
  // Step 7: Calculate totals
  newState.totalLoadP = newState.buses.reduce((sum, b) => sum + b.pLoad, 0);
  newState.totalLoadQ = newState.buses.reduce((sum, b) => sum + b.qLoad, 0);
  newState.totalGenP = newState.buses.reduce((sum, b) => sum + b.pGen, 0);
  newState.totalGenQ = newState.buses.reduce((sum, b) => sum + b.qGen, 0);
  newState.totalLossesP = totalLossesP;
  newState.totalLossesQ = totalLossesQ;
  
  // Grid import/export
  const netPower = newState.totalLoadP - newState.totalGenP + totalLossesP;
  newState.gridImport = netPower > 0 ? netPower : 0;
  newState.gridExport = netPower < 0 ? Math.abs(netPower) : 0;
  
  // Voltage extremes
  newState.minVoltage = Math.min(...newState.buses.map(b => b.voltagePU));
  newState.maxVoltage = Math.max(...newState.buses.map(b => b.voltagePU));
  
  // System power factor
  const totalS = Math.sqrt(newState.totalLoadP * newState.totalLoadP + newState.totalLoadQ * newState.totalLoadQ);
  newState.powerFactor = totalS > 0 ? newState.totalLoadP / totalS : 1;
  
  // Grid health calculation
  newState.gridHealth = calculateGridHealth(newState);
  
  newState.converged = true;
  newState.solverMessage = 'Power flow converged successfully';
  
  return newState;
}

// Find all buses downstream of a given bus
function findDownstreamBuses(startBusId: string, lines: Line[], buses: Bus[]): string[] {
  const result: string[] = [startBusId];
  const visited = new Set<string>([startBusId]);
  const queue = [startBusId];
  
  while (queue.length > 0) {
    const current = queue.shift()!;
    const downstreamLines = lines.filter(l => l.fromBus === current);
    downstreamLines.forEach(line => {
      if (!visited.has(line.toBus)) {
        visited.add(line.toBus);
        result.push(line.toBus);
        queue.push(line.toBus);
      }
    });
  }
  
  return result;
}

// Calculate grid health score (0-100)
export function calculateGridHealth(state: SimulationState): number {
  let score = 100;
  
  // Voltage violations (-20 max)
  const voltageViolations = state.buses.filter(b => b.voltageStatus !== 'NORMAL').length;
  score -= Math.min(20, voltageViolations * 5);
  
  // Critical voltage (-15 max)
  const criticalVoltages = state.buses.filter(b => 
    b.voltageStatus === 'CRITICAL_LOW' || b.voltageStatus === 'CRITICAL_HIGH'
  ).length;
  score -= Math.min(15, criticalVoltages * 10);
  
  // Transformer overloads (-15 max)
  const overloadedTransformers = state.transformers.filter(t => t.status === 'CRITICAL').length;
  score -= Math.min(15, overloadedTransformers * 10);
  
  // Line overloads (-15 max)
  const overloadedLines = state.lines.filter(l => l.status === 'CRITICAL').length;
  score -= Math.min(15, overloadedLines * 5);
  
  // High losses (-10 max)
  const lossPercent = state.totalLoadP > 0 ? (state.totalLossesP / state.totalLoadP) * 100 : 0;
  if (lossPercent > 10) score -= 10;
  else if (lossPercent > 5) score -= 5;
  else if (lossPercent > 3) score -= 2;
  
  // Poor power factor (-10 max)
  if (state.powerFactor < 0.85) score -= 10;
  else if (state.powerFactor < 0.90) score -= 5;
  else if (state.powerFactor < 0.95) score -= 2;
  
  // Active faults (-20 max)
  const activeFaults = state.faults.filter(f => f.active).length;
  score -= Math.min(20, activeFaults * 20);
  
  // Reverse power flow penalty (-5 max)
  const reverseFlows = state.lines.filter(l => l.flowDirection === 'REVERSE').length;
  if (reverseFlows > 0) score -= Math.min(5, reverseFlows * 2);
  
  return Math.max(0, Math.min(100, Math.round(score)));
}

// Get health color
export function getHealthColor(health: number): string {
  if (health >= 90) return '#22c55e';
  if (health >= 70) return '#f59e0b';
  if (health >= 50) return '#f97316';
  return '#ef4444';
}

// Get status color
export function getStatusColor(status: ComponentStatus | VoltageStatus): string {
  switch (status) {
    case 'NORMAL': return '#22c55e';
    case 'WARNING': return '#f59e0b';
    case 'CRITICAL':
    case 'CRITICAL_LOW':
    case 'CRITICAL_HIGH': return '#ef4444';
    case 'LOW': return '#f97316';
    case 'HIGH': return '#f97316';
    case 'OFFLINE': return '#94a3b8';
    case 'FAULT': return '#ef4444';
    default: return '#64748b';
  }
}
