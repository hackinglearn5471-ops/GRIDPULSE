import React, { useState, useRef, useCallback, useEffect } from 'react';
import type { SimulationState, Bus, Transformer, Line, Load, SolarPV, Battery, CapacitorBank, CircuitBreaker, FaultType } from '../engine/types';
import { getStatusColor } from '../engine/calculations';

interface CircuitViewProps {
  state: SimulationState;
  onSelectComponent: (id: string, type: string) => void;
  selectedComponent: string | null;
  onToggleBreaker?: (id: string) => void;
  onToggleCapacitor?: (id: string) => void;
  onDeleteComponent?: (id: string, type: string) => void;
  onAddComponent?: (type: string, busId?: string) => void;
}

interface Position { x: number; y: number; }
interface Tooltip { x: number; y: number; content: React.ReactNode; }
interface ContextMenu { x: number; y: number; items: { label: string; icon: string; action: () => void; danger?: boolean }[]; }

const CircuitView: React.FC<CircuitViewProps> = ({
  state, onSelectComponent, selectedComponent,
  onToggleBreaker, onToggleCapacitor, onDeleteComponent, onAddComponent
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // View state
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState<Position>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState<Position>({ x: 0, y: 0 });

  // Component positions (draggable)
  const [positions, setPositions] = useState<Record<string, Position>>(() => {
    const pos: Record<string, Position> = {};
    state.buses.forEach(b => { pos[b.id] = { x: b.x, y: b.y }; });
    return pos;
  });

  // Interaction state
  const [dragging, setDragging] = useState<{ id: string; type: string; offset: Position } | null>(null);
  const [hovered, setHovered] = useState<string | null>(null);
  const [tooltip, setTooltip] = useState<Tooltip | null>(null);
  const [contextMenu, setContextMenu] = useState<ContextMenu | null>(null);
  const [showPalette, setShowPalette] = useState(false);

  // Close context menu on click elsewhere
  useEffect(() => {
    const close = () => setContextMenu(null);
    window.addEventListener('click', close);
    return () => window.removeEventListener('click', close);
  }, []);

  // Get SVG coordinates from mouse event
  const getSVGPoint = useCallback((e: React.MouseEvent): Position => {
    if (!svgRef.current) return { x: 0, y: 0 };
    const rect = svgRef.current.getBoundingClientRect();
    const vb = svgRef.current.viewBox.baseVal;
    return {
      x: ((e.clientX - rect.left) / rect.width) * vb.width / zoom - pan.x,
      y: ((e.clientY - rect.top) / rect.height) * vb.height / zoom - pan.y
    };
  }, [zoom, pan]);

  // Mouse handlers for zoom/pan
  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom(z => Math.max(0.3, Math.min(3, z * delta)));
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.target === svgRef.current || (e.target as SVGElement).tagName === 'rect' && (e.target as SVGElement).getAttribute('data-bg') === 'true') {
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  }, [pan]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (isPanning) {
      setPan({ x: e.clientX - panStart.x, y: e.clientY - panStart.y });
    } else if (dragging) {
      const pt = getSVGPoint(e);
      setPositions(p => ({ ...p, [dragging.id]: { x: pt.x - dragging.offset.x, y: pt.y - dragging.offset.y } }));
    }
  }, [isPanning, panStart, dragging, getSVGPoint]);

  const handleMouseUp = useCallback(() => {
    setIsPanning(false);
    setDragging(null);
  }, []);

  // Component drag handlers
  const startDrag = (id: string, type: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const pt = getSVGPoint(e);
    const pos = positions[id] || { x: 0, y: 0 };
    setDragging({ id, type, offset: { x: pt.x - pos.x, y: pt.y - pos.y } });
  };

  // Tooltip content generators
  const getBusTooltip = (bus: Bus) => (
    <div className="text-xs">
      <div className="font-bold text-slate-800 mb-1">{bus.name}</div>
      <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 font-mono text-[10px]">
        <span className="text-slate-500">Voltage:</span><span className="font-bold" style={{ color: getStatusColor(bus.voltageStatus) }}>{bus.voltagePU.toFixed(4)} pu</span>
        <span className="text-slate-500">Angle:</span><span>{bus.voltageAngle.toFixed(2)}°</span>
        <span className="text-slate-500">P Load:</span><span>{bus.pLoad.toFixed(1)} kW</span>
        <span className="text-slate-500">Q Load:</span><span>{bus.qLoad.toFixed(1)} kVAR</span>
        <span className="text-slate-500">P Gen:</span><span className="text-emerald-600">{bus.pGen.toFixed(1)} kW</span>
        <span className="text-slate-500">Status:</span><span style={{ color: getStatusColor(bus.voltageStatus) }}>{bus.voltageStatus}</span>
      </div>
    </div>
  );

  const getTxTooltip = (tx: Transformer) => (
    <div className="text-xs">
      <div className="font-bold text-slate-800 mb-1">{tx.name}</div>
      <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 font-mono text-[10px]">
        <span className="text-slate-500">Loading:</span><span className="font-bold" style={{ color: getStatusColor(tx.status) }}>{tx.loading.toFixed(1)}%</span>
        <span className="text-slate-500">Rating:</span><span>{tx.ratedPower} kVA</span>
        <span className="text-slate-500">P Flow:</span><span>{tx.currentP.toFixed(1)} kW</span>
        <span className="text-slate-500">PF:</span><span>{tx.powerFactor.toFixed(3)}</span>
        <span className="text-slate-500">Tap:</span><span>{tx.tapPosition > 0 ? '+' : ''}{tx.tapPosition}</span>
        <span className="text-slate-500">Status:</span><span style={{ color: getStatusColor(tx.status) }}>{tx.status}</span>
      </div>
    </div>
  );

  const getLineTooltip = (line: Line) => (
    <div className="text-xs">
      <div className="font-bold text-slate-800 mb-1">{line.name}</div>
      <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 font-mono text-[10px]">
        <span className="text-slate-500">Current:</span><span className="font-bold">{line.current.toFixed(1)} A</span>
        <span className="text-slate-500">Loading:</span><span style={{ color: getStatusColor(line.status) }}>{line.loading.toFixed(1)}%</span>
        <span className="text-slate-500">P Flow:</span><span>{line.pFlow.toFixed(1)} kW</span>
        <span className="text-slate-500">Losses:</span><span className="text-red-600">{line.losses.toFixed(2)} kW</span>
        <span className="text-slate-500">V Drop:</span><span>{line.voltageDrop.toFixed(2)}%</span>
        <span className="text-slate-500">Direction:</span><span style={{ color: line.flowDirection === 'REVERSE' ? '#f59e0b' : '#3b82f6' }}>{line.flowDirection}</span>
      </div>
    </div>
  );

  // Context menu handler
  const handleContextMenu = (e: React.MouseEvent, id: string, type: string) => {
    e.preventDefault();
    e.stopPropagation();
    const items: ContextMenu['items'] = [
      { label: 'Inspect', icon: '🔍', action: () => onSelectComponent(id, type) },
      { label: 'Edit Parameters', icon: '✏️', action: () => onSelectComponent(id, type) },
    ];
    if (type === 'breaker' && onToggleBreaker) {
      const cb = state.breakers.find(b => b.id === id);
      items.push({ label: cb?.state === 'CLOSED' ? 'Open Breaker' : 'Close Breaker', icon: '⚡', action: () => onToggleBreaker(id) });
    }
    if (type === 'capacitor' && onToggleCapacitor) {
      const cap = state.capacitors.find(c => c.id === id);
      items.push({ label: cap?.switchedOn ? 'Switch OFF' : 'Switch ON', icon: '⚡', action: () => onToggleCapacitor(id) });
    }
    if (onDeleteComponent && type !== 'bus') {
      items.push({ label: 'Delete', icon: '🗑️', action: () => onDeleteComponent(id, type), danger: true });
    }
    setContextMenu({ x: e.clientX, y: e.clientY, items });
  };

  // Hover handlers
  const handleHover = (id: string, type: string, e: React.MouseEvent, content: React.ReactNode) => {
    setHovered(id);
    setTooltip({ x: e.clientX + 15, y: e.clientY + 15, content });
  };

  const handleHoverEnd = () => {
    setHovered(null);
    setTooltip(null);
  };

  // Render helpers
  const getPos = (id: string): Position => positions[id] || { x: 0, y: 0 };
  const isSelected = (id: string) => selectedComponent === id;
  const isHovered = (id: string) => hovered === id;

  return (
    <div ref={containerRef} className="w-full h-full relative bg-white overflow-hidden select-none" style={{ cursor: isPanning ? 'grabbing' : dragging ? 'move' : 'default' }}>
      {/* Toolbar */}
      <div className="absolute top-3 left-3 z-20 flex gap-1 bg-white/95 backdrop-blur-sm rounded-lg border border-slate-200 p-1 shadow-md">
        <button onClick={() => setZoom(z => Math.min(3, z * 1.2))} className="w-7 h-7 rounded hover:bg-slate-100 flex items-center justify-center text-slate-600 text-sm font-bold" title="Zoom In">+</button>
        <button onClick={() => setZoom(z => Math.max(0.3, z * 0.8))} className="w-7 h-7 rounded hover:bg-slate-100 flex items-center justify-center text-slate-600 text-sm font-bold" title="Zoom Out">−</button>
        <button onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }} className="w-7 h-7 rounded hover:bg-slate-100 flex items-center justify-center text-slate-600 text-[10px] font-bold" title="Reset View">⌂</button>
        <div className="w-px bg-slate-200 mx-0.5" />
        <button onClick={() => setShowPalette(!showPalette)} className={`px-2 h-7 rounded text-[10px] font-bold flex items-center gap-1 ${showPalette ? 'bg-blue-500 text-white' : 'hover:bg-slate-100 text-slate-600'}`} title="Add Components">
          <span>+</span> Add
        </button>
        <div className="w-px bg-slate-200 mx-0.5" />
        <div className="px-2 h-7 flex items-center text-[10px] font-mono text-slate-500">
          {(zoom * 100).toFixed(0)}%
        </div>
      </div>

      {/* Component Palette */}
      {showPalette && (
        <div className="absolute top-14 left-3 z-20 bg-white rounded-lg border border-slate-200 shadow-lg p-2 w-48">
          <div className="text-[10px] font-bold text-slate-500 uppercase mb-2 px-1">Add Component</div>
          <div className="space-y-0.5">
            {[
              { type: 'load', icon: '⚡', label: 'Load', desc: 'Add new load' },
              { type: 'solar', icon: '☀️', label: 'Solar PV', desc: 'Add solar system' },
              { type: 'battery', icon: '🔋', label: 'Battery', desc: 'Add BESS' },
              { type: 'capacitor', icon: '⚡', label: 'Capacitor', desc: 'Add capacitor bank' },
            ].map(item => (
              <button key={item.type} onClick={() => { onAddComponent?.(item.type); setShowPalette(false); }}
                className="w-full text-left px-2 py-1.5 rounded hover:bg-slate-100 flex items-center gap-2 transition-colors">
                <span className="text-base">{item.icon}</span>
                <div>
                  <div className="text-[11px] font-semibold text-slate-700">{item.label}</div>
                  <div className="text-[9px] text-slate-400">{item.desc}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Help hint */}
      <div className="absolute bottom-3 left-3 z-10 text-[10px] text-slate-400 bg-white/90 backdrop-blur-sm rounded px-2 py-1 border border-slate-200">
        <span className="font-semibold">Scroll</span> to zoom · <span className="font-semibold">Drag</span> background to pan · <span className="font-semibold">Drag</span> components to move · <span className="font-semibold">Right-click</span> for menu
      </div>

      {/* Main SVG */}
      <svg
        ref={svgRef}
        viewBox="0 0 1200 700"
        className="w-full h-full"
        preserveAspectRatio="xMidYMid meet"
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: 'center' }}
      >
        <defs>
          <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
            <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#f1f5f9" strokeWidth="0.5" />
          </pattern>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge><feMergeNode in="coloredBlur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <filter id="shadow">
            <feDropShadow dx="0" dy="1" stdDeviation="2" floodOpacity="0.15" />
          </filter>
        </defs>

        {/* Background */}
        <rect data-bg="true" x="-5000" y="-5000" width="10000" height="10000" fill="url(#grid)" />

        {/* ═══════════ GRID SOURCE ═══════════ */}
        {(() => {
          const bus = state.buses.find(b => b.id === 'grid');
          if (!bus) return null;
          const pos = getPos('grid');
          const sel = isSelected('grid');
          const hov = isHovered('grid');
          return (
            <g
              transform={`translate(${pos.x}, ${pos.y})`}
              onClick={(e) => { e.stopPropagation(); onSelectComponent('grid', 'bus'); }}
              onMouseDown={(e) => startDrag('grid', 'bus', e)}
              onMouseEnter={(e) => handleHover('grid', 'bus', e, getBusTooltip(bus))}
              onMouseLeave={handleHoverEnd}
              onContextMenu={(e) => handleContextMenu(e, 'grid', 'bus')}
              className="cursor-grab active:cursor-grabbing"
            >
              {/* Selection/hover ring */}
              {(sel || hov) && (
                <circle r="32" fill="none" stroke={sel ? '#2563eb' : '#60a5fa'} strokeWidth="2" strokeDasharray="4 2" opacity="0.6">
                  {!sel && <animate attributeName="stroke-dashoffset" from="0" to="12" dur="1s" repeatCount="indefinite" />}
                </circle>
              )}
              <circle r="26" fill={sel ? '#dbeafe' : hov ? '#eff6ff' : 'white'} stroke={sel ? '#2563eb' : '#1e40af'} strokeWidth="2.5" filter="url(#shadow)" />
              <line x1="-12" y1="0" x2="12" y2="0" stroke="#1e40af" strokeWidth="2.5" />
              <line x1="0" y1="-12" x2="0" y2="12" stroke="#1e40af" strokeWidth="2.5" />
              <text y="-38" textAnchor="middle" fontSize="11" fill="#1e3a8a" fontWeight="700" fontFamily="Inter">UTILITY GRID</text>
              <text y="44" textAnchor="middle" fontSize="10" fill="#64748b" fontFamily="JetBrains Mono" fontWeight="600">33 kV / 50 Hz</text>
              <text y="58" textAnchor="middle" fontSize="9" fill="#94a3b8" fontFamily="JetBrains Mono">{bus.voltagePU.toFixed(3)} pu</text>
            </g>
          );
        })()}

        {/* ═══════════ MAIN TRANSFORMER ═══════════ */}
        {(() => {
          const tx = state.transformers.find(t => t.id === 'tx1');
          const gridPos = getPos('grid');
          const subPos = getPos('sub_bus');
          if (!tx) return null;
          const midY = (gridPos.y + subPos.y) / 2;
          const sel = isSelected('tx1');
          const hov = isHovered('tx1');
          const color = getStatusColor(tx.status);
          return (
            <g>
              {/* Connection lines */}
              <line x1={gridPos.x} y1={gridPos.y + 26} x2={gridPos.x} y2={midY - 15} stroke="#475569" strokeWidth="2.5" />
              <line x1={gridPos.x} y1={midY + 15} x2={subPos.x} y2={subPos.y} stroke="#475569" strokeWidth="2.5" />
              <g
                transform={`translate(${gridPos.x}, ${midY})`}
                onClick={(e) => { e.stopPropagation(); onSelectComponent('tx1', 'transformer'); }}
                onMouseDown={(e) => startDrag('tx1', 'transformer', e)}
                onMouseEnter={(e) => handleHover('tx1', 'transformer', e, getTxTooltip(tx))}
                onMouseLeave={handleHoverEnd}
                onContextMenu={(e) => handleContextMenu(e, 'tx1', 'transformer')}
                className="cursor-grab active:cursor-grabbing"
              >
                {(sel || hov) && <circle r="28" fill="none" stroke={sel ? '#2563eb' : '#60a5fa'} strokeWidth="2" strokeDasharray="4 2" opacity="0.6" />}
                <circle cy="-11" r="14" fill={sel ? '#dbeafe' : 'white'} stroke={color} strokeWidth="2.5" filter="url(#shadow)" />
                <circle cy="11" r="14" fill={sel ? '#dbeafe' : 'white'} stroke={color} strokeWidth="2.5" filter="url(#shadow)" />
                <circle r="22" fill="none" stroke={color} strokeWidth="3" strokeDasharray={`${(tx.loading / 100) * 138} 138`} strokeLinecap="round" transform="rotate(-90)" opacity="0.6" />
                <text x="32" y="-10" fontSize="10" fill="#1e293b" fontWeight="700" fontFamily="Inter">{tx.name.split('(')[0].trim()}</text>
                <text x="32" y="3" fontSize="9" fill="#64748b" fontFamily="JetBrains Mono">{tx.primaryVoltage}/{tx.secondaryVoltage} kV | {(tx.ratedPower / 1000).toFixed(1)} MVA</text>
                <text x="32" y="16" fontSize="9" fill={color} fontWeight="700" fontFamily="JetBrains Mono">Loading: {tx.loading.toFixed(0)}% | PF: {tx.powerFactor.toFixed(2)}</text>
              </g>
            </g>
          );
        })()}

        {/* ═══════════ SUBSTATION BUS ═══════════ */}
        {(() => {
          const bus = state.buses.find(b => b.id === 'sub_bus');
          if (!bus) return null;
          const pos = getPos('sub_bus');
          const sel = isSelected('sub_bus');
          const hov = isHovered('sub_bus');
          const color = getStatusColor(bus.voltageStatus);
          return (
            <g
              transform={`translate(${pos.x}, ${pos.y})`}
              onClick={(e) => { e.stopPropagation(); onSelectComponent('sub_bus', 'bus'); }}
              onMouseDown={(e) => startDrag('sub_bus', 'bus', e)}
              onMouseEnter={(e) => handleHover('sub_bus', 'bus', e, getBusTooltip(bus))}
              onMouseLeave={handleHoverEnd}
              onContextMenu={(e) => handleContextMenu(e, 'sub_bus', 'bus')}
              className="cursor-grab active:cursor-grabbing"
            >
              {(sel || hov) && <rect x="-420" y="-8" width="840" height="16" fill={sel ? '#dbeafe' : '#eff6ff'} stroke={sel ? '#2563eb' : '#60a5fa'} strokeWidth="2" strokeDasharray="4 2" rx="3" opacity="0.6" />}
              <rect x="-400" y="-4" width="800" height="8" fill={color} rx="2" filter="url(#shadow)" />
              <text x="-410" y="-12" textAnchor="end" fontSize="10" fill="#1e293b" fontWeight="700" fontFamily="Inter">11 kV SUBSTATION BUS</text>
              <text x="-410" y="5" textAnchor="end" fontSize="9" fill={color} fontWeight="700" fontFamily="JetBrains Mono">{bus.voltagePU.toFixed(3)} pu</text>
            </g>
          );
        })()}

        {/* ═══════════ FEEDERS ═══════════ */}
        {state.lines.filter(l => l.fromBus === 'sub_bus').map((line, idx) => {
          const feederBuses = ['bus1', 'bus2', 'bus3'];
          const busId = feederBuses[idx];
          const bus = state.buses.find(b => b.id === busId);
          if (!bus) return null;
          const subPos = getPos('sub_bus');
          const busPos = getPos(busId);
          const cb = state.breakers.find(b => b.lineId === line.id);
          const lineColor = getStatusColor(line.status);
          const busColor = getStatusColor(bus.voltageStatus);
          const selLine = isSelected(line.id);
          const selBus = isSelected(busId);
          const selCb = isSelected(cb?.id || '');
          const hovLine = isHovered(line.id);
          const hovBus = isHovered(busId);

          // Midpoint for line label
          const midX = (subPos.x + busPos.x) / 2;
          const midY = (subPos.y + busPos.y) / 2;

          return (
            <g key={line.id}>
              {/* Feeder line */}
              <g
                onClick={(e) => { e.stopPropagation(); onSelectComponent(line.id, 'line'); }}
                onMouseEnter={(e) => handleHover(line.id, 'line', e, getLineTooltip(line))}
                onMouseLeave={handleHoverEnd}
                onContextMenu={(e) => handleContextMenu(e, line.id, 'line')}
                className="cursor-pointer"
              >
                {(selLine || hovLine) && (
                  <line x1={subPos.x} y1={subPos.y} x2={busPos.x} y2={busPos.y}
                    stroke={selLine ? '#2563eb' : '#60a5fa'} strokeWidth="8" opacity="0.3" strokeLinecap="round" />
                )}
                <line x1={subPos.x} y1={subPos.y} x2={busPos.x} y2={busPos.y}
                  stroke={lineColor} strokeWidth="2.5" strokeLinecap="round" />
                {/* Flow animation */}
                {line.pFlow !== 0 && (
                  <>
                    <circle r="3.5" fill={line.flowDirection === 'REVERSE' ? '#f59e0b' : '#3b82f6'} opacity="0.9">
                      <animateMotion dur="1.5s" repeatCount="indefinite"
                        path={line.flowDirection === 'REVERSE'
                          ? `M${busPos.x},${busPos.y} L${subPos.x},${subPos.y}`
                          : `M${subPos.x},${subPos.y} L${busPos.x},${busPos.y}`} />
                    </circle>
                    <circle r="2.5" fill={line.flowDirection === 'REVERSE' ? '#fbbf24' : '#60a5fa'} opacity="0.7">
                      <animateMotion dur="1.5s" repeatCount="indefinite" begin="0.5s"
                        path={line.flowDirection === 'REVERSE'
                          ? `M${busPos.x},${busPos.y} L${subPos.x},${subPos.y}`
                          : `M${subPos.x},${subPos.y} L${busPos.x},${busPos.y}`} />
                    </circle>
                  </>
                )}
              </g>

              {/* Circuit breaker */}
              {cb && (() => {
                const cbX = subPos.x + (busPos.x - subPos.x) * 0.2;
                const cbY = subPos.y + (busPos.y - subPos.y) * 0.2;
                const isOpen = cb.state !== 'CLOSED';
                return (
                  <g
                    transform={`translate(${cbX}, ${cbY})`}
                    onClick={(e) => { e.stopPropagation(); onToggleBreaker?.(cb.id); onSelectComponent(cb.id, 'breaker'); }}
                    onContextMenu={(e) => handleContextMenu(e, cb.id, 'breaker')}
                    className="cursor-pointer"
                  >
                    {(selCb || isHovered(cb.id)) && <rect x="-12" y="-12" width="24" height="24" fill="#dbeafe" stroke="#2563eb" strokeWidth="2" rx="3" opacity="0.6" />}
                    <rect x="-9" y="-9" width="18" height="18" rx="2"
                      fill={isOpen ? '#fef2f2' : 'white'}
                      stroke={isOpen ? '#ef4444' : '#64748b'} strokeWidth="2" filter="url(#shadow)" />
                    {isOpen ? (
                      <line x1="-5" y1="5" x2="5" y2="-5" stroke="#ef4444" strokeWidth="2.5" />
                    ) : (
                      <line x1="-5" y1="0" x2="5" y2="0" stroke="#64748b" strokeWidth="2.5" />
                    )}
                    <text x="14" y="4" fontSize="8" fill="#475569" fontWeight="600" fontFamily="Inter">{cb.name}</text>
                  </g>
                );
              })()}

              {/* Line label */}
              <g transform={`translate(${midX + 15}, ${midY})`}>
                <rect x="-5" y="-12" width="130" height="32" rx="4" fill="white" stroke="#e2e8f0" opacity="0.95" filter="url(#shadow)" />
                <text y="0" fontSize="9" fill="#475569" fontWeight="600" fontFamily="Inter">{line.name}</text>
                <text y="13" fontSize="8" fill="#94a3b8" fontFamily="JetBrains Mono">
                  {line.length}km | {line.current.toFixed(0)}A | {line.losses.toFixed(1)}kW
                </text>
              </g>

              {/* Feeder bus */}
              <g
                transform={`translate(${busPos.x}, ${busPos.y})`}
                onClick={(e) => { e.stopPropagation(); onSelectComponent(busId, 'bus'); }}
                onMouseDown={(e) => startDrag(busId, 'bus', e)}
                onMouseEnter={(e) => handleHover(busId, 'bus', e, getBusTooltip(bus))}
                onMouseLeave={handleHoverEnd}
                onContextMenu={(e) => handleContextMenu(e, busId, 'bus')}
                className="cursor-grab active:cursor-grabbing"
              >
                {(selBus || hovBus) && <rect x="-55" y="-8" width="110" height="16" fill={selBus ? '#dbeafe' : '#eff6ff'} stroke={selBus ? '#2563eb' : '#60a5fa'} strokeWidth="2" strokeDasharray="4 2" rx="3" opacity="0.6" />}
                <rect x="-45" y="-3" width="90" height="6" fill={busColor} rx="2" filter="url(#shadow)" />
                <text y="-12" textAnchor="middle" fontSize="9" fill="#1e293b" fontWeight="700" fontFamily="Inter">FEEDER {idx + 1} BUS</text>
                <text y="18" textAnchor="middle" fontSize="8" fill={busColor} fontWeight="700" fontFamily="JetBrains Mono">{bus.voltagePU.toFixed(3)} pu</text>
              </g>

              {/* Downstream components based on feeder */}
              {renderFeederDownstream(idx, busId, busPos, state, positions, isSelected, isHovered, onSelectComponent, startDrag, handleHover, handleHoverEnd, handleContextMenu, onToggleCapacitor)}
            </g>
          );
        })}
      </svg>

      {/* Tooltip */}
      {tooltip && (
        <div className="fixed z-50 pointer-events-none bg-white rounded-lg border border-slate-200 shadow-xl p-2.5 max-w-xs"
          style={{ left: tooltip.x, top: tooltip.y }}>
          {tooltip.content}
        </div>
      )}

      {/* Context Menu */}
      {contextMenu && (
        <div className="fixed z-50 bg-white rounded-lg border border-slate-200 shadow-xl py-1 min-w-[180px]"
          style={{ left: contextMenu.x, top: contextMenu.y }}>
          {contextMenu.items.map((item, i) => (
            <button key={i} onClick={(e) => { e.stopPropagation(); item.action(); setContextMenu(null); }}
              className={`w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 transition-colors ${
                item.danger ? 'hover:bg-red-50 text-red-600' : 'hover:bg-slate-100 text-slate-700'
              }`}>
              <span>{item.icon}</span>
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

// Helper to render downstream components for each feeder
const renderFeederDownstream = (
  feederIdx: number, busId: string, busPos: Position,
  state: SimulationState, positions: Record<string, Position>,
  isSelected: (id: string) => boolean, isHovered: (id: string) => boolean,
  onSelectComponent: (id: string, type: string) => void,
  startDrag: (id: string, type: string, e: React.MouseEvent) => void,
  handleHover: (id: string, type: string, e: React.MouseEvent, content: React.ReactNode) => void,
  handleHoverEnd: () => void,
  handleContextMenu: (e: React.MouseEvent, id: string, type: string) => void,
  onToggleCapacitor?: (id: string) => void
) => {
  // Map of feeder to downstream components
  const downstreamMap: Record<number, { txId: string; lvBusId: string; loadIds: string[]; pvIds: string[]; batIds: string[]; capIds: string[] }> = {
    0: { txId: 'tx2', lvBusId: 'bus4', loadIds: ['load1', 'load4'], pvIds: ['pv3'], batIds: [], capIds: [] },
    1: { txId: 'tx3', lvBusId: 'bus5', loadIds: ['load2'], pvIds: ['pv1'], batIds: ['bat1'], capIds: [] },
    2: { txId: 'tx4', lvBusId: 'bus6', loadIds: ['load3', 'load5'], pvIds: ['pv2'], batIds: ['bat2'], capIds: ['cap1', 'cap2'] },
  };

  const downstream = downstreamMap[feederIdx];
  if (!downstream) return null;

  const tx = state.transformers.find(t => t.id === downstream.txId);
  const lvBus = state.buses.find(b => b.id === downstream.lvBusId);
  if (!tx || !lvBus) return null;

  // Position for LV bus (offset from feeder bus)
  const lvPos = positions[downstream.lvBusId] || { x: busPos.x - 30, y: busPos.y + 150 };

  return (
    <g>
      {/* Connection to LV bus */}
      <line x1={busPos.x} y1={busPos.y} x2={lvPos.x} y2={lvPos.y - 25} stroke="#475569" strokeWidth="2" />

      {/* Transformer */}
      {(() => {
        const txY = busPos.y + (lvPos.y - busPos.y) * 0.4;
        const color = getStatusColor(tx.status);
        const sel = isSelected(tx.id);
        const hov = isHovered(tx.id);
        return (
          <g
            transform={`translate(${busPos.x - 20}, ${txY})`}
            onClick={(e) => { e.stopPropagation(); onSelectComponent(tx.id, 'transformer'); }}
            onMouseDown={(e) => startDrag(tx.id, 'transformer', e)}
            onMouseEnter={(e) => handleHover(tx.id, 'transformer', e, (
              <div className="text-xs">
                <div className="font-bold text-slate-800 mb-1">{tx.name}</div>
                <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 font-mono text-[10px]">
                  <span className="text-slate-500">Loading:</span><span className="font-bold" style={{ color }}>{tx.loading.toFixed(1)}%</span>
                  <span className="text-slate-500">Rating:</span><span>{tx.ratedPower} kVA</span>
                  <span className="text-slate-500">PF:</span><span>{tx.powerFactor.toFixed(3)}</span>
                  <span className="text-slate-500">Status:</span><span style={{ color }}>{tx.status}</span>
                </div>
              </div>
            ))}
            onMouseLeave={handleHoverEnd}
            onContextMenu={(e) => handleContextMenu(e, tx.id, 'transformer')}
            className="cursor-grab active:cursor-grabbing"
          >
            {(sel || hov) && <circle r="24" fill="none" stroke={sel ? '#2563eb' : '#60a5fa'} strokeWidth="2" strokeDasharray="4 2" opacity="0.6" />}
            <circle cy="-10" r="11" fill={sel ? '#dbeafe' : 'white'} stroke={color} strokeWidth="2" filter="url(#shadow)" />
            <circle cy="10" r="11" fill={sel ? '#dbeafe' : 'white'} stroke={color} strokeWidth="2" filter="url(#shadow)" />
            <text x="-22" y="-8" textAnchor="end" fontSize="8" fill="#475569" fontWeight="600" fontFamily="Inter">{tx.id.toUpperCase()}</text>
            <text x="-22" y="4" textAnchor="end" fontSize="7" fill={color} fontWeight="700" fontFamily="JetBrains Mono">{tx.loading.toFixed(0)}%</text>
          </g>
        );
      })()}

      <line x1={busPos.x - 20} y1={busPos.y + (lvPos.y - busPos.y) * 0.4 + 22} x2={lvPos.x} y2={lvPos.y} stroke="#475569" strokeWidth="2" />

      {/* LV Bus */}
      {(() => {
        const sel = isSelected(lvBus.id);
        const hov = isHovered(lvBus.id);
        const color = getStatusColor(lvBus.voltageStatus);
        return (
          <g
            transform={`translate(${lvPos.x}, ${lvPos.y})`}
            onClick={(e) => { e.stopPropagation(); onSelectComponent(lvBus.id, 'bus'); }}
            onMouseDown={(e) => startDrag(lvBus.id, 'bus', e)}
            onMouseEnter={(e) => handleHover(lvBus.id, 'bus', e, (
              <div className="text-xs">
                <div className="font-bold text-slate-800 mb-1">{lvBus.name}</div>
                <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 font-mono text-[10px]">
                  <span className="text-slate-500">Voltage:</span><span className="font-bold" style={{ color: getStatusColor(lvBus.voltageStatus) }}>{lvBus.voltagePU.toFixed(4)} pu</span>
                  <span className="text-slate-500">P Load:</span><span>{lvBus.pLoad.toFixed(1)} kW</span>
                  <span className="text-slate-500">P Gen:</span><span className="text-emerald-600">{lvBus.pGen.toFixed(1)} kW</span>
                </div>
              </div>
            ))}
            onMouseLeave={handleHoverEnd}
            onContextMenu={(e) => handleContextMenu(e, lvBus.id, 'bus')}
            className="cursor-grab active:cursor-grabbing"
          >
            {(sel || hov) && <rect x="-55" y="-8" width="110" height="16" fill={sel ? '#dbeafe' : '#eff6ff'} stroke={sel ? '#2563eb' : '#60a5fa'} strokeWidth="2" strokeDasharray="4 2" rx="3" opacity="0.6" />}
            <rect x="-45" y="-3" width="90" height="6" fill={color} rx="2" filter="url(#shadow)" />
            <text y="-10" textAnchor="middle" fontSize="8" fill="#1e293b" fontWeight="600" fontFamily="Inter">{lvBus.name}</text>
            <text y="15" textAnchor="middle" fontSize="7" fill={color} fontWeight="700" fontFamily="JetBrains Mono">{lvBus.voltagePU.toFixed(3)} pu</text>
          </g>
        );
      })()}

      {/* Loads on LV bus */}
      {downstream.loadIds.map((loadId, i) => {
        const load = state.loads.find(l => l.id === loadId);
        if (!load) return null;
        const loadPos = { x: lvPos.x - 50 + i * 50, y: lvPos.y + 80 };
        const sel = isSelected(load.id);
        const hov = isHovered(load.id);
        return (
          <g key={load.id}>
            <line x1={lvPos.x - 30 + i * 30} y1={lvPos.y} x2={loadPos.x} y2={loadPos.y - 15} stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 2" />
            <g
              transform={`translate(${loadPos.x}, ${loadPos.y})`}
              onClick={(e) => { e.stopPropagation(); onSelectComponent(load.id, 'load'); }}
              onMouseDown={(e) => startDrag(load.id, 'load', e)}
              onMouseEnter={(e) => handleHover(load.id, 'load', e, (
                <div className="text-xs">
                  <div className="font-bold text-slate-800 mb-1">{load.name}</div>
                  <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 font-mono text-[10px]">
                    <span className="text-slate-500">Type:</span><span>{load.type}</span>
                    <span className="text-slate-500">P:</span><span className="font-bold">{load.pActual.toFixed(1)} kW</span>
                    <span className="text-slate-500">Q:</span><span>{load.qActual.toFixed(1)} kVAR</span>
                    <span className="text-slate-500">PF:</span><span>{load.powerFactor.toFixed(2)}</span>
                  </div>
                </div>
              ))}
              onMouseLeave={handleHoverEnd}
              onContextMenu={(e) => handleContextMenu(e, load.id, 'load')}
              className="cursor-grab active:cursor-grabbing"
            >
              {(sel || hov) && <rect x="-18" y="-18" width="36" height="36" fill={sel ? '#dbeafe' : '#eff6ff'} stroke={sel ? '#2563eb' : '#60a5fa'} strokeWidth="2" strokeDasharray="4 2" rx="3" opacity="0.6" />}
              <polygon points="0,10 -10,-10 10,-10" fill={sel ? '#dbeafe' : 'white'} stroke="#475569" strokeWidth="1.5" filter="url(#shadow)" />
              <text y="22" textAnchor="middle" fontSize="7" fill="#475569" fontWeight="600" fontFamily="Inter">{load.name.length > 12 ? load.name.substring(0, 12) + '..' : load.name}</text>
              <text y="32" textAnchor="middle" fontSize="7" fill="#64748b" fontFamily="JetBrains Mono">{load.pActual.toFixed(0)} kW</text>
            </g>
          </g>
        );
      })}

      {/* Solar PV */}
      {downstream.pvIds.map((pvId, i) => {
        const pv = state.solarPV.find(p => p.id === pvId);
        if (!pv) return null;
        const pvPos = { x: lvPos.x + 30 + i * 40, y: lvPos.y + 80 };
        const sel = isSelected(pv.id);
        const hov = isHovered(pv.id);
        return (
          <g key={pv.id}>
            <line x1={lvPos.x + 20 + i * 30} y1={lvPos.y} x2={pvPos.x} y2={pvPos.y - 15} stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="4 2" />
            <g
              transform={`translate(${pvPos.x}, ${pvPos.y})`}
              onClick={(e) => { e.stopPropagation(); onSelectComponent(pv.id, 'solar'); }}
              onMouseDown={(e) => startDrag(pv.id, 'solar', e)}
              onMouseEnter={(e) => handleHover(pv.id, 'solar', e, (
                <div className="text-xs">
                  <div className="font-bold text-slate-800 mb-1">{pv.name}</div>
                  <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 font-mono text-[10px]">
                    <span className="text-slate-500">Output:</span><span className="font-bold text-amber-600">{pv.currentOutput.toFixed(1)} kW</span>
                    <span className="text-slate-500">Capacity:</span><span>{pv.capacity} kWp</span>
                    <span className="text-slate-500">Irradiance:</span><span>{pv.irradiance.toFixed(0)} W/m²</span>
                    <span className="text-slate-500">Temp:</span><span>{pv.temperature.toFixed(1)}°C</span>
                  </div>
                </div>
              ))}
              onMouseLeave={handleHoverEnd}
              onContextMenu={(e) => handleContextMenu(e, pv.id, 'solar')}
              className="cursor-grab active:cursor-grabbing"
            >
              {(sel || hov) && <rect x="-18" y="-18" width="36" height="36" fill={sel ? '#fef3c7' : '#fefce8'} stroke={sel ? '#d97706' : '#fbbf24'} strokeWidth="2" strokeDasharray="4 2" rx="3" opacity="0.6" />}
              <rect x="-10" y="-10" width="20" height="14" rx="2" fill={sel ? '#fef3c7' : '#fefce8'} stroke="#f59e0b" strokeWidth="1.5" filter="url(#shadow)" />
              <line x1="-5" y1="-10" x2="-5" y2="4" stroke="#f59e0b" strokeWidth="0.5" />
              <line x1="0" y1="-10" x2="0" y2="4" stroke="#f59e0b" strokeWidth="0.5" />
              <line x1="5" y1="-10" x2="5" y2="4" stroke="#f59e0b" strokeWidth="0.5" />
              <line x1="-10" y1="-3" x2="10" y2="-3" stroke="#f59e0b" strokeWidth="0.5" />
              <text y="18" textAnchor="middle" fontSize="7" fill="#92400e" fontWeight="600" fontFamily="Inter">{pv.name.length > 10 ? pv.name.substring(0, 10) + '..' : pv.name}</text>
              <text y="28" textAnchor="middle" fontSize="7" fill="#b45309" fontFamily="JetBrains Mono">{pv.currentOutput.toFixed(0)}/{pv.capacity} kW</text>
            </g>
          </g>
        );
      })}

      {/* Batteries */}
      {downstream.batIds.map((batId, i) => {
        const bat = state.batteries.find(b => b.id === batId);
        if (!bat) return null;
        const batPos = { x: lvPos.x + 80 + i * 40, y: lvPos.y + 80 };
        const sel = isSelected(bat.id);
        const hov = isHovered(bat.id);
        const isCharging = bat.currentPower > 0;
        const isDischarging = bat.currentPower < 0;
        return (
          <g key={bat.id}>
            <line x1={lvPos.x + 40 + i * 30} y1={lvPos.y} x2={batPos.x} y2={batPos.y - 15} stroke="#10b981" strokeWidth="1.5" strokeDasharray="4 2" />
            <g
              transform={`translate(${batPos.x}, ${batPos.y})`}
              onClick={(e) => { e.stopPropagation(); onSelectComponent(bat.id, 'battery'); }}
              onMouseDown={(e) => startDrag(bat.id, 'battery', e)}
              onMouseEnter={(e) => handleHover(bat.id, 'battery', e, (
                <div className="text-xs">
                  <div className="font-bold text-slate-800 mb-1">{bat.name}</div>
                  <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 font-mono text-[10px]">
                    <span className="text-slate-500">SOC:</span><span className="font-bold" style={{ color: bat.soc > 50 ? '#10b981' : bat.soc > 20 ? '#f59e0b' : '#ef4444' }}>{bat.soc.toFixed(1)}%</span>
                    <span className="text-slate-500">Power:</span><span className="font-bold" style={{ color: bat.currentPower < 0 ? '#ef4444' : '#10b981' }}>{bat.currentPower > 0 ? '+' : ''}{bat.currentPower.toFixed(1)} kW</span>
                    <span className="text-slate-500">Mode:</span><span>{bat.mode.replace(/_/g, ' ')}</span>
                    <span className="text-slate-500">Capacity:</span><span>{bat.capacity} kWh</span>
                    <span className="text-slate-500">Status:</span>
                    <span className="font-bold" style={{ 
                      color: bat.soc < 10 ? '#ef4444' : bat.soc < 20 ? '#f59e0b' : '#10b981'
                    }}>
                      {bat.soc < 10 ? 'STOPPED' : bat.soc < 20 ? 'BITS MODE' : 'NORMAL'}
                    </span>
                  </div>
                  {bat.currentPower < 0 && bat.soc < 20 && (
                    <div className="mt-1 pt-1 border-t border-slate-200 text-[9px] text-amber-700">
                      ⚠️ {bat.soc < 10 ? 'Discharge stopped - SOC critical' : 'Discharging in bits - approaching limit'}
                    </div>
                  )}
                </div>
              ))}
              onMouseLeave={handleHoverEnd}
              onContextMenu={(e) => handleContextMenu(e, bat.id, 'battery')}
              className="cursor-grab active:cursor-grabbing"
            >
              {(sel || hov) && <rect x="-20" y="-18" width="40" height="36" fill={sel ? '#d1fae5' : '#ecfdf5'} stroke={sel ? '#059669' : '#34d399'} strokeWidth="2" strokeDasharray="4 2" rx="3" opacity="0.6" />}
              <rect x="-12" y="-10" width="24" height="16" rx="2" fill={sel ? '#d1fae5' : '#ecfdf5'} stroke="#10b981" strokeWidth="1.5" filter="url(#shadow)" />
              <rect x="12" y="-5" width="3" height="6" rx="1" fill="#10b981" />
              <rect x="-10" y="-8" width={Math.max(0, (bat.soc / 100) * 20)} height="12" rx="1"
                fill={bat.soc > 50 ? '#10b981' : bat.soc > 20 ? '#f59e0b' : '#ef4444'} opacity="0.5" />
              {isCharging && <text y="2" textAnchor="middle" fontSize="8" fill="#059669" fontWeight="bold">⬆</text>}
              {isDischarging && <text y="2" textAnchor="middle" fontSize="8" fill="#dc2626" fontWeight="bold">⬇</text>}
              <text y="22" textAnchor="middle" fontSize="7" fill="#065f46" fontWeight="600" fontFamily="Inter">{bat.name}</text>
              <text y="32" textAnchor="middle" fontSize="7" fill="#047857" fontFamily="JetBrains Mono">
                {bat.soc.toFixed(0)}% | {bat.currentPower > 0 ? '+' : ''}{bat.currentPower.toFixed(0)}kW
              </text>
              {/* Safety indicator when discharging in bits */}
              {bat.currentPower < 0 && bat.soc < 20 && (
                <g>
                  <rect x="-15" y="36" width="30" height="12" rx="2" fill="#fef3c7" stroke="#f59e0b" strokeWidth="0.5" />
                  <text y="44" textAnchor="middle" fontSize="6" fill="#92400e" fontWeight="700" fontFamily="Inter">
                    {bat.soc < 10 ? 'STOP' : 'BITS'}
                  </text>
                </g>
              )}
            </g>
          </g>
        );
      })}

      {/* Capacitors on feeder bus */}
      {downstream.capIds.map((capId, i) => {
        const cap = state.capacitors.find(c => c.id === capId);
        if (!cap) return null;
        // Place first cap on feeder bus, second on LV bus
        const isOnFeeder = i === 0;
        const parentPos = isOnFeeder ? busPos : lvPos;
        const capPos = { x: parentPos.x + 60, y: parentPos.y + (isOnFeeder ? 35 : 40) };
        const sel = isSelected(cap.id);
        const hov = isHovered(cap.id);
        return (
          <g key={cap.id}>
            <line x1={parentPos.x + 40} y1={parentPos.y} x2={capPos.x} y2={capPos.y - 10} stroke="#94a3b8" strokeWidth="1.5" />
            <g
              transform={`translate(${capPos.x}, ${capPos.y})`}
              onClick={(e) => { e.stopPropagation(); onToggleCapacitor?.(cap.id); onSelectComponent(cap.id, 'capacitor'); }}
              onMouseEnter={(e) => handleHover(cap.id, 'capacitor', e, (
                <div className="text-xs">
                  <div className="font-bold text-slate-800 mb-1">{cap.name}</div>
                  <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 font-mono text-[10px]">
                    <span className="text-slate-500">State:</span><span className="font-bold" style={{ color: cap.switchedOn ? '#10b981' : '#94a3b8' }}>{cap.switchedOn ? 'ON' : 'OFF'}</span>
                    <span className="text-slate-500">Q:</span><span className="font-bold text-indigo-600">{cap.totalQ} kVAR</span>
                    <span className="text-slate-500">Steps:</span><span>{cap.activeSteps}/{cap.numSteps}</span>
                  </div>
                  <div className="text-[9px] text-slate-400 mt-1 italic">Click to toggle</div>
                </div>
              ))}
              onMouseLeave={handleHoverEnd}
              onContextMenu={(e) => handleContextMenu(e, cap.id, 'capacitor')}
              className="cursor-pointer"
            >
              {(sel || hov) && <rect x="-18" y="-15" width="36" height="30" fill={sel ? '#e0e7ff' : '#eef2ff'} stroke={sel ? '#4338ca' : '#818cf8'} strokeWidth="2" strokeDasharray="4 2" rx="3" opacity="0.6" />}
              <line x1="-8" y1="-3" x2="8" y2="-3" stroke={cap.switchedOn ? '#6366f1' : '#94a3b8'} strokeWidth="2.5" />
              <line x1="-8" y1="3" x2="8" y2="3" stroke={cap.switchedOn ? '#6366f1' : '#94a3b8'} strokeWidth="2.5" />
              <text y="16" textAnchor="middle" fontSize="7" fill="#4338ca" fontWeight="600" fontFamily="Inter">
                {cap.id.toUpperCase()} {cap.switchedOn ? `${cap.totalQ}kVAR` : 'OFF'}
              </text>
            </g>
          </g>
        );
      })}
    </g>
  );
};

export default CircuitView;
