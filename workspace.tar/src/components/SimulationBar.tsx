import React from 'react';
import type { SimulationConfig } from '../engine/types';

interface SimulationBarProps {
  config: SimulationConfig;
  onConfigChange: (config: Partial<SimulationConfig>) => void;
  gridHealth: number;
}

const SimulationBar: React.FC<SimulationBarProps> = ({ config, onConfigChange, gridHealth }) => {
  const currentTime = config.currentTime;
  const hours = Math.floor(currentTime);
  const minutes = Math.floor((currentTime % 1) * 60);
  const timeStr = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;

  const getHealthColor = (h: number) => {
    if (h >= 90) return '#22c55e';
    if (h >= 70) return '#f59e0b';
    if (h >= 50) return '#f97316';
    return '#ef4444';
  };

  const getPeriodLabel = (hour: number) => {
    if (hour >= 5 && hour < 8) return '🌅 Morning';
    if (hour >= 8 && hour < 12) return '☀️ Late Morning';
    if (hour >= 12 && hour < 14) return '🌞 Midday';
    if (hour >= 14 && hour < 17) return '☀️ Afternoon';
    if (hour >= 17 && hour < 20) return '🌇 Evening Peak';
    if (hour >= 20 && hour < 23) return '🌙 Night';
    return '🌑 Late Night';
  };

  return (
    <div className="flex items-center gap-4">
      {/* Time display */}
      <div className="flex items-center gap-2 flex-shrink-0">
        <div className="w-16 h-7 rounded bg-slate-900 flex items-center justify-center">
          <span className="text-white text-xs font-mono font-bold">{timeStr}</span>
        </div>
        <div>
          <div className="text-[10px] text-slate-700 font-semibold">{getPeriodLabel(currentTime)}</div>
        </div>
      </div>

      {/* Playback controls */}
      <div className="flex items-center gap-1 flex-shrink-0">
        <button onClick={() => onConfigChange({ currentTime: 0 })}
          className="w-7 h-7 rounded bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 transition-colors" title="Reset">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M3 12a9 9 0 1 1 9 9M3 12V3m0 9h9" />
          </svg>
        </button>
        <button onClick={() => onConfigChange({ isRunning: !config.isRunning })}
          className={`w-8 h-8 rounded flex items-center justify-center transition-all ${
            config.isRunning ? 'bg-amber-500 text-white hover:bg-amber-600' : 'bg-blue-500 text-white hover:bg-blue-600'
          }`} title={config.isRunning ? 'Pause' : 'Play'}>
          {config.isRunning ? (
            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
              <rect x="6" y="4" width="4" height="16" /><rect x="14" y="4" width="4" height="16" />
            </svg>
          ) : (
            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
              <polygon points="5,3 19,12 5,21" />
            </svg>
          )}
        </button>
        <button onClick={() => {
          const newTime = Math.min(24, currentTime + 0.25);
          onConfigChange({ currentTime: newTime >= 24 ? 0 : newTime });
        }} className="w-7 h-7 rounded bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 transition-colors" title="Step Forward">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
            <polygon points="5,3 15,12 5,21" /><rect x="16" y="3" width="3" height="18" />
          </svg>
        </button>
      </div>

      {/* Speed control */}
      <div className="flex items-center gap-1 flex-shrink-0">
        <span className="text-[9px] text-slate-400 font-semibold uppercase">Speed:</span>
        {[0.5, 1, 2, 5, 10].map(speed => (
          <button key={speed} onClick={() => onConfigChange({ simulationSpeed: speed })}
            className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold transition-all ${
              config.simulationSpeed === speed ? 'bg-blue-500 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
            }`}>
            {speed}×
          </button>
        ))}
      </div>

      {/* Time slider */}
      <div className="flex-1 min-w-[120px]">
        <input type="range" min={0} max={24} step={0.25} value={currentTime}
          onChange={(e) => onConfigChange({ currentTime: parseFloat(e.target.value) })}
          className="w-full h-1.5 bg-slate-200 rounded-full appearance-none cursor-pointer accent-blue-500" />
        <div className="flex justify-between text-[7px] text-slate-400 mt-0.5 px-0.5">
          <span>00:00</span><span>06:00</span><span>12:00</span><span>18:00</span><span>24:00</span>
        </div>
      </div>

      {/* Quick jumps */}
      <div className="flex items-center gap-1 flex-shrink-0">
        {[{ label: '🌅', time: 6 }, { label: '🌞', time: 12 }, { label: '🌇', time: 18 }, { label: '🌙', time: 23 }].map(jump => (
          <button key={jump.time} onClick={() => onConfigChange({ currentTime: jump.time })}
            className="w-6 h-6 rounded bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-xs transition-colors" title={`${jump.time}:00`}>
            {jump.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default SimulationBar;
