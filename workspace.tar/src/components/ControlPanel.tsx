import React, { useState } from 'react';
import type { SimulationState, SimulationConfig, BatteryMode, FaultType, LoadType, Bus, Transformer, Line, Load, SolarPV, Battery, CapacitorBank } from '../engine/types';
import { SCENARIOS } from '../engine/scenarios';
import { getStatusColor } from '../engine/calculations';

interface ControlPanelProps {
  state: SimulationState;
  config: SimulationConfig;
  onConfigChange: (config: Partial<SimulationConfig>) => void;
  onStateChange: (state: Partial<SimulationState>) => void;
  onSelectComponent: (id: string, type: string) => void;
  onApplyScenario: (scenarioId: string) => void;
  onInjectFault: (componentId: string, componentType: string, faultType: FaultType, resistance: number) => void;
  onClearFaults: () => void;
  activePanel: 'inspector' | 'controls' | 'scenarios' | 'faults';
}

// ─────────────────────────────────────────────────────────────────────────────
// INPUT COMPONENTS
// ─────────────────────────────────────────────────────────────────────────────

const Field: React.FC<{ label: string; unit?: string; hint?: string; children: React.ReactNode }> = ({ label, unit, hint, children }) => (
  <div>
    <label className="block text-[10px] font-semibold text-slate-600 uppercase tracking-wide mb-0.5">
      {label} {unit && <span className="text-slate-400 normal-case">({unit})</span>}
    </label>
    {children}
    {hint && <div className="text-[9px] text-slate-400 mt-0.5">{hint}</div>}
  </div>
);

const NumInput: React.FC<{
  value: number; min?: number; max?: number; step?: number;
  onChange: (v: number) => void;
}> = ({ value, min, max, step = 0.01, onChange }) => (
  <input
    type="number"
    value={value}
    min={min}
    max={max}
    step={step}
    onChange={(e) => {
      let v = parseFloat(e.target.value);
      if (isNaN(v)) return;
      if (min !== undefined) v = Math.max(min, v);
      if (max !== undefined) v = Math.min(max, v);
      onChange(v);
    }}
    className="w-full px-2 py-1 text-xs font-mono bg-white border border-slate-300 rounded focus:border-blue-600 focus:outline-none focus:ring-1 focus:ring-blue-600"
  />
);

const TextInput: React.FC<{ value: string; onChange: (v: string) => void }> = ({ value, onChange }) => (
  <input
    type="text"
    value={value}
    onChange={(e) => onChange(e.target.value)}
    className="w-full px-2 py-1 text-xs bg-white border border-slate-300 rounded focus:border-blue-600 focus:outline-none focus:ring-1 focus:ring-blue-600"
  />
);

const SelectInput: React.FC<{
  value: string; options: { value: string; label: string }[];
  onChange: (v: string) => void;
}> = ({ value, options, onChange }) => (
  <select
    value={value}
    onChange={(e) => onChange(e.target.value)}
    className="w-full px-2 py-1 text-xs bg-white border border-slate-300 rounded focus:border-blue-600 focus:outline-none"
  >
    {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
  </select>
);

const Toggle: React.FC<{ value: boolean; onChange: (v: boolean) => void; onLabel?: string; offLabel?: string }> = ({ value, onChange, onLabel = 'ON', offLabel = 'OFF' }) => (
  <button
    onClick={() => onChange(!value)}
    className={`px-3 py-1 text-xs font-semibold rounded border ${
      value ? 'bg-blue-700 text-white border-blue-700' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
    }`}
  >
    {value ? onLabel : offLabel}
  </button>
);

// ─────────────────────────────────────────────────────────────────────────────
// INSPECTOR - EDITABLE CONFIGURATION
// ─────────────────────────────────────────────────────────────────────────────

const Inspector: React.FC<{
  state: SimulationState;
  config: SimulationConfig;
  onStateChange: (state: Partial<SimulationState>) => void;
}> = ({ state, config, onStateChange }) => {
  const selectedId = config.selectedComponent;
  const selectedType = config.selectedComponentType;

  if (!selectedId || !selectedType) {
    return (
      <div className="p-6 text-center">
        <div className="text-slate-400 text-3xl mb-3">⊙</div>
        <div className="text-xs font-semibold text-slate-600 mb-1">No Component Selected</div>
        <div className="text-[10px] text-slate-500">
          Click any component in the Single Line Diagram or Equipment Data table to view and edit its parameters.
        </div>
      </div>
    );
  }

  // ── BUS CONFIGURATION ──
  if (selectedType === 'bus') {
    const bus = state.buses.find(b => b.id === selectedId);
    if (!bus) return null;
    return (
      <div className="p-3 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div>
            <div className="text-xs font-bold text-slate-900">{bus.name}</div>
            <div className="text-[10px] text-slate-500 font-mono">ID: {bus.id} | Type: {bus.type.toUpperCase()}</div>
          </div>
          <StatusBadge status={bus.voltageStatus} />
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Configuration</div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Bus Name"><TextInput value={bus.name} onChange={(v) => updateBus(state, bus.id, { name: v }, onStateChange)} /></Field>
          <Field label="Nominal Voltage" unit="kV">
            <NumInput value={bus.voltage} min={0.1} max={400} step={0.1} onChange={(v) => updateBus(state, bus.id, { voltage: v }, onStateChange)} />
          </Field>
          <Field label="Active Power Load" unit="kW">
            <NumInput value={bus.pLoad} min={0} max={10000} step={1} onChange={(v) => updateBus(state, bus.id, { pLoad: v }, onStateChange)} />
          </Field>
          <Field label="Reactive Power Load" unit="kVAR">
            <NumInput value={bus.qLoad} min={0} max={5000} step={1} onChange={(v) => updateBus(state, bus.id, { qLoad: v }, onStateChange)} />
          </Field>
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Calculated Values (Read-Only)</div>
        <div className="grid grid-cols-2 gap-2">
          <ReadOnlyField label="Voltage" value={`${bus.voltagePU.toFixed(4)} pu`} color={getStatusColor(bus.voltageStatus)} />
          <ReadOnlyField label="Angle" value={`${bus.voltageAngle.toFixed(2)}°`} />
          <ReadOnlyField label="P Generation" value={`${bus.pGen.toFixed(1)} kW`} color="#10b981" />
          <ReadOnlyField label="Q Generation" value={`${bus.qGen.toFixed(1)} kVAR`} />
          <ReadOnlyField label="Status" value={bus.voltageStatus} color={getStatusColor(bus.voltageStatus)} />
        </div>
      </div>
    );
  }

  // ── TRANSFORMER CONFIGURATION ──
  if (selectedType === 'transformer') {
    const tx = state.transformers.find(t => t.id === selectedId);
    if (!tx) return null;
    return (
      <div className="p-3 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div>
            <div className="text-xs font-bold text-slate-900">{tx.name}</div>
            <div className="text-[10px] text-slate-500 font-mono">ID: {tx.id}</div>
          </div>
          <StatusBadge status={tx.status} />
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Configuration</div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Transformer Name"><TextInput value={tx.name} onChange={(v) => updateTx(state, tx.id, { name: v }, onStateChange)} /></Field>
          <Field label="Rated Power" unit="kVA">
            <NumInput value={tx.ratedPower} min={10} max={100000} step={10} onChange={(v) => updateTx(state, tx.id, { ratedPower: v }, onStateChange)} />
          </Field>
          <Field label="Primary Voltage" unit="kV">
            <NumInput value={tx.primaryVoltage} min={0.1} max={400} step={0.1} onChange={(v) => updateTx(state, tx.id, { primaryVoltage: v }, onStateChange)} />
          </Field>
          <Field label="Secondary Voltage" unit="kV">
            <NumInput value={tx.secondaryVoltage} min={0.1} max={400} step={0.1} onChange={(v) => updateTx(state, tx.id, { secondaryVoltage: v }, onStateChange)} />
          </Field>
          <Field label="Impedance" unit="%">
            <NumInput value={tx.impedance} min={0.1} max={30} step={0.1} onChange={(v) => updateTx(state, tx.id, { impedance: v }, onStateChange)} />
          </Field>
          <Field label="Tap Position">
            <NumInput value={tx.tapPosition} min={-tx.numTaps} max={tx.numTaps} step={1} onChange={(v) => updateTx(state, tx.id, { tapPosition: Math.round(v) }, onStateChange)} />
          </Field>
          <Field label="Number of Taps">
            <NumInput value={tx.numTaps} min={1} max={33} step={2} onChange={(v) => updateTx(state, tx.id, { numTaps: Math.round(v) }, onStateChange)} />
          </Field>
          <Field label="Tap Range" unit="%">
            <NumInput value={tx.tapRange} min={1} max={20} step={1} onChange={(v) => updateTx(state, tx.id, { tapRange: v }, onStateChange)} />
          </Field>
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Calculated Values (Read-Only)</div>
        <div className="grid grid-cols-2 gap-2">
          <ReadOnlyField label="Loading" value={`${tx.loading.toFixed(1)}%`} color={getStatusColor(tx.status)} />
          <ReadOnlyField label="P Flow" value={`${tx.currentP.toFixed(1)} kW`} />
          <ReadOnlyField label="Q Flow" value={`${tx.currentQ.toFixed(1)} kVAR`} />
          <ReadOnlyField label="Power Factor" value={tx.powerFactor.toFixed(3)} />
        </div>
      </div>
    );
  }

  // ── LINE CONFIGURATION ──
  if (selectedType === 'line') {
    const line = state.lines.find(l => l.id === selectedId);
    if (!line) return null;
    return (
      <div className="p-3 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div>
            <div className="text-xs font-bold text-slate-900">{line.name}</div>
            <div className="text-[10px] text-slate-500 font-mono">ID: {line.id} | {line.fromBus} → {line.toBus}</div>
          </div>
          <StatusBadge status={line.status} />
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Configuration</div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Line Name"><TextInput value={line.name} onChange={(v) => updateLine(state, line.id, { name: v }, onStateChange)} /></Field>
          <Field label="Length" unit="km">
            <NumInput value={line.length} min={0.01} max={100} step={0.1} onChange={(v) => updateLine(state, line.id, { length: v }, onStateChange)} />
          </Field>
          <Field label="Resistance" unit="Ω/km">
            <NumInput value={line.resistance} min={0.001} max={10} step={0.01} onChange={(v) => updateLine(state, line.id, { resistance: v }, onStateChange)} />
          </Field>
          <Field label="Reactance" unit="Ω/km">
            <NumInput value={line.reactance} min={0.001} max={10} step={0.01} onChange={(v) => updateLine(state, line.id, { reactance: v }, onStateChange)} />
          </Field>
          <Field label="Thermal Rating" unit="A">
            <NumInput value={line.thermalRating} min={10} max={2000} step={10} onChange={(v) => updateLine(state, line.id, { thermalRating: v }, onStateChange)} />
          </Field>
          <Field label="Number of Phases">
            <SelectInput value={String(line.phases)} options={[{ value: '1', label: 'Single Phase' }, { value: '3', label: 'Three Phase' }]}
              onChange={(v) => updateLine(state, line.id, { phases: parseInt(v) }, onStateChange)} />
          </Field>
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Calculated Values (Read-Only)</div>
        <div className="grid grid-cols-2 gap-2">
          <ReadOnlyField label="Current" value={`${line.current.toFixed(1)} A`} />
          <ReadOnlyField label="Loading" value={`${line.loading.toFixed(1)}%`} color={getStatusColor(line.status)} />
          <ReadOnlyField label="P Flow" value={`${line.pFlow.toFixed(1)} kW`} />
          <ReadOnlyField label="Q Flow" value={`${line.qFlow.toFixed(1)} kVAR`} />
          <ReadOnlyField label="Losses" value={`${line.losses.toFixed(2)} kW`} color="#dc2626" />
          <ReadOnlyField label="Voltage Drop" value={`${line.voltageDrop.toFixed(2)}%`} />
          <ReadOnlyField label="Flow Direction" value={line.flowDirection} color={line.flowDirection === 'REVERSE' ? '#d97706' : '#1e40af'} />
        </div>
      </div>
    );
  }

  // ── LOAD CONFIGURATION ──
  if (selectedType === 'load') {
    const load = state.loads.find(l => l.id === selectedId);
    if (!load) return null;
    return (
      <div className="p-3 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div>
            <div className="text-xs font-bold text-slate-900">{load.name}</div>
            <div className="text-[10px] text-slate-500 font-mono">ID: {load.id} | Bus: {load.busId}</div>
          </div>
          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
            load.type === 'RESIDENTIAL' ? 'bg-blue-50 text-blue-700' :
            load.type === 'COMMERCIAL' ? 'bg-purple-50 text-purple-700' :
            'bg-orange-50 text-orange-700'
          }`}>{load.type}</span>
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Configuration</div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Load Name"><TextInput value={load.name} onChange={(v) => updateLoad(state, load.id, { name: v }, onStateChange)} /></Field>
          <Field label="Load Type">
            <SelectInput value={load.type} options={[
              { value: 'RESIDENTIAL', label: 'Residential' },
              { value: 'COMMERCIAL', label: 'Commercial' },
              { value: 'INDUSTRIAL', label: 'Industrial' }
            ]} onChange={(v) => updateLoad(state, load.id, { type: v as LoadType, profileType: v.toLowerCase() }, onStateChange)} />
          </Field>
          <Field label="Nominal Active Power" unit="kW">
            <NumInput value={load.pNominal} min={0} max={5000} step={1} onChange={(v) => updateLoad(state, load.id, { pNominal: v, pActual: v }, onStateChange)} />
          </Field>
          <Field label="Nominal Reactive Power" unit="kVAR">
            <NumInput value={load.qNominal} min={0} max={2000} step={1} onChange={(v) => updateLoad(state, load.id, { qNominal: v, qActual: v }, onStateChange)} />
          </Field>
          <Field label="Power Factor">
            <NumInput value={load.powerFactor} min={0.5} max={1.0} step={0.01} onChange={(v) => updateLoad(state, load.id, { powerFactor: v }, onStateChange)} />
          </Field>
          <Field label="Number of Consumers">
            <NumInput value={load.numConsumers} min={1} max={10000} step={1} onChange={(v) => updateLoad(state, load.id, { numConsumers: Math.round(v) }, onStateChange)} />
          </Field>
          <Field label="Load Profile">
            <SelectInput value={load.profileType} options={[
              { value: 'residential', label: 'Residential' },
              { value: 'commercial', label: 'Commercial' },
              { value: 'industrial', label: 'Industrial' }
            ]} onChange={(v) => updateLoad(state, load.id, { profileType: v }, onStateChange)} />
          </Field>
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Current Operating Point</div>
        <div className="grid grid-cols-2 gap-2">
          <ReadOnlyField label="Actual P" value={`${load.pActual.toFixed(1)} kW`} />
          <ReadOnlyField label="Actual Q" value={`${load.qActual.toFixed(1)} kVAR`} />
          <ReadOnlyField label="Apparent Power" value={`${Math.sqrt(load.pActual ** 2 + load.qActual ** 2).toFixed(1)} kVA`} />
        </div>
      </div>
    );
  }

  // ── SOLAR PV CONFIGURATION ──
  if (selectedType === 'solar') {
    const pv = state.solarPV.find(p => p.id === selectedId);
    if (!pv) return null;
    return (
      <div className="p-3 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div>
            <div className="text-xs font-bold text-slate-900">{pv.name}</div>
            <div className="text-[10px] text-slate-500 font-mono">ID: {pv.id} | Bus: {pv.busId}</div>
          </div>
          <StatusBadge status={pv.status} />
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Configuration</div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="System Name"><TextInput value={pv.name} onChange={(v) => updatePV(state, pv.id, { name: v }, onStateChange)} /></Field>
          <Field label="Installed Capacity" unit="kWp">
            <NumInput value={pv.capacity} min={1} max={10000} step={1} onChange={(v) => updatePV(state, pv.id, { capacity: v }, onStateChange)} />
          </Field>
          <Field label="Irradiance" unit="W/m²">
            <NumInput value={pv.irradiance} min={0} max={1200} step={10} onChange={(v) => updatePV(state, pv.id, { irradiance: v }, onStateChange)} />
          </Field>
          <Field label="Ambient Temperature" unit="°C">
            <NumInput value={pv.temperature} min={-10} max={60} step={0.5} onChange={(v) => updatePV(state, pv.id, { temperature: v }, onStateChange)} />
          </Field>
          <Field label="Panel Efficiency">
            <NumInput value={pv.efficiency} min={0.5} max={1.0} step={0.01} onChange={(v) => updatePV(state, pv.id, { efficiency: v }, onStateChange)} />
          </Field>
          <Field label="Power Factor">
            <NumInput value={pv.powerFactor} min={0.5} max={1.0} step={0.01} onChange={(v) => updatePV(state, pv.id, { powerFactor: v }, onStateChange)} />
          </Field>
          <Field label="Inverter Rating" unit="kVA">
            <NumInput value={pv.inverterRating} min={1} max={10000} step={1} onChange={(v) => updatePV(state, pv.id, { inverterRating: v }, onStateChange)} />
          </Field>
          <Field label="Curtailment" unit="%">
            <NumInput value={pv.curtailment} min={0} max={100} step={1} onChange={(v) => updatePV(state, pv.id, { curtailment: v }, onStateChange)} />
          </Field>
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Calculated Output</div>
        <div className="grid grid-cols-2 gap-2">
          <ReadOnlyField label="Current Output" value={`${pv.currentOutput.toFixed(1)} kW`} color="#d97706" />
          <ReadOnlyField label="Utilization" value={`${(pv.currentOutput / pv.capacity * 100).toFixed(1)}%`} />
        </div>
      </div>
    );
  }

  // ── BATTERY CONFIGURATION ──
  if (selectedType === 'battery') {
    const bat = state.batteries.find(b => b.id === selectedId);
    if (!bat) return null;
    return (
      <div className="p-3 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div>
            <div className="text-xs font-bold text-slate-900">{bat.name}</div>
            <div className="text-[10px] text-slate-500 font-mono">ID: {bat.id} | Bus: {bat.busId}</div>
          </div>
          <StatusBadge status={bat.status} />
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Configuration</div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Battery Name"><TextInput value={bat.name} onChange={(v) => updateBat(state, bat.id, { name: v }, onStateChange)} /></Field>
          <Field label="Capacity" unit="kWh">
            <NumInput value={bat.capacity} min={1} max={10000} step={1} onChange={(v) => updateBat(state, bat.id, { capacity: v }, onStateChange)} />
          </Field>
          <Field label="State of Charge" unit="%">
            <NumInput value={bat.soc} min={0} max={100} step={0.5} onChange={(v) => updateBat(state, bat.id, { soc: v }, onStateChange)} />
          </Field>
          <Field label="Round-Trip Efficiency">
            <NumInput value={bat.efficiency} min={0.5} max={1.0} step={0.01} onChange={(v) => updateBat(state, bat.id, { efficiency: v }, onStateChange)} />
          </Field>
          <Field label="Max Charge Power" unit="kW">
            <NumInput value={bat.maxChargePower} min={0} max={5000} step={1} onChange={(v) => updateBat(state, bat.id, { maxChargePower: v }, onStateChange)} />
          </Field>
          <Field label="Max Discharge Power" unit="kW">
            <NumInput value={bat.maxDischargePower} min={0} max={5000} step={1} onChange={(v) => updateBat(state, bat.id, { maxDischargePower: v }, onStateChange)} />
          </Field>
          <Field label="SOC Minimum Limit" unit="%">
            <NumInput value={bat.socMin} min={0} max={50} step={1} onChange={(v) => updateBat(state, bat.id, { socMin: v }, onStateChange)} />
          </Field>
          <Field label="SOC Maximum Limit" unit="%">
            <NumInput value={bat.socMax} min={50} max={100} step={1} onChange={(v) => updateBat(state, bat.id, { socMax: v }, onStateChange)} />
          </Field>
          <Field label="Operating Mode">
            <SelectInput value={bat.mode} options={[
              { value: 'MANUAL', label: 'Manual' },
              { value: 'PEAK_SHAVING', label: 'Peak Shaving' },
              { value: 'SOLAR_SELF_CONSUMPTION', label: 'Solar Self-Consumption' },
              { value: 'GRID_SUPPORT', label: 'Grid Support' },
              { value: 'LOAD_FOLLOWING', label: 'Load Following' }
            ]} onChange={(v) => updateBat(state, bat.id, { mode: v as BatteryMode }, onStateChange)} />
          </Field>
          <Field label="Manual Power Setpoint" unit="kW" hint="Positive = charge, Negative = discharge">
            <NumInput value={bat.currentPower} min={-bat.maxDischargePower} max={bat.maxChargePower} step={1} onChange={(v) => updateBat(state, bat.id, { currentPower: v }, onStateChange)} />
          </Field>
        </div>

        {/* BITS Mode Status */}
        <div className={`rounded border p-2 ${
          bat.soc < 10 ? 'bg-red-50 border-red-200' :
          bat.soc < 20 ? 'bg-amber-50 border-amber-200' :
          'bg-emerald-50 border-emerald-200'
        }`}>
          <div className="text-[10px] font-bold uppercase tracking-wide mb-1" style={{
            color: bat.soc < 10 ? '#991b1b' : bat.soc < 20 ? '#92400e' : '#065f46'
          }}>
            {bat.soc < 10 ? '🛑 DISCHARGE STOPPED' : bat.soc < 20 ? '⚡ BITS MODE ACTIVE' : '✅ NORMAL OPERATION'}
          </div>
          <div className="text-[9px] text-slate-600">
            {bat.soc < 10
              ? `SOC at ${bat.soc.toFixed(1)}% (below ${bat.socMin}% critical limit) - All discharge blocked to protect battery`
              : bat.soc < 20
              ? `Discharge power reduced to ${((bat.soc - 10) / 10 * 100).toFixed(0)}% of maximum. Effective max discharge: ${(bat.maxDischargePower * (bat.soc - 10) / 10).toFixed(0)} kW`
              : `SOC above safe threshold (20%). Full discharge power of ${bat.maxDischargePower} kW available.`}
          </div>
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Current State</div>
        <div className="grid grid-cols-2 gap-2">
          <ReadOnlyField label="Current Power" value={`${bat.currentPower > 0 ? '+' : ''}${bat.currentPower.toFixed(1)} kW`} color={bat.currentPower < 0 ? '#dc2626' : '#10b981'} />
          <ReadOnlyField label="Energy Available" value={`${(bat.soc / 100 * bat.capacity).toFixed(1)} kWh`} />
          <ReadOnlyField label="Voltage" value={`${bat.voltage} V`} />
          <ReadOnlyField label="Current" value={`${bat.current.toFixed(1)} A`} />
        </div>

        {/* Quick Actions - Clear/Reset Battery */}
        <div className="pt-3 border-t border-slate-200">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide mb-2">Quick Actions</div>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => updateBat(state, bat.id, { soc: 0, currentPower: 0 }, onStateChange)}
              className="px-2 py-1.5 text-[10px] font-semibold bg-red-50 text-red-700 border border-red-200 rounded hover:bg-red-100 transition-colors"
              title="Instantly discharge battery to 0%"
            >
              🗑️ Clear to 0%
            </button>
            <button
              onClick={() => updateBat(state, bat.id, { soc: 100, currentPower: 0 }, onStateChange)}
              className="px-2 py-1.5 text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded hover:bg-emerald-100 transition-colors"
              title="Instantly charge battery to 100%"
            >
              🔋 Charge to 100%
            </button>
            <button
              onClick={() => updateBat(state, bat.id, { soc: 50, currentPower: 0 }, onStateChange)}
              className="px-2 py-1.5 text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200 rounded hover:bg-blue-100 transition-colors"
              title="Reset battery to default 50%"
            >
              🔄 Reset to 50%
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── CAPACITOR CONFIGURATION ──
  if (selectedType === 'capacitor') {
    const cap = state.capacitors.find(c => c.id === selectedId);
    if (!cap) return null;
    return (
      <div className="p-3 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div>
            <div className="text-xs font-bold text-slate-900">{cap.name}</div>
            <div className="text-[10px] text-slate-500 font-mono">ID: {cap.id} | Bus: {cap.busId}</div>
          </div>
          <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${cap.switchedOn ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
            {cap.switchedOn ? 'ONLINE' : 'OFFLINE'}
          </span>
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Configuration</div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Capacitor Name"><TextInput value={cap.name} onChange={(v) => updateCap(state, cap.id, { name: v }, onStateChange)} /></Field>
          <Field label="Number of Steps">
            <NumInput value={cap.numSteps} min={1} max={12} step={1} onChange={(v) => updateCap(state, cap.id, { numSteps: Math.round(v) }, onStateChange)} />
          </Field>
          <Field label="Step Size" unit="kVAR">
            <NumInput value={cap.stepSize} min={5} max={500} step={5} onChange={(v) => updateCap(state, cap.id, { stepSize: v }, onStateChange)} />
          </Field>
          <Field label="Active Steps">
            <NumInput value={cap.activeSteps} min={0} max={cap.numSteps} step={1} onChange={(v) => updateCap(state, cap.id, { activeSteps: Math.min(Math.round(v), cap.numSteps), totalQ: Math.min(Math.round(v), cap.numSteps) * cap.stepSize }, onStateChange)} />
          </Field>
          <Field label="Switching State">
            <Toggle value={cap.switchedOn} onChange={(v) => updateCap(state, cap.id, { switchedOn: v, activeSteps: v ? cap.numSteps : 0, totalQ: v ? cap.numSteps * cap.stepSize : 0 }, onStateChange)} />
          </Field>
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Current Output</div>
        <div className="grid grid-cols-2 gap-2">
          <ReadOnlyField label="Reactive Power" value={`${cap.totalQ} kVAR`} color="#4338ca" />
          <ReadOnlyField label="Max Compensation" value={`${cap.numSteps * cap.stepSize} kVAR`} />
        </div>
      </div>
    );
  }

  // ── BREAKER CONFIGURATION ──
  if (selectedType === 'breaker') {
    const cb = state.breakers.find(b => b.id === selectedId);
    if (!cb) return null;
    return (
      <div className="p-3 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-slate-200">
          <div>
            <div className="text-xs font-bold text-slate-900">{cb.name}</div>
            <div className="text-[10px] text-slate-500 font-mono">ID: {cb.id} | Line: {cb.lineId}</div>
          </div>
          <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${cb.state === 'CLOSED' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
            {cb.state}
          </span>
        </div>

        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Configuration</div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Breaker Name"><TextInput value={cb.name} onChange={(v) => updateBreaker(state, cb.id, { name: v }, onStateChange)} /></Field>
          <Field label="Rated Current" unit="A">
            <NumInput value={cb.ratedCurrent} min={10} max={5000} step={10} onChange={(v) => updateBreaker(state, cb.id, { ratedCurrent: v }, onStateChange)} />
          </Field>
          <Field label="Trip Current" unit="A">
            <NumInput value={cb.tripCurrent} min={10} max={10000} step={10} onChange={(v) => updateBreaker(state, cb.id, { tripCurrent: v }, onStateChange)} />
          </Field>
          <Field label="Trip Time" unit="ms">
            <NumInput value={cb.tripTime} min={10} max={5000} step={10} onChange={(v) => updateBreaker(state, cb.id, { tripTime: v }, onStateChange)} />
          </Field>
          <Field label="Breaker State">
            <Toggle value={cb.state === 'CLOSED'} onChange={(v) => updateBreaker(state, cb.id, { state: v ? 'CLOSED' : 'OPEN' }, onStateChange)} onLabel="CLOSED" offLabel="OPEN" />
          </Field>
        </div>
      </div>
    );
  }

  return <div className="p-4 text-xs text-slate-500">Unknown component type: {selectedType}</div>;
};

// ─────────────────────────────────────────────────────────────────────────────
// UPDATE HELPERS
// ─────────────────────────────────────────────────────────────────────────────

function updateBus(state: SimulationState, id: string, changes: Partial<Bus>, onStateChange: (s: Partial<SimulationState>) => void) {
  onStateChange({ buses: state.buses.map(b => b.id === id ? { ...b, ...changes } : b) });
}
function updateTx(state: SimulationState, id: string, changes: Partial<Transformer>, onStateChange: (s: Partial<SimulationState>) => void) {
  onStateChange({ transformers: state.transformers.map(t => t.id === id ? { ...t, ...changes } : t) });
}
function updateLine(state: SimulationState, id: string, changes: Partial<Line>, onStateChange: (s: Partial<SimulationState>) => void) {
  onStateChange({ lines: state.lines.map(l => l.id === id ? { ...l, ...changes } : l) });
}
function updateLoad(state: SimulationState, id: string, changes: Partial<Load>, onStateChange: (s: Partial<SimulationState>) => void) {
  const newLoads = state.loads.map(l => l.id === id ? { ...l, ...changes } : l);
  const newBuses = state.buses.map(bus => {
    const busLoads = newLoads.filter(l => l.busId === bus.id);
    return { ...bus, pLoad: busLoads.reduce((s, l) => s + l.pActual, 0), qLoad: busLoads.reduce((s, l) => s + l.qActual, 0) };
  });
  onStateChange({ loads: newLoads, buses: newBuses });
}
function updatePV(state: SimulationState, id: string, changes: Partial<SolarPV>, onStateChange: (s: Partial<SimulationState>) => void) {
  onStateChange({ solarPV: state.solarPV.map(p => p.id === id ? { ...p, ...changes } : p) });
}
function updateBat(state: SimulationState, id: string, changes: Partial<Battery>, onStateChange: (s: Partial<SimulationState>) => void) {
  onStateChange({ batteries: state.batteries.map(b => b.id === id ? { ...b, ...changes } : b) });
}
function updateCap(state: SimulationState, id: string, changes: Partial<CapacitorBank>, onStateChange: (s: Partial<SimulationState>) => void) {
  onStateChange({ capacitors: state.capacitors.map(c => c.id === id ? { ...c, ...changes } : c) });
}
function updateBreaker(state: SimulationState, id: string, changes: any, onStateChange: (s: Partial<SimulationState>) => void) {
  onStateChange({ breakers: state.breakers.map(b => b.id === id ? { ...b, ...changes } : b) });
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED UI COMPONENTS
// ─────────────────────────────────────────────────────────────────────────────

const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const color = getStatusColor(status as any);
  return (
    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase" style={{ background: `${color}20`, color }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
      {status}
    </span>
  );
};

const ReadOnlyField: React.FC<{ label: string; value: string; color?: string }> = ({ label, value, color }) => (
  <div className="bg-slate-50 rounded px-2 py-1.5 border border-slate-100">
    <div className="text-[9px] text-slate-500 uppercase tracking-wider font-semibold">{label}</div>
    <div className="text-[11px] font-mono font-bold mt-0.5" style={{ color: color || '#1e293b' }}>{value}</div>
  </div>
);

// ─────────────────────────────────────────────────────────────────────────────
// CONTROLS PANEL
// ─────────────────────────────────────────────────────────────────────────────

const Controls: React.FC<{
  state: SimulationState;
  config: SimulationConfig;
  onConfigChange: (config: Partial<SimulationConfig>) => void;
  onStateChange: (state: Partial<SimulationState>) => void;
}> = ({ state, config, onConfigChange, onStateChange }) => (
  <div className="p-3 space-y-3">
    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Grid Parameters</div>
    <div className="grid grid-cols-2 gap-2">
      <Field label="Grid Voltage" unit="kV">
        <NumInput value={config.gridVoltage} min={20} max={400} step={0.5} onChange={(v) => onConfigChange({ gridVoltage: v })} />
      </Field>
      <Field label="System Frequency" unit="Hz">
        <NumInput value={config.gridFrequency} min={48} max={52} step={0.01} onChange={(v) => onConfigChange({ gridFrequency: v })} />
      </Field>
      <Field label="Short Circuit MVA">
        <NumInput value={config.gridShortCircuitMVA} min={50} max={1000} step={10} onChange={(v) => onConfigChange({ gridShortCircuitMVA: v })} />
      </Field>
    </div>

    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Global Load Scaling</div>
    <Field label="Load Multiplier" unit="×" hint="Scale all loads proportionally">
      <NumInput value={1.0} min={0.1} max={3.0} step={0.05} onChange={(v) => {
        const newLoads = state.loads.map(l => ({ ...l, pActual: l.pNominal * v, qActual: l.qNominal * v }));
        const newBuses = state.buses.map(bus => {
          const busLoads = newLoads.filter(l => l.busId === bus.id);
          return { ...bus, pLoad: busLoads.reduce((s, l) => s + l.pActual, 0), qLoad: busLoads.reduce((s, l) => s + l.qActual, 0) };
        });
        onStateChange({ loads: newLoads, buses: newBuses });
      }} />
    </Field>

    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Global Solar Irradiance</div>
    <Field label="Irradiance" unit="W/m²" hint="Override all PV system irradiance">
      <NumInput value={state.solarPV[0]?.irradiance || 800} min={0} max={1200} step={10} onChange={(v) => {
        onStateChange({ solarPV: state.solarPV.map(pv => ({ ...pv, irradiance: v })) });
      }} />
    </Field>

    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Global Battery Mode</div>
    <Field label="Set All Batteries To">
      <SelectInput value={state.batteries[0]?.mode || 'MANUAL'} options={[
        { value: 'MANUAL', label: 'Manual' },
        { value: 'PEAK_SHAVING', label: 'Peak Shaving' },
        { value: 'SOLAR_SELF_CONSUMPTION', label: 'Solar Self-Consumption' },
        { value: 'GRID_SUPPORT', label: 'Grid Support' },
        { value: 'LOAD_FOLLOWING', label: 'Load Following' }
      ]} onChange={(v) => onStateChange({ batteries: state.batteries.map(b => ({ ...b, mode: v as BatteryMode })) })} />
    </Field>

    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Global Battery Actions</div>
    <div className="grid grid-cols-3 gap-2">
      <button
        onClick={() => onStateChange({ batteries: state.batteries.map(b => ({ ...b, soc: 0, currentPower: 0 })) })}
        className="px-2 py-2 text-[10px] font-semibold bg-red-50 text-red-700 border border-red-200 rounded hover:bg-red-100 transition-colors"
        title="Instantly discharge all batteries to 0%"
      >
        🗑️ Clear All
      </button>
      <button
        onClick={() => onStateChange({ batteries: state.batteries.map(b => ({ ...b, soc: 100, currentPower: 0 })) })}
        className="px-2 py-2 text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded hover:bg-emerald-100 transition-colors"
        title="Instantly charge all batteries to 100%"
      >
        🔋 Charge All
      </button>
      <button
        onClick={() => onStateChange({ batteries: state.batteries.map(b => ({ ...b, soc: 50, currentPower: 0 })) })}
        className="px-2 py-2 text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200 rounded hover:bg-blue-100 transition-colors"
        title="Reset all batteries to 50%"
      >
        🔄 Reset All
      </button>
    </div>

    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Capacitor Banks</div>
    {state.capacitors.map(cap => (
      <div key={cap.id} className="flex items-center justify-between bg-slate-50 rounded px-2 py-1.5 border border-slate-100">
        <div>
          <div className="text-[10px] font-semibold text-slate-700">{cap.name}</div>
          <div className="text-[9px] text-slate-500 font-mono">{cap.activeSteps}/{cap.numSteps} steps | {cap.totalQ} kVAR</div>
        </div>
        <Toggle value={cap.switchedOn} onChange={(v) => onStateChange({
          capacitors: state.capacitors.map(c => c.id === cap.id ? { ...c, switchedOn: v, activeSteps: v ? c.numSteps : 0, totalQ: v ? c.numSteps * c.stepSize : 0 } : c)
        })} />
      </div>
    ))}
  </div>
);

// ─────────────────────────────────────────────────────────────────────────────
// SCENARIOS PANEL
// ─────────────────────────────────────────────────────────────────────────────

const Scenarios: React.FC<{ onApplyScenario: (id: string) => void }> = ({ onApplyScenario }) => (
  <div className="p-3 space-y-1.5">
    <div className="text-[10px] text-slate-500 mb-2">Select a predefined scenario to configure the network:</div>
    {SCENARIOS.map(scenario => (
      <button key={scenario.id} onClick={() => onApplyScenario(scenario.id)}
        className="w-full text-left px-2.5 py-2 rounded bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 transition-colors">
        <div className="flex items-center gap-2">
          <span className="text-base">{scenario.icon}</span>
          <div className="flex-1 min-w-0">
            <div className="text-[11px] font-semibold text-slate-700">{scenario.name}</div>
            <div className="text-[9px] text-slate-500 truncate">{scenario.description}</div>
          </div>
        </div>
      </button>
    ))}
  </div>
);

// ─────────────────────────────────────────────────────────────────────────────
// FAULTS PANEL
// ─────────────────────────────────────────────────────────────────────────────

const Faults: React.FC<{
  state: SimulationState;
  onInjectFault: (componentId: string, componentType: string, faultType: FaultType, resistance: number) => void;
  onClearFaults: () => void;
}> = ({ state, onInjectFault, onClearFaults }) => {
  const [faultComponent, setFaultComponent] = useState('line3');
  const [faultType, setFaultType] = useState<FaultType>('LLL');
  const [faultResistance, setFaultResistance] = useState(0.5);

  return (
    <div className="p-3 space-y-3">
      <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Fault Injection</div>
      <div className="space-y-2">
        <Field label="Target Component">
          <select value={faultComponent} onChange={(e) => setFaultComponent(e.target.value)}
            className="w-full px-2 py-1 text-xs bg-white border border-slate-300 rounded">
            <optgroup label="Lines">{state.lines.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}</optgroup>
            <optgroup label="Buses">{state.buses.filter(b => b.type !== 'source').map(b => <option key={b.id} value={b.id}>{b.name}</option>)}</optgroup>
            <optgroup label="Transformers">{state.transformers.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</optgroup>
          </select>
        </Field>
        <Field label="Fault Type">
          <select value={faultType} onChange={(e) => setFaultType(e.target.value as FaultType)}
            className="w-full px-2 py-1 text-xs bg-white border border-slate-300 rounded">
            <option value="SLG">Single Line-to-Ground (SLG)</option>
            <option value="LL">Line-to-Line (LL)</option>
            <option value="DLG">Double Line-to-Ground (DLG)</option>
            <option value="LLL">Three-Phase (LLL)</option>
            <option value="HIF">High Impedance (HIF)</option>
          </select>
        </Field>
        <Field label="Fault Resistance" unit="Ω">
          <NumInput value={faultResistance} min={0.01} max={100} step={0.1} onChange={setFaultResistance} />
        </Field>
        <div className="flex gap-2 pt-2">
          <button onClick={() => {
            const isLine = state.lines.some(l => l.id === faultComponent);
            const isBus = state.buses.some(b => b.id === faultComponent);
            onInjectFault(faultComponent, isLine ? 'line' : isBus ? 'bus' : 'transformer', faultType, faultResistance);
          }} className="flex-1 px-3 py-1.5 rounded bg-red-700 text-white text-xs font-semibold hover:bg-red-800">
            Inject Fault
          </button>
          <button onClick={onClearFaults} className="px-3 py-1.5 rounded bg-slate-100 text-slate-700 text-xs font-semibold hover:bg-slate-200 border border-slate-300">
            Clear
          </button>
        </div>
      </div>

      {state.faults.filter(f => f.active).length > 0 && (
        <div className="mt-4 p-2.5 rounded bg-red-50 border border-red-200">
          <div className="text-[10px] font-bold text-red-900 mb-1.5">⚠ Active Faults</div>
          {state.faults.filter(f => f.active).map(fault => (
            <div key={fault.id} className="text-[10px] text-red-700 font-mono space-y-0.5">
              <div>Type: {fault.faultType} | R: {fault.faultResistance}Ω</div>
              <div>Fault Current: {fault.faultCurrent.toFixed(0)} A</div>
              <div>Component: {fault.componentId}</div>
            </div>
          ))}
        </div>
      )}

      <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide pt-2">Protection Status</div>
      <div className="space-y-1">
        {state.breakers.map(cb => (
          <div key={cb.id} className="flex items-center justify-between bg-slate-50 rounded px-2 py-1.5 border border-slate-100">
            <span className="text-[10px] font-semibold text-slate-700">{cb.name}</span>
            <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${
              cb.state === 'CLOSED' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
            }`}>{cb.state}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// MAIN CONTROL PANEL
// ─────────────────────────────────────────────────────────────────────────────

const ControlPanel: React.FC<ControlPanelProps> = ({
  state, config, onConfigChange, onStateChange, onSelectComponent, onApplyScenario, onInjectFault, onClearFaults, activePanel
}) => {
  return (
    <div className="h-full flex flex-col">
      <div className="flex-1 overflow-auto">
        {activePanel === 'inspector' && <Inspector state={state} config={config} onStateChange={onStateChange} />}
        {activePanel === 'controls' && <Controls state={state} config={config} onConfigChange={onConfigChange} onStateChange={onStateChange} />}
        {activePanel === 'scenarios' && <Scenarios onApplyScenario={onApplyScenario} />}
        {activePanel === 'faults' && <Faults state={state} onInjectFault={onInjectFault} onClearFaults={onClearFaults} />}
      </div>
    </div>
  );
};

export default ControlPanel;
