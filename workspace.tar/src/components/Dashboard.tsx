import React from 'react';
import type { SimulationState } from '../engine/types';
import { getHealthColor } from '../engine/calculations';

interface DashboardProps {
  state: SimulationState;
}

const PremiumKPI: React.FC<{
  label: string;
  value: string;
  unit: string;
  icon: string;
  color?: string;
  trend?: 'up' | 'down' | 'stable';
}> = ({ label, value, unit, icon, color = '#3b82f6', trend = 'stable' }) => (
  <div className="group relative overflow-hidden rounded-2xl bg-white border border-slate-200/60 p-4 shadow-sm hover:shadow-xl hover:scale-105 transition-all duration-300">
    {/* Gradient accent */}
    <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r opacity-80" style={{ background: `linear-gradient(90deg, ${color}, ${color}88)` }} />
    
    {/* Background icon */}
    <div className="absolute -right-4 -bottom-4 text-6xl opacity-5 group-hover:opacity-10 transition-opacity">
      {icon}
    </div>
    
    <div className="relative z-10">
      <div className="flex items-center justify-between mb-2">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl shadow-sm" 
          style={{ background: `linear-gradient(135deg, ${color}20, ${color}10)`, border: `1px solid ${color}30` }}>
          {icon}
        </div>
        {trend && (
          <div className={`text-xs font-bold px-2 py-0.5 rounded-full ${
            trend === 'up' ? 'bg-green-100 text-green-700' :
            trend === 'down' ? 'bg-red-100 text-red-700' :
            'bg-slate-100 text-slate-600'
          }`}>
            {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'}
          </div>
        )}
      </div>
      
      <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">{label}</div>
      <div className="flex items-baseline gap-1">
        <span className="text-2xl font-black text-slate-800 font-mono">{value}</span>
        <span className="text-xs text-slate-500 font-semibold">{unit}</span>
      </div>
    </div>
  </div>
);

const Dashboard: React.FC<DashboardProps> = ({ state }) => {
  const healthColor = getHealthColor(state.gridHealth);
  const activeFaults = state.faults.filter(f => f.active).length;
  const maxTxLoading = Math.max(...state.transformers.map(t => t.loading), 0);
  const reverseFlowLines = state.lines.filter(l => l.flowDirection === 'REVERSE').length;
  const batteryNet = state.batteries.reduce((s, b) => s + b.currentPower, 0);
  const lossPercent = state.totalLoadP > 0 ? (state.totalLossesP / state.totalLoadP) * 100 : 0;

  return (
    <div className="grid grid-cols-6 gap-3">
      <PremiumKPI 
        label="System Load" 
        value={(state.totalLoadP / 1000).toFixed(2)} 
        unit="MW" 
        icon="⚡" 
        color="#3b82f6"
        trend="stable"
      />
      <PremiumKPI 
        label="Solar Generation" 
        value={(state.totalGenP / 1000).toFixed(2)} 
        unit="MW" 
        icon="☀️" 
        color="#f59e0b"
        trend={state.totalGenP > 500 ? 'up' : 'stable'}
      />
      <PremiumKPI 
        label="Battery Power" 
        value={`${batteryNet > 0 ? '+' : ''}${batteryNet.toFixed(0)}`} 
        unit="kW" 
        icon="🔋" 
        color="#10b981"
        trend={batteryNet < 0 ? 'down' : batteryNet > 0 ? 'up' : 'stable'}
      />
      <PremiumKPI 
        label="Grid Import/Export" 
        value={(state.gridImport / 1000).toFixed(2)} 
        unit="MW" 
        icon={state.gridExport > state.gridImport ? '↩️' : '🔌'} 
        color={state.gridExport > state.gridImport ? '#f59e0b' : '#6366f1'}
        trend={state.gridExport > state.gridImport ? 'down' : 'stable'}
      />
      <PremiumKPI 
        label="Total Losses" 
        value={state.totalLossesP.toFixed(1)} 
        unit="kW" 
        icon="📊" 
        color="#ef4444"
        trend={lossPercent > 5 ? 'up' : 'stable'}
      />
      <PremiumKPI 
        label="Min Voltage" 
        value={state.minVoltage.toFixed(3)} 
        unit="pu" 
        icon="📉" 
        color={state.minVoltage < 0.95 ? '#ef4444' : '#22c55e'}
        trend={state.minVoltage < 0.95 ? 'down' : 'stable'}
      />
      
      {/* Grid Health - Special Card */}
      <div className="col-span-6 relative overflow-hidden rounded-2xl bg-gradient-to-br from-white to-slate-50 border border-slate-200/60 p-4 shadow-sm hover:shadow-xl transition-all duration-300">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r" style={{ background: `linear-gradient(90deg, ${healthColor}, ${healthColor}88)` }} />
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6 flex-1">
            {/* Health Score Circle */}
            <div className="relative w-20 h-20 flex-shrink-0">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="#e2e8f0"
                  strokeWidth="3"
                />
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke={healthColor}
                  strokeWidth="3"
                  strokeDasharray={`${state.gridHealth}, 100`}
                  strokeLinecap="round"
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-2xl font-black" style={{ color: healthColor }}>{state.gridHealth}</div>
                  <div className="text-[8px] text-slate-500 font-bold">/100</div>
                </div>
              </div>
            </div>
            
            {/* Health Details */}
            <div className="flex-1">
              <div className="text-sm font-black text-slate-800 mb-1">Grid Health Status</div>
              <div className="text-xs text-slate-600 mb-2">
                {state.gridHealth >= 90 ? 'Excellent - All systems operating normally' :
                 state.gridHealth >= 70 ? 'Good - Minor issues detected' :
                 state.gridHealth >= 50 ? 'Fair - Attention required' :
                 'Poor - Critical issues detected'}
              </div>
              <div className="flex items-center gap-4 text-[10px]">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                  <span className="text-slate-600">TX Loading: <span className="font-bold">{maxTxLoading.toFixed(0)}%</span></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full" style={{ background: state.powerFactor < 0.9 ? '#f59e0b' : '#22c55e' }}></div>
                  <span className="text-slate-600">Power Factor: <span className="font-bold">{state.powerFactor.toFixed(2)}</span></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full" style={{ background: activeFaults > 0 ? '#ef4444' : '#22c55e' }}></div>
                  <span className="text-slate-600">Faults: <span className="font-bold">{activeFaults}</span></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full" style={{ background: reverseFlowLines > 0 ? '#f59e0b' : '#22c55e' }}></div>
                  <span className="text-slate-600">Reverse Flow: <span className="font-bold">{reverseFlowLines}</span></span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Quick Stats */}
          <div className="flex items-center gap-3 pl-6 border-l border-slate-200">
            <div className="text-center">
              <div className="text-2xl font-black text-slate-800">{state.buses.length}</div>
              <div className="text-[9px] text-slate-500 font-bold uppercase">Buses</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-black text-slate-800">{state.lines.length}</div>
              <div className="text-[9px] text-slate-500 font-bold uppercase">Lines</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-black text-slate-800">{state.loads.length}</div>
              <div className="text-[9px] text-slate-500 font-bold uppercase">Loads</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
