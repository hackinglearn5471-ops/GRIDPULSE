import React, { useState } from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from 'recharts';
import type { TimeSeriesPoint, SimulationState } from '../engine/types';

interface ChartsProps {
  timeSeries: TimeSeriesPoint[];
  state: SimulationState;
  currentTime: number;
}

type ChartTab = 'overview' | 'voltage' | 'power' | 'losses' | 'battery';

const Charts: React.FC<ChartsProps> = ({ timeSeries, state, currentTime }) => {
  const [activeTab, setActiveTab] = useState<ChartTab>('overview');

  const currentData = timeSeries.find(p => Math.abs(p.hour - currentTime) < 0.25);

  // Prepare voltage data for all buses
  const busVoltageData = state.buses.map(bus => ({
    name: bus.name.length > 10 ? bus.name.substring(0, 10) : bus.name,
    voltage: bus.voltagePU,
    status: bus.voltageStatus
  }));

  // Prepare loss data
  const lossData = state.lines.map(line => ({
    name: line.name.length > 12 ? line.name.substring(0, 12) : line.name,
    losses: line.losses,
    loading: line.loading
  }));

  const tabs: { id: ChartTab; label: string; icon: string }[] = [
    { id: 'overview', label: 'Overview', icon: '📊' },
    { id: 'voltage', label: 'Voltage', icon: '📉' },
    { id: 'power', label: 'Power', icon: '⚡' },
    { id: 'losses', label: 'Losses', icon: '🔥' },
    { id: 'battery', label: 'Battery', icon: '🔋' }
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border border-slate-200 rounded-lg p-2 shadow-lg text-xs">
          <p className="font-semibold text-slate-700 mb-1">{label}</p>
          {payload.map((p: any, i: number) => (
            <p key={i} style={{ color: p.color }} className="font-mono">
              {p.name}: {typeof p.value === 'number' ? p.value.toFixed(2) : p.value}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  // Sample time series for performance
  const sampledTS = timeSeries.filter((_, i) => i % 2 === 0);

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
      {/* Tab bar */}
      <div className="flex border-b border-slate-100 px-2 pt-2 gap-1">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-3 py-1.5 rounded-t-lg text-xs font-medium transition-all ${
              activeTab === tab.id
                ? 'bg-slate-50 text-slate-800 border-b-2 border-blue-500'
                : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'
            }`}
          >
            <span className="mr-1">{tab.icon}</span>
            {tab.label}
          </button>
        ))}
        {/* Current value indicator */}
        {currentData && (
          <div className="ml-auto flex items-center gap-3 px-3 text-[10px] font-mono text-slate-500">
            <span>Load: <span className="text-blue-600 font-semibold">{currentData.totalLoadP} kW</span></span>
            <span>Solar: <span className="text-amber-600 font-semibold">{currentData.solarGen} kW</span></span>
            <span>Losses: <span className="text-red-500 font-semibold">{currentData.losses} kW</span></span>
          </div>
        )}
      </div>

      {/* Chart area */}
      <div className="p-3 h-[calc(100%-40px)]">
        {activeTab === 'overview' && (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={sampledTS} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="loadGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="solarGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="lossGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="time" tick={{ fontSize: 9, fill: '#94a3b8' }} interval={11} />
              <YAxis tick={{ fontSize: 9, fill: '#94a3b8' }} width={45} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="totalLoadP" name="Load (kW)" stroke="#3b82f6" fill="url(#loadGrad)" strokeWidth={2} />
              <Area type="monotone" dataKey="solarGen" name="Solar (kW)" stroke="#f59e0b" fill="url(#solarGrad)" strokeWidth={2} />
              <Area type="monotone" dataKey="losses" name="Losses (kW)" stroke="#ef4444" fill="url(#lossGrad)" strokeWidth={1.5} />
              {/* Current time marker */}
              <Line type="monotone" dataKey={() => null} stroke="none" />
            </AreaChart>
          </ResponsiveContainer>
        )}

        {activeTab === 'voltage' && (
          <div className="flex gap-3 h-full">
            {/* Time series voltage */}
            <div className="flex-1">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sampledTS} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="time" tick={{ fontSize: 9, fill: '#94a3b8' }} interval={11} />
                  <YAxis domain={[0.88, 1.12]} tick={{ fontSize: 9, fill: '#94a3b8' }} width={40} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="minVoltage" name="Min V (pu)" stroke="#ef4444" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="maxVoltage" name="Max V (pu)" stroke="#f59e0b" strokeWidth={2} dot={false} />
                  {/* Reference lines at 0.95 and 1.05 */}
                </LineChart>
              </ResponsiveContainer>
            </div>
            {/* Bus voltage bars */}
            <div className="w-48">
              <div className="text-[10px] font-medium text-slate-500 mb-1">Bus Voltages (pu)</div>
              <ResponsiveContainer width="100%" height="90%">
                <BarChart data={busVoltageData} layout="vertical" margin={{ top: 0, right: 5, left: 0, bottom: 0 }}>
                  <XAxis type="number" domain={[0.88, 1.12]} tick={{ fontSize: 8, fill: '#94a3b8' }} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 7, fill: '#64748b' }} width={70} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="voltage" fill="#3b82f6" radius={[0, 3, 3, 0]} barSize={10} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {activeTab === 'power' && (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={sampledTS} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="importGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="exportGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="time" tick={{ fontSize: 9, fill: '#94a3b8' }} interval={11} />
              <YAxis tick={{ fontSize: 9, fill: '#94a3b8' }} width={45} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: '10px' }} />
              <Area type="monotone" dataKey="gridImport" name="Grid Import (kW)" stroke="#6366f1" fill="url(#importGrad)" strokeWidth={2} />
              <Area type="monotone" dataKey="gridExport" name="Grid Export (kW)" stroke="#10b981" fill="url(#exportGrad)" strokeWidth={2} />
              <Line type="monotone" dataKey="batteryPower" name="Battery (kW)" stroke="#f59e0b" strokeWidth={1.5} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        )}

        {activeTab === 'losses' && (
          <div className="flex gap-3 h-full">
            <div className="flex-1">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={sampledTS} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="time" tick={{ fontSize: 9, fill: '#94a3b8' }} interval={11} />
                  <YAxis tick={{ fontSize: 9, fill: '#94a3b8' }} width={40} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area type="monotone" dataKey="losses" name="Total Losses (kW)" stroke="#ef4444" fill="#fecaca" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="w-48">
              <div className="text-[10px] font-medium text-slate-500 mb-1">Losses by Line (kW)</div>
              <ResponsiveContainer width="100%" height="90%">
                <BarChart data={lossData} layout="vertical" margin={{ top: 0, right: 5, left: 0, bottom: 0 }}>
                  <XAxis type="number" tick={{ fontSize: 8, fill: '#94a3b8' }} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 7, fill: '#64748b' }} width={75} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="losses" fill="#ef4444" radius={[0, 3, 3, 0]} barSize={10} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {activeTab === 'battery' && (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={sampledTS} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="time" tick={{ fontSize: 9, fill: '#94a3b8' }} interval={11} />
              <YAxis yAxisId="left" tick={{ fontSize: 9, fill: '#94a3b8' }} width={40} />
              <YAxis yAxisId="right" orientation="right" domain={[0, 100]} tick={{ fontSize: 9, fill: '#94a3b8' }} width={35} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: '10px' }} />
              <Line yAxisId="left" type="monotone" dataKey="batteryPower" name="Battery Power (kW)" stroke="#10b981" strokeWidth={2} dot={false} />
              <Line yAxisId="right" type="monotone" dataKey="batterySOC" name="SOC (%)" stroke="#6366f1" strokeWidth={2} dot={false} strokeDasharray="5 5" />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
};

export default Charts;
