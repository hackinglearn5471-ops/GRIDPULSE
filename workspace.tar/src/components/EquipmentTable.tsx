import React, { useState } from 'react';
import type { SimulationState, Bus, Transformer, Line, Load, SolarPV, Battery, CapacitorBank } from '../engine/types';
import { getStatusColor } from '../engine/calculations';

interface EquipmentTableProps {
  state: SimulationState;
  onSelectComponent: (id: string, type: string) => void;
  selectedComponent: string | null;
}

type TableTab = 'buses' | 'transformers' | 'lines' | 'loads' | 'solar' | 'batteries' | 'capacitors';

const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const color = getStatusColor(status as any);
  return (
    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase"
      style={{ background: `${color}18`, color }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
      {status}
    </span>
  );
};

const EquipmentTable: React.FC<EquipmentTableProps> = ({ state, onSelectComponent, selectedComponent }) => {
  const [activeTab, setActiveTab] = useState<TableTab>('buses');

  const tabs: { id: TableTab; label: string; count: number }[] = [
    { id: 'buses', label: 'Buses', count: state.buses.length },
    { id: 'transformers', label: 'Transformers', count: state.transformers.length },
    { id: 'lines', label: 'Lines', count: state.lines.length },
    { id: 'loads', label: 'Loads', count: state.loads.length },
    { id: 'solar', label: 'Solar PV', count: state.solarPV.length },
    { id: 'batteries', label: 'Batteries', count: state.batteries.length },
    { id: 'capacitors', label: 'Capacitors', count: state.capacitors.length }
  ];

  const renderBuses = () => (
    <table className="w-full text-xs">
      <thead>
        <tr className="bg-slate-50 border-b border-slate-200">
          <th className="text-left px-3 py-2 font-semibold text-slate-600">ID</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">Name</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Vnom (kV)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">V (pu)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Angle (°)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">P (kW)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Q (kVAR)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Pgen (kW)</th>
          <th className="text-center px-3 py-2 font-semibold text-slate-600">Status</th>
        </tr>
      </thead>
      <tbody>
        {state.buses.map(bus => (
          <tr key={bus.id} onClick={() => onSelectComponent(bus.id, 'bus')}
            className={`border-b border-slate-100 cursor-pointer transition-colors ${
              selectedComponent === bus.id ? 'bg-blue-50' : 'hover:bg-slate-50'
            }`}>
            <td className="px-3 py-1.5 font-mono text-slate-500">{bus.id}</td>
            <td className="px-3 py-1.5 font-medium text-slate-800">{bus.name}</td>
            <td className="px-3 py-1.5 text-right font-mono">{bus.voltage}</td>
            <td className="px-3 py-1.5 text-right font-mono font-bold" style={{ color: getStatusColor(bus.voltageStatus) }}>
              {bus.voltagePU.toFixed(4)}
            </td>
            <td className="px-3 py-1.5 text-right font-mono">{bus.voltageAngle.toFixed(2)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{bus.pLoad.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{bus.qLoad.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-right font-mono text-emerald-600">{bus.pGen.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-center"><StatusBadge status={bus.voltageStatus} /></td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  const renderTransformers = () => (
    <table className="w-full text-xs">
      <thead>
        <tr className="bg-slate-50 border-b border-slate-200">
          <th className="text-left px-3 py-2 font-semibold text-slate-600">ID</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">Name</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Rating (kVA)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Vpri/Vsec</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Z (%)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Tap</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">P (kW)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Q (kVAR)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">PF</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Loading</th>
          <th className="text-center px-3 py-2 font-semibold text-slate-600">Status</th>
        </tr>
      </thead>
      <tbody>
        {state.transformers.map(tx => (
          <tr key={tx.id} onClick={() => onSelectComponent(tx.id, 'transformer')}
            className={`border-b border-slate-100 cursor-pointer transition-colors ${
              selectedComponent === tx.id ? 'bg-blue-50' : 'hover:bg-slate-50'
            }`}>
            <td className="px-3 py-1.5 font-mono text-slate-500">{tx.id}</td>
            <td className="px-3 py-1.5 font-medium text-slate-800">{tx.name}</td>
            <td className="px-3 py-1.5 text-right font-mono">{tx.ratedPower.toLocaleString()}</td>
            <td className="px-3 py-1.5 text-right font-mono">{tx.primaryVoltage}/{tx.secondaryVoltage}</td>
            <td className="px-3 py-1.5 text-right font-mono">{tx.impedance}</td>
            <td className="px-3 py-1.5 text-right font-mono">{tx.tapPosition > 0 ? '+' : ''}{tx.tapPosition}</td>
            <td className="px-3 py-1.5 text-right font-mono">{tx.currentP.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{tx.currentQ.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{tx.powerFactor.toFixed(3)}</td>
            <td className="px-3 py-1.5 text-right font-mono font-bold" style={{ color: getStatusColor(tx.status) }}>
              {tx.loading.toFixed(1)}%
            </td>
            <td className="px-3 py-1.5 text-center"><StatusBadge status={tx.status} /></td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  const renderLines = () => (
    <table className="w-full text-xs">
      <thead>
        <tr className="bg-slate-50 border-b border-slate-200">
          <th className="text-left px-3 py-2 font-semibold text-slate-600">ID</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">Name</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">From → To</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Length (km)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">R (Ω/km)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">X (Ω/km)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">I (A)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Rating (A)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">P (kW)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Loss (kW)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Vdrop (%)</th>
          <th className="text-center px-3 py-2 font-semibold text-slate-600">Flow</th>
          <th className="text-center px-3 py-2 font-semibold text-slate-600">Status</th>
        </tr>
      </thead>
      <tbody>
        {state.lines.map(line => (
          <tr key={line.id} onClick={() => onSelectComponent(line.id, 'line')}
            className={`border-b border-slate-100 cursor-pointer transition-colors ${
              selectedComponent === line.id ? 'bg-blue-50' : 'hover:bg-slate-50'
            }`}>
            <td className="px-3 py-1.5 font-mono text-slate-500">{line.id}</td>
            <td className="px-3 py-1.5 font-medium text-slate-800">{line.name}</td>
            <td className="px-3 py-1.5 font-mono text-[10px] text-slate-500">{line.fromBus} → {line.toBus}</td>
            <td className="px-3 py-1.5 text-right font-mono">{line.length.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{line.resistance.toFixed(2)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{line.reactance.toFixed(2)}</td>
            <td className="px-3 py-1.5 text-right font-mono font-bold">{line.current.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{line.thermalRating}</td>
            <td className="px-3 py-1.5 text-right font-mono">{line.pFlow.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-right font-mono text-red-600">{line.losses.toFixed(2)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{line.voltageDrop.toFixed(2)}</td>
            <td className="px-3 py-1.5 text-center">
              <span className={`text-[9px] font-bold ${line.flowDirection === 'REVERSE' ? 'text-amber-600' : 'text-blue-600'}`}>
                {line.flowDirection === 'REVERSE' ? '↩ REV' : '→ FWD'}
              </span>
            </td>
            <td className="px-3 py-1.5 text-center"><StatusBadge status={line.status} /></td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  const renderLoads = () => (
    <table className="w-full text-xs">
      <thead>
        <tr className="bg-slate-50 border-b border-slate-200">
          <th className="text-left px-3 py-2 font-semibold text-slate-600">ID</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">Name</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">Bus</th>
          <th className="text-center px-3 py-2 font-semibold text-slate-600">Type</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Pnom (kW)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Pact (kW)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Q (kVAR)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">PF</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Consumers</th>
          <th className="text-center px-3 py-2 font-semibold text-slate-600">Status</th>
        </tr>
      </thead>
      <tbody>
        {state.loads.map(load => (
          <tr key={load.id} onClick={() => onSelectComponent(load.id, 'load')}
            className={`border-b border-slate-100 cursor-pointer transition-colors ${
              selectedComponent === load.id ? 'bg-blue-50' : 'hover:bg-slate-50'
            }`}>
            <td className="px-3 py-1.5 font-mono text-slate-500">{load.id}</td>
            <td className="px-3 py-1.5 font-medium text-slate-800">{load.name}</td>
            <td className="px-3 py-1.5 font-mono text-slate-500">{load.busId}</td>
            <td className="px-3 py-1.5 text-center">
              <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                load.type === 'RESIDENTIAL' ? 'bg-blue-50 text-blue-700' :
                load.type === 'COMMERCIAL' ? 'bg-purple-50 text-purple-700' :
                'bg-orange-50 text-orange-700'
              }`}>{load.type.charAt(0) + load.type.slice(1).toLowerCase()}</span>
            </td>
            <td className="px-3 py-1.5 text-right font-mono">{load.pNominal.toFixed(0)}</td>
            <td className="px-3 py-1.5 text-right font-mono font-bold">{load.pActual.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{load.qActual.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{load.powerFactor.toFixed(2)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{load.numConsumers}</td>
            <td className="px-3 py-1.5 text-center"><StatusBadge status={load.status} /></td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  const renderSolar = () => (
    <table className="w-full text-xs">
      <thead>
        <tr className="bg-slate-50 border-b border-slate-200">
          <th className="text-left px-3 py-2 font-semibold text-slate-600">ID</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">Name</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">Bus</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Cap (kWp)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Output (kW)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Irr (W/m²)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Temp (°C)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Eff (%)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">PF</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Inverter (kVA)</th>
          <th className="text-center px-3 py-2 font-semibold text-slate-600">Status</th>
        </tr>
      </thead>
      <tbody>
        {state.solarPV.map(pv => (
          <tr key={pv.id} onClick={() => onSelectComponent(pv.id, 'solar')}
            className={`border-b border-slate-100 cursor-pointer transition-colors ${
              selectedComponent === pv.id ? 'bg-blue-50' : 'hover:bg-slate-50'
            }`}>
            <td className="px-3 py-1.5 font-mono text-slate-500">{pv.id}</td>
            <td className="px-3 py-1.5 font-medium text-slate-800">{pv.name}</td>
            <td className="px-3 py-1.5 font-mono text-slate-500">{pv.busId}</td>
            <td className="px-3 py-1.5 text-right font-mono">{pv.capacity}</td>
            <td className="px-3 py-1.5 text-right font-mono font-bold text-amber-600">{pv.currentOutput.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{pv.irradiance.toFixed(0)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{pv.temperature.toFixed(1)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{(pv.efficiency * 100).toFixed(0)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{pv.powerFactor.toFixed(2)}</td>
            <td className="px-3 py-1.5 text-right font-mono">{pv.inverterRating}</td>
            <td className="px-3 py-1.5 text-center"><StatusBadge status={pv.status} /></td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  const renderBatteries = () => (
    <table className="w-full text-xs">
      <thead>
        <tr className="bg-slate-50 border-b border-slate-200">
          <th className="text-left px-3 py-2 font-semibold text-slate-600">ID</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">Name</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">Bus</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Cap (kWh)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">SOC (%)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Power (kW)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Max Ch (kW)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Max Dis (kW)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Eff (%)</th>
          <th className="text-center px-3 py-2 font-semibold text-slate-600">Mode</th>
          <th className="text-center px-3 py-2 font-semibold text-slate-600">Status</th>
        </tr>
      </thead>
      <tbody>
        {state.batteries.map(bat => (
          <tr key={bat.id} onClick={() => onSelectComponent(bat.id, 'battery')}
            className={`border-b border-slate-100 cursor-pointer transition-colors ${
              selectedComponent === bat.id ? 'bg-blue-50' : 'hover:bg-slate-50'
            }`}>
            <td className="px-3 py-1.5 font-mono text-slate-500">{bat.id}</td>
            <td className="px-3 py-1.5 font-medium text-slate-800">{bat.name}</td>
            <td className="px-3 py-1.5 font-mono text-slate-500">{bat.busId}</td>
            <td className="px-3 py-1.5 text-right font-mono">{bat.capacity}</td>
            <td className="px-3 py-1.5 text-right font-mono font-bold" style={{ color: bat.soc > 50 ? '#10b981' : bat.soc > 20 ? '#f59e0b' : '#ef4444' }}>
              {bat.soc.toFixed(1)}
            </td>
            <td className="px-3 py-1.5 text-right font-mono font-bold" style={{ color: bat.currentPower < 0 ? '#ef4444' : '#10b981' }}>
              {bat.currentPower > 0 ? '+' : ''}{bat.currentPower.toFixed(1)}
              {bat.currentPower < 0 && bat.soc < 20 && (
                <span className="ml-1 text-[8px] font-normal text-amber-600">
                  {bat.soc < 10 ? '(STOP)' : '(BITS)'}
                </span>
              )}
            </td>
            <td className="px-3 py-1.5 text-right font-mono">{bat.maxChargePower}</td>
            <td className="px-3 py-1.5 text-right font-mono">{bat.maxDischargePower}</td>
            <td className="px-3 py-1.5 text-right font-mono">{(bat.efficiency * 100).toFixed(0)}</td>
            <td className="px-3 py-1.5 text-center">
              <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-50 text-emerald-700">
                {bat.mode.replace(/_/g, ' ')}
              </span>
            </td>
            <td className="px-3 py-1.5 text-center"><StatusBadge status={bat.status} /></td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  const renderCapacitors = () => (
    <table className="w-full text-xs">
      <thead>
        <tr className="bg-slate-50 border-b border-slate-200">
          <th className="text-left px-3 py-2 font-semibold text-slate-600">ID</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">Name</th>
          <th className="text-left px-3 py-2 font-semibold text-slate-600">Bus</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Steps</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Step Size (kVAR)</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Active</th>
          <th className="text-right px-3 py-2 font-semibold text-slate-600">Q (kVAR)</th>
          <th className="text-center px-3 py-2 font-semibold text-slate-600">Switch</th>
          <th className="text-center px-3 py-2 font-semibold text-slate-600">Status</th>
        </tr>
      </thead>
      <tbody>
        {state.capacitors.map(cap => (
          <tr key={cap.id} onClick={() => onSelectComponent(cap.id, 'capacitor')}
            className={`border-b border-slate-100 cursor-pointer transition-colors ${
              selectedComponent === cap.id ? 'bg-blue-50' : 'hover:bg-slate-50'
            }`}>
            <td className="px-3 py-1.5 font-mono text-slate-500">{cap.id}</td>
            <td className="px-3 py-1.5 font-medium text-slate-800">{cap.name}</td>
            <td className="px-3 py-1.5 font-mono text-slate-500">{cap.busId}</td>
            <td className="px-3 py-1.5 text-right font-mono">{cap.numSteps}</td>
            <td className="px-3 py-1.5 text-right font-mono">{cap.stepSize}</td>
            <td className="px-3 py-1.5 text-right font-mono font-bold">{cap.activeSteps}</td>
            <td className="px-3 py-1.5 text-right font-mono font-bold text-indigo-600">{cap.totalQ}</td>
            <td className="px-3 py-1.5 text-center">
              <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${cap.switchedOn ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                {cap.switchedOn ? 'ON' : 'OFF'}
              </span>
            </td>
            <td className="px-3 py-1.5 text-center"><StatusBadge status={cap.status} /></td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  return (
    <div className="h-full flex flex-col">
      {/* Tab bar */}
      <div className="flex-shrink-0 flex border-b border-slate-200 bg-slate-50 px-2 overflow-x-auto">
        {tabs.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`px-3 py-2 text-xs font-semibold whitespace-nowrap border-b-2 transition-all ${
              activeTab === tab.id ? 'border-blue-500 text-blue-700 bg-white' : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}>
            {tab.label}
            <span className="ml-1.5 px-1.5 py-0.5 rounded-full bg-slate-200 text-[9px] font-bold text-slate-600">{tab.count}</span>
          </button>
        ))}
      </div>

      {/* Table content */}
      <div className="flex-1 overflow-auto">
        {activeTab === 'buses' && renderBuses()}
        {activeTab === 'transformers' && renderTransformers()}
        {activeTab === 'lines' && renderLines()}
        {activeTab === 'loads' && renderLoads()}
        {activeTab === 'solar' && renderSolar()}
        {activeTab === 'batteries' && renderBatteries()}
        {activeTab === 'capacitors' && renderCapacitors()}
      </div>

      {/* Summary footer */}
      <div className="flex-shrink-0 px-3 py-2 bg-slate-50 border-t border-slate-200 flex items-center gap-4 text-[10px] text-slate-600 font-mono">
        <span>Total Load: <strong className="text-slate-800">{state.totalLoadP.toFixed(1)} kW</strong></span>
        <span>Total Gen: <strong className="text-emerald-700">{state.totalGenP.toFixed(1)} kW</strong></span>
        <span>Losses: <strong className="text-red-600">{state.totalLossesP.toFixed(2)} kW</strong></span>
        <span>Grid Import: <strong className="text-blue-700">{state.gridImport.toFixed(1)} kW</strong></span>
        <span>Grid Export: <strong className="text-amber-700">{state.gridExport.toFixed(1)} kW</strong></span>
      </div>
    </div>
  );
};

export default EquipmentTable;
