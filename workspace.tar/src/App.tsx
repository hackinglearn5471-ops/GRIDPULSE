import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { SimulationState, SimulationConfig, FaultType, TimeSeriesPoint } from './engine/types';
import { calculatePowerFlow, calculateSolarOutput, calculateBatteryPower, updateBatterySOC } from './engine/calculations';
import { createDefaultNetwork, getDefaultConfig } from './engine/network';
import { generateTimeSeries, getLoadProfileMultiplier, getSolarIrradiance, getTemperature } from './engine/timeSeries';
import { applyScenario, SCENARIOS } from './engine/scenarios';
import CircuitView from './components/CircuitView';
import ControlPanel from './components/ControlPanel';
import EquipmentTable from './components/EquipmentTable';
import SimulationBar from './components/SimulationBar';

type ViewTab = 'sld' | 'data' | 'charts';
type RightPanel = 'inspector' | 'controls' | 'scenarios' | 'faults';

function App() {
  const [state, setState] = useState<SimulationState>(() => createDefaultNetwork());
  const [config, setConfig] = useState<SimulationConfig>(() => getDefaultConfig());
  const [timeSeries, setTimeSeries] = useState<TimeSeriesPoint[]>([]);
  const [solverStatus, setSolverStatus] = useState<{ converged: boolean; message: string }>({ converged: true, message: 'Power flow converged' });
  const [activeView, setActiveView] = useState<ViewTab>('sld');
  const [rightPanel, setRightPanel] = useState<RightPanel>('inspector');
  const [baseline, setBaseline] = useState<SimulationState | null>(null);
  const [history, setHistory] = useState<SimulationState[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [showHelp, setShowHelp] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    setTimeSeries(generateTimeSeries(createDefaultNetwork()));
  }, []);

  const runPowerFlow = useCallback((newState: SimulationState) => {
    try {
      const hour = config.currentTime;
      const updatedLoads = newState.loads.map(load => {
        const multiplier = getLoadProfileMultiplier(load.profileType, hour);
        return { ...load, pActual: load.pNominal * multiplier, qActual: load.qNominal * multiplier };
      });
      const updatedBuses = newState.buses.map(bus => {
        const busLoads = updatedLoads.filter(l => l.busId === bus.id);
        return { ...bus, pLoad: busLoads.reduce((s, l) => s + l.pActual, 0), qLoad: busLoads.reduce((s, l) => s + l.qActual, 0) };
      });
      const irradiance = getSolarIrradiance(hour);
      const temperature = getTemperature(hour);
      const updatedPV = newState.solarPV.map(pv => ({
        ...pv,
        irradiance: pv.irradiance > 0 ? Math.min(1000, irradiance * (pv.irradiance / 800)) : irradiance,
        temperature
      }));
      updatedPV.forEach(pv => { pv.currentOutput = calculateSolarOutput(pv); });
      const totalLoadP = updatedBuses.reduce((s, b) => s + b.pLoad, 0);
      const totalSolarP = updatedPV.reduce((s, pv) => s + pv.currentOutput, 0);
      const netLoad = totalLoadP - totalSolarP;
      const updatedBatteries = newState.batteries.map(bat => {
        const power = calculateBatteryPower(bat, netLoad / newState.batteries.length, totalSolarP / newState.batteries.length);
        const newSOC = updateBatterySOC(bat, power, 0.25);
        return { ...bat, currentPower: power, soc: newSOC };
      });
      const stateForPF: SimulationState = { ...newState, loads: updatedLoads, buses: updatedBuses, solarPV: updatedPV, batteries: updatedBatteries };
      const result = calculatePowerFlow(stateForPF);
      setState(result);
      setSolverStatus({ converged: result.converged, message: result.solverMessage });
    } catch (error) {
      setSolverStatus({ converged: false, message: `Simulation error: ${error instanceof Error ? error.message : 'Unknown error'}` });
    }
  }, [config.currentTime]);

  useEffect(() => {
    if (config.isRunning) {
      intervalRef.current = window.setInterval(() => {
        setConfig(prev => {
          const newTime = prev.currentTime + 0.25 * prev.simulationSpeed;
          return { ...prev, currentTime: newTime >= 24 ? 0 : newTime };
        });
      }, 1000 / config.simulationSpeed);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [config.isRunning, config.simulationSpeed]);

  useEffect(() => { runPowerFlow(state); }, [config.currentTime]);

  const handleConfigChange = useCallback((changes: Partial<SimulationConfig>) => {
    setConfig(prev => ({ ...prev, ...changes }));
  }, []);

  const handleStateChange = useCallback((changes: Partial<SimulationState>) => {
    setState(prev => calculatePowerFlow({ ...prev, ...changes }));
  }, []);

  const handleSelectComponent = useCallback((id: string, type: string) => {
    setConfig(prev => ({
      ...prev,
      selectedComponent: prev.selectedComponent === id ? null : id,
      selectedComponentType: prev.selectedComponent === id ? null : type
    }));
    setRightPanel('inspector');
  }, []);

  const handleApplyScenario = useCallback((scenarioId: string) => {
    const scenario = SCENARIOS.find(s => s.id === scenarioId);
    if (scenario) {
      const newState = applyScenario(state, scenario);
      setState(calculatePowerFlow(newState));
      setConfig(prev => ({ ...prev, currentTime: scenario.timeHour }));
    }
  }, [state]);

  const handleInjectFault = useCallback((componentId: string, componentType: string, faultType: FaultType, resistance: number) => {
    const newFault = {
      id: `fault_${Date.now()}`, componentId,
      componentType: componentType as 'bus' | 'line' | 'transformer',
      faultType, faultResistance: resistance, duration: 500,
      active: true, faultCurrent: 0, startTime: config.currentTime
    };
    setState(prev => calculatePowerFlow({ ...prev, faults: [...prev.faults.filter(f => !f.active), newFault] }));
    setTimeout(() => {
      setState(prev => calculatePowerFlow({ ...prev, faults: prev.faults.map(f => f.id === newFault.id ? { ...f, active: false } : f) }));
    }, 3000);
  }, [config.currentTime]);

  const handleClearFaults = useCallback(() => {
    setState(prev => calculatePowerFlow({ ...prev, faults: prev.faults.map(f => ({ ...f, active: false })) }));
  }, []);

  const handleToggleBreaker = useCallback((id: string) => {
    setState(prev => {
      const newBreakers = prev.breakers.map(cb =>
        cb.id === id ? { ...cb, state: cb.state === 'CLOSED' ? 'OPEN' as const : 'CLOSED' as const } : cb
      );
      return calculatePowerFlow({ ...prev, breakers: newBreakers });
    });
  }, []);

  const handleToggleCapacitor = useCallback((id: string) => {
    setState(prev => {
      const newCaps = prev.capacitors.map(cap =>
        cap.id === id ? { ...cap, switchedOn: !cap.switchedOn, activeSteps: !cap.switchedOn ? cap.numSteps : 0, totalQ: !cap.switchedOn ? cap.numSteps * cap.stepSize : 0 } : cap
      );
      return calculatePowerFlow({ ...prev, capacitors: newCaps });
    });
  }, []);

  const handleDeleteComponent = useCallback((id: string, type: string) => {
    setState(prev => {
      let newState = { ...prev };
      switch (type) {
        case 'load': newState.loads = prev.loads.filter(l => l.id !== id); break;
        case 'solar': newState.solarPV = prev.solarPV.filter(p => p.id !== id); break;
        case 'battery': newState.batteries = prev.batteries.filter(b => b.id !== id); break;
        case 'capacitor': newState.capacitors = prev.capacitors.filter(c => c.id !== id); break;
      }
      return calculatePowerFlow(newState);
    });
  }, []);

  const handleAddComponent = useCallback((type: string) => {
    const lvBuses = state.buses.filter(b => b.voltage <= 1);
    if (lvBuses.length === 0) return;
    const targetBus = lvBuses[0].id;
    setState(prev => {
      let newState = { ...prev };
      const newId = `${type}_${Date.now()}`;
      switch (type) {
        case 'load':
          newState.loads = [...prev.loads, {
            id: newId, name: `New Load`, busId: targetBus, type: 'RESIDENTIAL' as const,
            pNominal: 100, qNominal: 40, pActual: 100, qActual: 40,
            powerFactor: 0.95, numConsumers: 10, profileType: 'residential', status: 'NORMAL' as const
          }];
          break;
        case 'solar':
          newState.solarPV = [...prev.solarPV, {
            id: newId, name: `New Solar`, busId: targetBus,
            capacity: 50, irradiance: 800, temperature: 30, efficiency: 0.95,
            powerFactor: 0.95, currentOutput: 0, inverterRating: 55,
            curtailment: 0, status: 'NORMAL' as const
          }];
          break;
        case 'battery':
          newState.batteries = [...prev.batteries, {
            id: newId, name: `New Battery`, busId: targetBus,
            capacity: 100, soc: 50, maxChargePower: 50, maxDischargePower: 75,
            efficiency: 0.92, currentPower: 0, mode: 'MANUAL' as const,
            socMin: 10, socMax: 90, voltage: 400, current: 0, status: 'NORMAL' as const
          }];
          break;
        case 'capacitor':
          newState.capacitors = [...prev.capacitors, {
            id: newId, name: `New Capacitor`, busId: targetBus,
            numSteps: 3, stepSize: 50, activeSteps: 0, totalQ: 0,
            switchedOn: false, status: 'NORMAL' as const
          }];
          break;
      }
      const updatedBuses = newState.buses.map(bus => {
        if (bus.id === targetBus) {
          const busLoads = newState.loads.filter(l => l.busId === bus.id);
          return { ...bus, pLoad: busLoads.reduce((s, l) => s + l.pActual, 0), qLoad: busLoads.reduce((s, l) => s + l.qActual, 0) };
        }
        return bus;
      });
      newState.buses = updatedBuses;
      return calculatePowerFlow(newState);
    });
  }, [state.buses]);

  const handleExport = useCallback(() => {
    const exportData = {
      timestamp: new Date().toISOString(), config,
      results: {
        totalLoadP: state.totalLoadP, totalLoadQ: state.totalLoadQ,
        totalGenP: state.totalGenP, totalLossesP: state.totalLossesP,
        gridImport: state.gridImport, gridExport: state.gridExport,
        minVoltage: state.minVoltage, maxVoltage: state.maxVoltage,
        powerFactor: state.powerFactor, gridHealth: state.gridHealth,
        buses: state.buses, transformers: state.transformers, lines: state.lines
      }
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `gridpulse_report_${Date.now()}.json`; a.click();
    URL.revokeObjectURL(url);
    showNotification('Report exported successfully', 'success');
  }, [state, config]);

  // Save/Load Configuration
  const handleSaveConfig = useCallback(() => {
    const saveData = { state, config, timestamp: Date.now() };
    localStorage.setItem('gridpulse_config', JSON.stringify(saveData));
    showNotification('Configuration saved', 'success');
  }, [state, config]);

  const handleLoadConfig = useCallback(() => {
    const saved = localStorage.getItem('gridpulse_config');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        setState(data.state);
        setConfig(data.config);
        showNotification('Configuration loaded', 'success');
      } catch (e) {
        showNotification('Failed to load configuration', 'error');
      }
    } else {
      showNotification('No saved configuration found', 'info');
    }
  }, []);

  // Undo/Redo
  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      setState(history[newIndex]);
      showNotification('Undone', 'info');
    }
  }, [history, historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      setState(history[newIndex]);
      showNotification('Redone', 'info');
    }
  }, [history, historyIndex]);

  // Add to history
  const addToHistory = useCallback((newState: SimulationState) => {
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newState);
    if (newHistory.length > 50) newHistory.shift(); // Keep last 50 states
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [history, historyIndex]);

  // Notifications
  const showNotification = useCallback((message: string, type: 'success' | 'error' | 'info') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  }, []);

  // CSV Export
  const handleExportCSV = useCallback(() => {
    const rows = [
      ['Component', 'Type', 'Parameter', 'Value', 'Unit'],
      ...state.buses.map(b => [b.id, 'Bus', 'Voltage', b.voltagePU.toFixed(4), 'pu']),
      ...state.transformers.map(t => [t.id, 'Transformer', 'Loading', t.loading.toFixed(2), '%']),
      ...state.lines.map(l => [l.id, 'Line', 'Current', l.current.toFixed(2), 'A']),
      ...state.loads.map(l => [l.id, 'Load', 'Power', l.pActual.toFixed(2), 'kW']),
      ...state.solarPV.map(p => [p.id, 'Solar', 'Output', p.currentOutput.toFixed(2), 'kW']),
      ...state.batteries.map(b => [b.id, 'Battery', 'SOC', b.soc.toFixed(2), '%']),
    ];
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gridpulse_data_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showNotification('CSV exported successfully', 'success');
  }, [state]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case 's':
            e.preventDefault();
            handleSaveConfig();
            break;
          case 'z':
            e.preventDefault();
            if (e.shiftKey) handleRedo();
            else handleUndo();
            break;
          case 'e':
            e.preventDefault();
            handleExport();
            break;
        }
      }
      if (e.key === 'Escape') {
        setShowHelp(false);
        setShowAbout(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleSaveConfig, handleUndo, handleRedo, handleExport]);

  // Computed values
  const maxTxLoading = Math.max(...state.transformers.map(t => t.loading), 0);
  const activeFaults = state.faults.filter(f => f.active).length;
  const batteryNet = state.batteries.reduce((s, b) => s + b.currentPower, 0);
  const lossPercent = state.totalLoadP > 0 ? (state.totalLossesP / state.totalLoadP) * 100 : 0;

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-100 overflow-hidden">
      {/* ═══════════ OFFICIAL HEADER ═══════════ */}
      <header className="flex-shrink-0 bg-white border-b-2 border-blue-900">
        {/* Top bar - official */}
        <div className="bg-blue-900 text-white px-4 py-1 flex items-center justify-between text-xs">
          <div className="flex items-center gap-4">
            <span className="font-semibold">GRIDPULSE</span>
            <span className="opacity-70">|</span>
            <span className="opacity-90">Distribution Network Analysis System</span>
          </div>
          <div className="flex items-center gap-4 opacity-90">
            <span>Operator: Admin</span>
            <span className="opacity-70">|</span>
            <span>{new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
            <span className="opacity-70">|</span>
            <span className="font-mono">{new Date().toLocaleTimeString('en-IN', { hour12: false })}</span>
          </div>
        </div>
        {/* Main header */}
        <div className="px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-blue-900 rounded flex items-center justify-center">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                  <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
                </svg>
              </div>
              <div>
                <h1 className="text-base font-bold text-slate-900 leading-tight">GRIDPULSE</h1>
                <p className="text-[10px] text-slate-500 leading-tight">Distribution Grid Simulation & Analysis Platform</p>
              </div>
            </div>
            <div className="h-8 w-px bg-slate-200" />
            {/* System status */}
            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1.5">
                <div className={`w-2 h-2 rounded-full ${solverStatus.converged ? 'bg-green-600' : 'bg-red-600'} ${!solverStatus.converged ? 'pulse-dot' : ''}`} />
                <span className="text-slate-700 font-medium">{solverStatus.converged ? 'System Normal' : 'System Alert'}</span>
              </div>
              <div className="text-slate-500">|</div>
              <div className="text-slate-600">
                <span className="font-medium">Grid Health:</span>{' '}
                <span className={`font-bold ${state.gridHealth >= 90 ? 'text-green-700' : state.gridHealth >= 70 ? 'text-amber-700' : 'text-red-700'}`}>
                  {state.gridHealth}/100
                </span>
              </div>
              <div className="text-slate-500">|</div>
              <div className="text-slate-600">
                <span className="font-medium">Simulation:</span>{' '}
                <span className="font-mono font-medium">{Math.floor(config.currentTime).toString().padStart(2, '0')}:{Math.floor((config.currentTime % 1) * 60).toString().padStart(2, '0')} HRS</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={handleSaveConfig}
              className="px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 text-slate-700 rounded hover:bg-slate-50"
              title="Save Configuration (Ctrl+S)">
              💾 Save
            </button>
            <button onClick={handleLoadConfig}
              className="px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 text-slate-700 rounded hover:bg-slate-50"
              title="Load Configuration">
              📂 Load
            </button>
            <div className="h-6 w-px bg-slate-200" />
            <button onClick={handleUndo}
              disabled={historyIndex <= 0}
              className="px-2 py-1.5 text-xs font-medium bg-white border border-slate-300 text-slate-700 rounded hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
              title="Undo (Ctrl+Z)">
              ↶ Undo
            </button>
            <button onClick={handleRedo}
              disabled={historyIndex >= history.length - 1}
              className="px-2 py-1.5 text-xs font-medium bg-white border border-slate-300 text-slate-700 rounded hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
              title="Redo (Ctrl+Shift+Z)">
              ↷ Redo
            </button>
            <div className="h-6 w-px bg-slate-200" />
            <button onClick={() => setBaseline(baseline ? null : JSON.parse(JSON.stringify(state)))}
              className={`px-3 py-1.5 text-xs font-medium border rounded transition-colors ${
                baseline ? 'bg-blue-50 border-blue-600 text-blue-700' : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}>
              {baseline ? '✓ Baseline Set' : 'Set Baseline'}
            </button>
            <button onClick={handleExport}
              className="px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 text-slate-700 rounded hover:bg-slate-50"
              title="Export JSON Report (Ctrl+E)">
              📄 Export JSON
            </button>
            <button onClick={handleExportCSV}
              className="px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 text-slate-700 rounded hover:bg-slate-50"
              title="Export CSV Data">
              📊 Export CSV
            </button>
            <div className="h-6 w-px bg-slate-200" />
            <button onClick={() => setShowHelp(true)}
              className="px-2 py-1.5 text-xs font-medium bg-white border border-slate-300 text-slate-700 rounded hover:bg-slate-50"
              title="Help & Keyboard Shortcuts">
              ❓
            </button>
            <button onClick={() => setShowAbout(true)}
              className="px-2 py-1.5 text-xs font-medium bg-white border border-slate-300 text-slate-700 rounded hover:bg-slate-50"
              title="About GRIDPULSE">
              ℹ️
            </button>
          </div>
        </div>
      </header>

      {/* ═══════════ SYSTEM SUMMARY BAR ═══════════ */}
      <div className="flex-shrink-0 bg-white border-b border-slate-200 px-4 py-2">
        <div className="grid grid-cols-12 gap-3">
          <SummaryCard label="Total Load" value={`${(state.totalLoadP / 1000).toFixed(2)} MW`} subtext={`${state.totalLoadQ.toFixed(0)} MVAr`} status={state.totalLoadP > 2500 ? 'warning' : 'normal'} />
          <SummaryCard label="Solar Gen" value={`${(state.totalGenP / 1000).toFixed(2)} MW`} subtext={`${state.solarPV.length} systems`} status="info" />
          <SummaryCard label="Battery" value={`${batteryNet > 0 ? '+' : ''}${batteryNet.toFixed(0)} kW`} subtext={batteryNet < 0 ? 'Discharging' : batteryNet > 0 ? 'Charging' : 'Idle'} status={batteryNet < 0 ? 'info' : 'normal'} />
          <SummaryCard label="Grid Flow" value={`${(state.gridImport / 1000).toFixed(2)} MW`} subtext={state.gridExport > state.gridImport ? 'Exporting' : 'Importing'} status="normal" />
          <SummaryCard label="System Loss" value={`${state.totalLossesP.toFixed(1)} kW`} subtext={`${lossPercent.toFixed(2)}% of load`} status={lossPercent > 5 ? 'warning' : 'normal'} />
          <SummaryCard label="Min Voltage" value={`${state.minVoltage.toFixed(3)} pu`} subtext={`Max: ${state.maxVoltage.toFixed(3)} pu`} status={state.minVoltage < 0.95 ? 'critical' : state.minVoltage < 0.97 ? 'warning' : 'normal'} />
          <SummaryCard label="TX Loading" value={`${maxTxLoading.toFixed(0)}%`} subtext="Peak transformer" status={maxTxLoading > 100 ? 'critical' : maxTxLoading > 80 ? 'warning' : 'normal'} />
          <SummaryCard label="Power Factor" value={state.powerFactor.toFixed(3)} subtext="System PF" status={state.powerFactor < 0.9 ? 'warning' : 'normal'} />
          <SummaryCard label="Active Faults" value={`${activeFaults}`} subtext={activeFaults > 0 ? 'Action required' : 'None'} status={activeFaults > 0 ? 'critical' : 'normal'} />
          <SummaryCard label="Frequency" value={`${state.systemFrequency.toFixed(2)} Hz`} subtext="Stable" status="normal" />
          <SummaryCard label="Reverse Flow" value={`${state.lines.filter(l => l.flowDirection === 'REVERSE').length} lines`} subtext="Solar → Grid" status={state.lines.some(l => l.flowDirection === 'REVERSE') ? 'info' : 'normal'} />
          <SummaryCard label="Components" value={`${state.buses.length + state.lines.length}`} subtext={`${state.buses.length} buses, ${state.lines.length} lines`} status="normal" />
        </div>
      </div>

      {/* ═══════════ SIMULATION CONTROLS ═══════════ */}
      <div className="flex-shrink-0 px-4 py-2 bg-white border-b border-slate-200">
        <SimulationBar config={config} onConfigChange={handleConfigChange} gridHealth={state.gridHealth} />
      </div>

      {/* ═══════════ BASELINE COMPARISON ═══════════ */}
      {baseline && (
        <div className="flex-shrink-0 mx-4 mt-2 p-2.5 bg-blue-50 border border-blue-200 rounded">
          <div className="flex items-center justify-between mb-1.5">
            <div className="text-xs font-semibold text-blue-900">Baseline Comparison</div>
            <button onClick={() => setBaseline(null)} className="text-[10px] text-blue-700 hover:text-blue-900">Clear</button>
          </div>
          <div className="grid grid-cols-6 gap-2 text-[10px]">
            {[
              { label: 'Losses', before: baseline.totalLossesP, after: state.totalLossesP, unit: 'kW', lower: true },
              { label: 'Min V', before: baseline.minVoltage, after: state.minVoltage, unit: 'pu', lower: false },
              { label: 'TX Load', before: Math.max(...baseline.transformers.map(t => t.loading)), after: Math.max(...state.transformers.map(t => t.loading)), unit: '%', lower: true },
              { label: 'Grid In', before: baseline.gridImport, after: state.gridImport, unit: 'kW', lower: true },
              { label: 'PF', before: baseline.powerFactor, after: state.powerFactor, unit: '', lower: false },
              { label: 'Health', before: baseline.gridHealth, after: state.gridHealth, unit: '/100', lower: false }
            ].map((item, i) => {
              const diff = item.after - item.before;
              const pct = item.before !== 0 ? (diff / Math.abs(item.before)) * 100 : 0;
              const improved = item.lower ? diff < 0 : diff > 0;
              return (
                <div key={i} className="bg-white rounded px-2 py-1 border border-blue-100">
                  <div className="text-[9px] text-slate-500 font-medium uppercase">{item.label}</div>
                  <div className="flex items-baseline gap-1 font-mono">
                    <span className="text-[9px] text-slate-400 line-through">{item.before.toFixed(2)}</span>
                    <span className="text-[11px] font-bold text-slate-800">{item.after.toFixed(2)}</span>
                    <span className="text-[9px] text-slate-500">{item.unit}</span>
                  </div>
                  <div className={`text-[9px] font-mono font-bold ${improved ? 'text-green-700' : diff === 0 ? 'text-slate-400' : 'text-red-700'}`}>
                    {improved ? '↓' : diff === 0 ? '—' : '↑'} {Math.abs(pct).toFixed(1)}%
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ═══════════ MAIN CONTENT ═══════════ */}
      <div className="flex-1 flex gap-2 p-2 min-h-0 overflow-hidden">
        {/* LEFT: Main view */}
        <div className="flex-1 flex flex-col min-w-0 bg-white border border-slate-200 rounded overflow-hidden">
          {/* View tabs */}
          <div className="flex-shrink-0 border-b border-slate-200 bg-slate-50 px-2 flex items-center">
            {([
              { id: 'sld' as ViewTab, label: 'Single Line Diagram' },
              { id: 'data' as ViewTab, label: 'Equipment Data' },
              { id: 'charts' as ViewTab, label: 'Load Flow Charts' }
            ]).map(tab => (
              <button key={tab.id} onClick={() => setActiveView(tab.id)}
                className={`px-3 py-2 text-xs font-medium border-b-2 transition-colors ${
                  activeView === tab.id ? 'border-blue-700 text-blue-900 bg-white' : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}>
                {tab.label}
              </button>
            ))}
          </div>
          {/* View content */}
          <div className="flex-1 min-h-0 overflow-hidden">
            {activeView === 'sld' && (
              <CircuitView state={state} onSelectComponent={handleSelectComponent} selectedComponent={config.selectedComponent}
                onToggleBreaker={handleToggleBreaker} onToggleCapacitor={handleToggleCapacitor}
                onDeleteComponent={handleDeleteComponent} onAddComponent={handleAddComponent} />
            )}
            {activeView === 'data' && (
              <EquipmentTable state={state} onSelectComponent={handleSelectComponent} selectedComponent={config.selectedComponent} />
            )}
            {activeView === 'charts' && (
              <div className="p-3 h-full overflow-auto">
                <Charts timeSeries={timeSeries} state={state} currentTime={config.currentTime} />
              </div>
            )}
          </div>
        </div>

        {/* RIGHT: Control panel */}
        <div className="w-[360px] flex-shrink-0 flex flex-col bg-white border border-slate-200 rounded overflow-hidden">
          {/* Panel tabs */}
          <div className="flex-shrink-0 border-b border-slate-200 bg-slate-50 px-1 flex">
            {([
              { id: 'inspector' as RightPanel, label: 'Inspector' },
              { id: 'controls' as RightPanel, label: 'Controls' },
              { id: 'scenarios' as RightPanel, label: 'Scenarios' },
              { id: 'faults' as RightPanel, label: 'Faults' }
            ]).map(tab => (
              <button key={tab.id} onClick={() => setRightPanel(tab.id)}
                className={`flex-1 px-2 py-2 text-xs font-medium border-b-2 transition-colors ${
                  rightPanel === tab.id ? 'border-blue-700 text-blue-900 bg-white' : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}>
                {tab.label}
              </button>
            ))}
          </div>
          {/* Panel content */}
          <div className="flex-1 min-h-0 overflow-auto">
            <ControlPanel state={state} config={config}
              onConfigChange={handleConfigChange} onStateChange={handleStateChange}
              onSelectComponent={handleSelectComponent}
              onApplyScenario={handleApplyScenario}
              onInjectFault={handleInjectFault} onClearFaults={handleClearFaults}
              activePanel={rightPanel} />
          </div>
        </div>
      </div>

      {/* ═══════════ FOOTER STATUS ═══════════ */}
      <footer className="flex-shrink-0 bg-slate-800 text-slate-300 px-4 py-1 flex items-center justify-between text-[10px] font-mono">
        <div className="flex items-center gap-3">
          <span className="text-slate-400">GRIDPULSE v2.0</span>
          <span className="text-slate-600">|</span>
          <span>Engine: {solverStatus.converged ? '✓ Converged' : '✗ Failed'}</span>
          <span className="text-slate-600">|</span>
          <span>Time: {config.currentTime.toFixed(2)}h</span>
          <span className="text-slate-600">|</span>
          <span>Speed: {config.simulationSpeed}x</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Load: {state.totalLoadP.toFixed(0)} kW</span>
          <span className="text-slate-600">|</span>
          <span>Gen: {state.totalGenP.toFixed(0)} kW</span>
          <span className="text-slate-600">|</span>
          <span>Loss: {state.totalLossesP.toFixed(1)} kW</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400">Smart India Hackathon 2024</span>
        </div>
      </footer>

      {/* Error banner */}
      {!solverStatus.converged && (
        <div className="absolute bottom-10 left-4 right-4 p-3 bg-red-50 border border-red-300 rounded flex items-center gap-3">
          <span className="text-red-600 text-lg">⚠</span>
          <div className="flex-1">
            <div className="text-xs font-bold text-red-900">SIMULATION ERROR</div>
            <div className="text-[10px] text-red-700">{solverStatus.message}</div>
          </div>
          <button onClick={() => { setState(createDefaultNetwork()); setConfig(getDefaultConfig()); setSolverStatus({ converged: true, message: 'Power flow converged' }); }}
            className="px-3 py-1 text-xs font-medium bg-red-100 text-red-800 rounded hover:bg-red-200">Reset System</button>
        </div>
      )}

      {/* Notification Toast */}
      {notification && (
        <div className={`fixed top-20 right-4 z-50 px-4 py-3 rounded-lg shadow-lg border animate-slide-in ${
          notification.type === 'success' ? 'bg-green-50 border-green-300 text-green-800' :
          notification.type === 'error' ? 'bg-red-50 border-red-300 text-red-800' :
          'bg-blue-50 border-blue-300 text-blue-800'
        }`}>
          <div className="flex items-center gap-2">
            <span className="text-lg">
              {notification.type === 'success' ? '✓' : notification.type === 'error' ? '✗' : 'ℹ'}
            </span>
            <span className="text-sm font-medium">{notification.message}</span>
          </div>
        </div>
      )}

      {/* Help Modal */}
      {showHelp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50" onClick={() => setShowHelp(false)}>
          <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full mx-4 max-h-[80vh] overflow-auto" onClick={e => e.stopPropagation()}>
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900">Help & Keyboard Shortcuts</h2>
              <button onClick={() => setShowHelp(false)} className="text-slate-400 hover:text-slate-600 text-xl">×</button>
            </div>
            <div className="px-6 py-4 space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 mb-2">Keyboard Shortcuts</h3>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Save Configuration</span>
                    <kbd className="px-2 py-0.5 bg-slate-100 rounded text-slate-700 font-mono">Ctrl+S</kbd>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Undo</span>
                    <kbd className="px-2 py-0.5 bg-slate-100 rounded text-slate-700 font-mono">Ctrl+Z</kbd>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Redo</span>
                    <kbd className="px-2 py-0.5 bg-slate-100 rounded text-slate-700 font-mono">Ctrl+Shift+Z</kbd>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span className="text-slate-600">Export JSON Report</span>
                    <kbd className="px-2 py-0.5 bg-slate-100 rounded text-slate-700 font-mono">Ctrl+E</kbd>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-600">Close Modal</span>
                    <kbd className="px-2 py-0.5 bg-slate-100 rounded text-slate-700 font-mono">Esc</kbd>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800 mb-2">Getting Started</h3>
                <ul className="space-y-1 text-xs text-slate-600 list-disc list-inside">
                  <li>Click any component in the circuit diagram to inspect and configure it</li>
                  <li>Use the Inspector panel to edit all parameters</li>
                  <li>Changes trigger immediate power flow recalculation</li>
                  <li>Use scenarios to quickly configure common test cases</li>
                  <li>Export reports in JSON or CSV format</li>
                  <li>Save your configuration to localStorage for later use</li>
                </ul>
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800 mb-2">Features</h3>
                <ul className="space-y-1 text-xs text-slate-600 list-disc list-inside">
                  <li>Complete configurability for all network elements</li>
                  <li>Real-time power flow calculations</li>
                  <li>Interactive single line diagram with drag & drop</li>
                  <li>Intelligent battery management with BITS mode</li>
                  <li>Fault injection and protection coordination</li>
                  <li>Time-series simulation with 24-hour profiles</li>
                  <li>Before/after comparison for scenario analysis</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* About Modal */}
      {showAbout && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50" onClick={() => setShowAbout(false)}>
          <div className="bg-white rounded-lg shadow-2xl max-w-lg w-full mx-4" onClick={e => e.stopPropagation()}>
            <div className="border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900">About GRIDPULSE</h2>
              <button onClick={() => setShowAbout(false)} className="text-slate-400 hover:text-slate-600 text-xl">×</button>
            </div>
            <div className="px-6 py-6 space-y-4">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-900 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                    <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-slate-900">GRIDPULSE</h3>
                <p className="text-sm text-slate-600 mt-1">Distribution Network Analysis System</p>
                <p className="text-xs text-slate-500 mt-1">Version 2.0</p>
              </div>
              <div className="border-t border-slate-200 pt-4">
                <p className="text-xs text-slate-600 leading-relaxed">
                  GRIDPULSE is a professional-grade, government-ready electrical distribution grid simulation platform 
                  designed for utility engineers, system operators, and researchers. It provides real-time power flow 
                  analysis, interactive network visualization, and comprehensive system monitoring capabilities.
                </p>
              </div>
              <div className="border-t border-slate-200 pt-4">
                <h4 className="text-xs font-bold text-slate-800 mb-2">Key Features</h4>
                <ul className="space-y-1 text-xs text-slate-600">
                  <li>• Complete configurability for all network elements</li>
                  <li>• Real-time power flow calculations with backward/forward sweep</li>
                  <li>• Interactive single line diagram with drag & drop</li>
                  <li>• Intelligent battery management with BITS mode</li>
                  <li>• 24-hour time-series simulation</li>
                  <li>• Fault injection and protection coordination</li>
                  <li>• Before/after scenario comparison</li>
                  <li>• Export to JSON and CSV formats</li>
                </ul>
              </div>
              <div className="border-t border-slate-200 pt-4 text-center">
                <p className="text-xs text-slate-500">Built for Smart India Hackathon 2024</p>
                <p className="text-xs text-slate-400 mt-1">© 2024 GRIDPULSE Team</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Summary card component
const SummaryCard: React.FC<{ label: string; value: string; subtext: string; status: 'normal' | 'warning' | 'critical' | 'info' }> = ({ label, value, subtext, status }) => {
  const borderColor = {
    normal: 'border-l-slate-300',
    warning: 'border-l-amber-500',
    critical: 'border-l-red-600',
    info: 'border-l-blue-600'
  }[status];
  const valueColor = {
    normal: 'text-slate-900',
    warning: 'text-amber-700',
    critical: 'text-red-700',
    info: 'text-blue-700'
  }[status];

  return (
    <div className={`border border-slate-200 border-l-4 ${borderColor} rounded px-2 py-1.5 bg-white`}>
      <div className="text-[9px] text-slate-500 font-medium uppercase tracking-wide">{label}</div>
      <div className={`text-sm font-bold font-mono ${valueColor} leading-tight`}>{value}</div>
      <div className="text-[9px] text-slate-500">{subtext}</div>
    </div>
  );
};

// Charts component with actual SVG rendering
const Charts: React.FC<{ timeSeries: any[]; state: SimulationState; currentTime: number }> = ({ timeSeries, state, currentTime }) => {
  const [activeChart, setActiveChart] = useState<'overview' | 'voltage' | 'power' | 'losses' | 'battery'>('overview');
  const sampled = timeSeries.filter((_, i) => i % 4 === 0);

  const W = 900, H = 320, PAD = { top: 20, right: 20, bottom: 30, left: 50 };
  const chartW = W - PAD.left - PAD.right;
  const chartH = H - PAD.top - PAD.bottom;

  const getX = (i: number) => PAD.left + (i / (sampled.length - 1)) * chartW;

  const makePath = (data: number[], yMin: number, yMax: number) => {
    return data.map((v, i) => {
      const x = getX(i);
      const y = PAD.top + chartH - ((v - yMin) / (yMax - yMin)) * chartH;
      return `${i === 0 ? 'M' : 'L'}${x},${y}`;
    }).join(' ');
  };

  const makeArea = (data: number[], yMin: number, yMax: number) => {
    const path = makePath(data, yMin, yMax);
    const lastX = getX(data.length - 1);
    const firstX = getX(0);
    const bottom = PAD.top + chartH;
    return `${path} L${lastX},${bottom} L${firstX},${bottom} Z`;
  };

  const getYTicks = (min: number, max: number, count: number = 5) => {
    const step = (max - min) / (count - 1);
    return Array.from({ length: count }, (_, i) => min + step * i);
  };

  const renderYAxis = (min: number, max: number, unit: string = '') => {
    const ticks = getYTicks(min, max);
    return (
      <g>
        {ticks.map((t, i) => {
          const y = PAD.top + chartH - ((t - min) / (max - min)) * chartH;
          return (
            <g key={i}>
              <line x1={PAD.left} y1={y} x2={PAD.left + chartW} y2={y} stroke="#e2e8f0" strokeWidth="0.5" />
            <text x={PAD.left - 5} y={y + 3} textAnchor="end" fontSize="9" fill="#64748b" fontFamily="JetBrains Mono">
              {`${t.toFixed(t < 10 ? 2 : 0)}${unit}`}
            </text>            </g>
          );
        })}
      </g>
    );
  };

  const renderXAxis = () => (
    <g>
      <line x1={PAD.left} y1={PAD.top + chartH} x2={PAD.left + chartW} y2={PAD.top + chartH} stroke="#94a3b8" strokeWidth="1" />
      {[0, 6, 12, 18, 24].map(h => {
        const idx = sampled.findIndex(p => Math.abs(p.hour - h) < 0.5);
        if (idx < 0) return null;
        const x = getX(idx);
        return (
          <g key={h}>
            <line x1={x} y1={PAD.top + chartH} x2={x} y2={PAD.top + chartH + 4} stroke="#94a3b8" />
            <text x={x} y={PAD.top + chartH + 15} textAnchor="middle" fontSize="9" fill="#64748b" fontFamily="JetBrains Mono">
              {String(h).padStart(2, '0')}:00
            </text>
          </g>
        );
      })}
    </g>
  );

  // Current time marker
  const currentTimeIdx = sampled.findIndex(p => Math.abs(p.hour - currentTime) < 0.5);
  const renderTimeMarker = () => {
    if (currentTimeIdx < 0) return null;
    const x = getX(currentTimeIdx);
    return (
      <g>
        <line x1={x} y1={PAD.top} x2={x} y2={PAD.top + chartH} stroke="#1e40af" strokeWidth="1" strokeDasharray="3 2" />
        <text x={x} y={PAD.top - 5} textAnchor="middle" fontSize="8" fill="#1e40af" fontWeight="600">NOW</text>
      </g>
    );
  };

  const renderChart = () => {
    switch (activeChart) {
      case 'overview': {
        const load = sampled.map(p => p.totalLoadP);
        const solar = sampled.map(p => p.solarGen);
        const losses = sampled.map(p => p.losses);
        const maxVal = Math.max(...load, 100) * 1.1;
        return (
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-full">
            {renderYAxis(0, maxVal, ' kW')}
            {renderXAxis()}
            <path d={makeArea(load, 0, maxVal)} fill="#3b82f620" />
            <path d={makePath(load, 0, maxVal)} fill="none" stroke="#3b82f6" strokeWidth="2" />
            <path d={makeArea(solar, 0, maxVal)} fill="#f59e0b20" />
            <path d={makePath(solar, 0, maxVal)} fill="none" stroke="#f59e0b" strokeWidth="2" />
            <path d={makePath(losses, 0, maxVal)} fill="none" stroke="#dc2626" strokeWidth="1.5" strokeDasharray="4 2" />
            {renderTimeMarker()}
            {/* Legend */}
            <g transform={`translate(${PAD.left + 10}, ${PAD.top + 10})`}>
              <line x1="0" y1="0" x2="15" y2="0" stroke="#3b82f6" strokeWidth="2" />
              <text x="20" y="3" fontSize="9" fill="#475569">Load (kW)</text>
              <line x1="80" y1="0" x2="95" y2="0" stroke="#f59e0b" strokeWidth="2" />
              <text x="100" y="3" fontSize="9" fill="#475569">Solar (kW)</text>
              <line x1="165" y1="0" x2="180" y2="0" stroke="#dc2626" strokeWidth="1.5" strokeDasharray="4 2" />
              <text x="185" y="3" fontSize="9" fill="#475569">Losses (kW)</text>
            </g>
          </svg>
        );
      }
      case 'voltage': {
        const minV = sampled.map(p => p.minVoltage);
        const maxV = sampled.map(p => p.maxVoltage);
        return (
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-full">
            {renderYAxis(0.88, 1.12, ' pu')}
            {renderXAxis()}
            {/* Safe zone */}
            <rect x={PAD.left} y={PAD.top + chartH - ((1.05 - 0.88) / 0.24) * chartH}
              width={chartW} height={((1.05 - 0.95) / 0.24) * chartH} fill="#22c55e10" />
            <line x1={PAD.left} y1={PAD.top + chartH - ((0.95 - 0.88) / 0.24) * chartH}
              x2={PAD.left + chartW} y2={PAD.top + chartH - ((0.95 - 0.88) / 0.24) * chartH}
              stroke="#f59e0b" strokeWidth="1" strokeDasharray="4 2" />
            <line x1={PAD.left} y1={PAD.top + chartH - ((1.05 - 0.88) / 0.24) * chartH}
              x2={PAD.left + chartW} y2={PAD.top + chartH - ((1.05 - 0.88) / 0.24) * chartH}
              stroke="#f59e0b" strokeWidth="1" strokeDasharray="4 2" />
            <path d={makePath(maxV, 0.88, 1.12)} fill="none" stroke="#f59e0b" strokeWidth="1.5" />
            <path d={makePath(minV, 0.88, 1.12)} fill="none" stroke="#dc2626" strokeWidth="2" />
            {renderTimeMarker()}
            <g transform={`translate(${PAD.left + 10}, ${PAD.top + 10})`}>
              <line x1="0" y1="0" x2="15" y2="0" stroke="#f59e0b" strokeWidth="1.5" />
              <text x="20" y="3" fontSize="9" fill="#475569">Max Voltage (pu)</text>
              <line x1="120" y1="0" x2="135" y2="0" stroke="#dc2626" strokeWidth="2" />
              <text x="140" y="3" fontSize="9" fill="#475569">Min Voltage (pu)</text>
            </g>
          </svg>
        );
      }
      case 'power': {
        const imp = sampled.map(p => p.gridImport);
        const exp = sampled.map(p => p.gridExport);
        const bat = sampled.map(p => Math.abs(p.batteryPower));
        const maxVal = Math.max(...imp, ...exp, 100) * 1.1;
        return (
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-full">
            {renderYAxis(0, maxVal, ' kW')}
            {renderXAxis()}
            <path d={makeArea(imp, 0, maxVal)} fill="#6366f120" />
            <path d={makePath(imp, 0, maxVal)} fill="none" stroke="#6366f1" strokeWidth="2" />
            <path d={makeArea(exp, 0, maxVal)} fill="#10b98120" />
            <path d={makePath(exp, 0, maxVal)} fill="none" stroke="#10b981" strokeWidth="2" />
            <path d={makePath(bat, 0, maxVal)} fill="none" stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="4 2" />
            {renderTimeMarker()}
            <g transform={`translate(${PAD.left + 10}, ${PAD.top + 10})`}>
              <line x1="0" y1="0" x2="15" y2="0" stroke="#6366f1" strokeWidth="2" />
              <text x="20" y="3" fontSize="9" fill="#475569">Grid Import (kW)</text>
              <line x1="115" y1="0" x2="130" y2="0" stroke="#10b981" strokeWidth="2" />
              <text x="135" y="3" fontSize="9" fill="#475569">Grid Export (kW)</text>
              <line x1="235" y1="0" x2="250" y2="0" stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="4 2" />
              <text x="255" y="3" fontSize="9" fill="#475569">Battery |Power| (kW)</text>
            </g>
          </svg>
        );
      }
      case 'losses': {
        const losses = sampled.map(p => p.losses);
        const maxVal = Math.max(...losses, 10) * 1.2;
        return (
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-full">
            {renderYAxis(0, maxVal, ' kW')}
            {renderXAxis()}
            <path d={makeArea(losses, 0, maxVal)} fill="#dc262620" />
            <path d={makePath(losses, 0, maxVal)} fill="none" stroke="#dc2626" strokeWidth="2" />
            {renderTimeMarker()}
            <g transform={`translate(${PAD.left + 10}, ${PAD.top + 10})`}>
              <line x1="0" y1="0" x2="15" y2="0" stroke="#dc2626" strokeWidth="2" />
              <text x="20" y="3" fontSize="9" fill="#475569">Total Losses (kW)</text>
            </g>
          </svg>
        );
      }
      case 'battery': {
        const batPower = sampled.map(p => Math.abs(p.batteryPower));
        const soc = sampled.map(p => p.batterySOC);
        const maxPower = Math.max(...batPower, 10) * 1.2;
        return (
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-full">
            {renderYAxis(0, maxPower, ' kW')}
            {renderXAxis()}
            {/* Secondary Y axis for SOC */}
            {[0, 25, 50, 75, 100].map(s => {
              const y = PAD.top + chartH - (s / 100) * chartH;
              return (
                <g key={s}>
                  <text x={PAD.left + chartW + 5} y={y + 3} fontSize="9" fill="#6366f1" fontFamily="JetBrains Mono">{s}%</text>
                </g>
              );
            })}
            <path d={makeArea(batPower, 0, maxPower)} fill="#10b98120" />
            <path d={makePath(batPower, 0, maxPower)} fill="none" stroke="#10b981" strokeWidth="2" />
            <path d={makePath(soc.map(s => s * maxPower / 100), 0, maxPower)} fill="none" stroke="#6366f1" strokeWidth="1.5" strokeDasharray="4 2" />
            {renderTimeMarker()}
            <g transform={`translate(${PAD.left + 10}, ${PAD.top + 10})`}>
              <line x1="0" y1="0" x2="15" y2="0" stroke="#10b981" strokeWidth="2" />
              <text x="20" y="3" fontSize="9" fill="#475569">Battery |Power| (kW)</text>
              <line x1="150" y1="0" x2="165" y2="0" stroke="#6366f1" strokeWidth="1.5" strokeDasharray="4 2" />
              <text x="170" y="3" fontSize="9" fill="#475569">SOC (%)</text>
            </g>
          </svg>
        );
      }
    }
  };

  return (
    <div className="h-full flex flex-col p-3">
      <div className="flex-shrink-0 flex gap-1 mb-2 border-b border-slate-200 pb-2">
        {(['overview', 'voltage', 'power', 'losses', 'battery'] as const).map(chart => (
          <button key={chart} onClick={() => setActiveChart(chart)}
            className={`px-2.5 py-1 text-[10px] font-medium rounded transition-colors ${
              activeChart === chart ? 'bg-blue-700 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}>
            {chart.charAt(0).toUpperCase() + chart.slice(1)}
          </button>
        ))}
      </div>
      <div className="flex-1 bg-white rounded border border-slate-200 overflow-hidden">
        {renderChart()}
      </div>
    </div>
  );
};

export default App;
