# Battery Intelligent Discharge Control

## 🎯 Overview

GRIDPULSE now implements **intelligent battery discharge control** with safety limits and gradual power delivery to protect battery health and prevent deep discharge damage.

---

## 🔋 How It Works

### Safety Thresholds

The battery discharge system uses two critical SOC (State of Charge) thresholds:

1. **Safe Discharge Limit: 20% SOC**
   - Above 20%: Full discharge power available
   - Below 20%: Discharge power gradually reduces

2. **Critical SOC Limit: 10% SOC**
   - Below 10%: Discharge completely stops
   - Protects battery from deep discharge damage

### Gradual Discharge (Bits Mode)

When SOC drops below 20%, the battery enters **"BITS Mode"** where:

- Discharge power **gradually reduces** from 100% to 0%
- Linear reduction between 20% and 10% SOC
- At 15% SOC: Discharge at 50% of maximum power
- At 12% SOC: Discharge at 20% of maximum power
- At 10% SOC: Discharge stops completely (0%)

### Discharge Factor Formula

```
If SOC ≤ 10%:     Discharge Factor = 0 (STOP)
If 10% < SOC < 20%: Discharge Factor = (SOC - 10) / 10
If SOC ≥ 20%:     Discharge Factor = 1 (FULL POWER)
```

**Example:**
- SOC = 18% → Factor = (18-10)/10 = 0.8 → 80% of max discharge power
- SOC = 15% → Factor = (15-10)/10 = 0.5 → 50% of max discharge power
- SOC = 12% → Factor = (12-10)/10 = 0.2 → 20% of max discharge power
- SOC = 10% → Factor = 0 → 0% (STOP)

---

## 📊 Visual Indicators

### Circuit Diagram

When the battery is discharging in BITS mode or STOPPED:

**Normal Discharge (SOC ≥ 20%):**
```
┌──────────────┐
│   🔋 BESS1   │
│   45% | -50kW│  ← Normal operation
└──────────────┘
```

**BITS Mode (10% < SOC < 20%):**
```
┌──────────────┐
│   🔋 BESS1   │
│   15% | -25kW│  ← Reduced power
│   [ BITS ]   │  ← Amber indicator
└──────────────┘
```

**Stopped (SOC ≤ 10%):**
```
┌──────────────┐
│   🔋 BESS1   │
│    8% |  0kW │  ← No discharge
│   [ STOP ]   │  ← Red indicator
└──────────────┘
```

### Hover Tooltip

**Normal Operation:**
```
BESS1
SOC:        45.0%
Power:      -50.0 kW
Mode:       Peak Shaving
Capacity:   200 kWh
Status:     NORMAL
```

**BITS Mode:**
```
BESS1
SOC:        15.0%
Power:      -25.0 kW
Mode:       Peak Shaving
Capacity:   200 kWh
Status:     BITS MODE
─────────────────────
⚠️ Discharging in bits - approaching limit
```

**Stopped:**
```
BESS1
SOC:        8.0%
Power:      0.0 kW
Mode:       Peak Shaving
Capacity:   200 kWh
Status:     STOPPED
─────────────────────
⚠️ Discharge stopped - SOC critical
```

### Equipment Table

The battery table shows discharge state indicators:

| SOC (%) | Power (kW) | Status |
|---------|------------|--------|
| 45.0 | -50.0 | NORMAL |
| 15.0 | -25.0 (BITS) | WARNING |
| 8.0 | 0.0 (STOP) | CRITICAL |

### Control Panel Inspector

When you click on a battery, the inspector shows detailed discharge behavior:

**Normal Discharge:**
```
✅ NORMAL DISCHARGE
SOC above safe limit (20%) - full discharge power available
```

**BITS Mode:**
```
⚡ DISCHARGING IN BITS
SOC approaching limit - discharge power reduced to 50% of max
```

**Stopped:**
```
🛑 DISCHARGE STOPPED
SOC critical (<10%) - discharge completely stopped to protect battery
```

---

## 🎮 How to Test

### Scenario 1: Normal Operation
1. Start with battery at 50% SOC
2. Apply "Peak Summer Load" scenario
3. Battery discharges at full power
4. No BITS or STOP indicators

### Scenario 2: BITS Mode
1. Start with battery at 25% SOC
2. Apply "Peak Summer Load" scenario
3. Battery SOC drops below 20%
4. Discharge power gradually reduces
5. "BITS" indicator appears

### Scenario 3: Stopped
1. Start with battery at 12% SOC
2. Apply "Peak Summer Load" scenario
3. Battery SOC drops below 10%
4. Discharge completely stops
5. "STOP" indicator appears
6. Power shows 0 kW

### Scenario 4: Recovery
1. Battery in STOP state (8% SOC)
2. Wait for solar generation to increase
3. Battery starts charging
4. SOC rises above 10% → discharge resumes in BITS
5. SOC rises above 20% → full discharge power restored

---

## 🔬 Technical Implementation

### Power Calculation Logic

```typescript
// Safety thresholds
const SAFE_DISCHARGE_LIMIT = 20; // %
const CRITICAL_SOC_LIMIT = 10; // %

// Calculate discharge factor
const getDischargeFactor = (soc: number): number => {
  if (soc <= CRITICAL_SOC_LIMIT) return 0; // Stop completely
  if (soc <= SAFE_DISCHARGE_LIMIT) {
    // Linear reduction from 100% to 0% between 20% and 10%
    return (soc - CRITICAL_SOC_LIMIT) / (SAFE_DISCHARGE_LIMIT - CRITICAL_SOC_LIMIT);
  }
  return 1; // Full power above safe limit
};

// Apply factor to discharge power
power = -Math.min(battery.maxDischargePower, desiredDischarge) * dischargeFactor;
```

### Mode-Specific Behavior

All battery modes respect the safety limits:

**PEAK_SHAVING:**
- Discharges during peak load (>500 kW)
- Max 60% of excess load
- Reduced by discharge factor when SOC < 20%

**SOLAR_SELF_CONSUMPTION:**
- Discharges when load > solar
- Max 50% of deficit
- Reduced by discharge factor when SOC < 20%

**GRID_SUPPORT:**
- Discharges when load > 800 kW
- Max 40% of load
- Reduced by discharge factor when SOC < 20%

**LOAD_FOLLOWING:**
- Discharges when net load > 0
- Max 30% of net load
- Reduced by discharge factor when SOC < 20%

**MANUAL:**
- User-specified discharge power
- Still respects safety limits
- Reduced by discharge factor when SOC < 20%

---

## 💡 Benefits

### 1. Battery Protection
- Prevents deep discharge damage
- Extends battery lifespan
- Maintains battery health

### 2. Grid Stability
- Predictable discharge behavior
- Gradual power reduction prevents sudden drops
- Smooth transition to charging mode

### 3. User Awareness
- Clear visual indicators
- Real-time status updates
- Informed decision making

### 4. Realistic Simulation
- Mimics real BMS (Battery Management System) behavior
- Industry-standard safety protocols
- Professional engineering accuracy

---

## 📈 Example Timeline

### 24-Hour Battery Operation

```
Time    SOC     Power    Status
─────────────────────────────────
00:00   85%     0 kW     Charging (off-peak)
06:00   90%     0 kW     Full - waiting for peak
08:00   90%     -50 kW   Normal discharge
10:00   70%     -50 kW   Normal discharge
12:00   50%     -50 kW   Normal discharge
14:00   30%     -50 kW   Normal discharge
16:00   20%     -40 kW   ⚡ BITS Mode (80%)
17:00   15%     -25 kW   ⚡ BITS Mode (50%)
18:00   12%     -10 kW   ⚡ BITS Mode (20%)
19:00   10%     0 kW     🛑 STOPPED
20:00   10%     +30 kW   Charging (solar excess)
22:00   25%     +50 kW   Charging
24:00   45%     0 kW     Ready for next day
```

---

## 🎯 Use Cases

### 1. Peak Shaving with Protection
- Battery discharges during evening peak
- Gradually reduces power as SOC drops
- Prevents complete depletion
- Maintains reserve for critical loads

### 2. Solar Self-Consumption
- Stores excess solar during day
- Discharges in evening when solar drops
- BITS mode prevents over-discharge
- Ready for next morning's solar

### 3. Grid Support
- Provides power during grid stress
- Reduces output as battery depletes
- Prevents battery damage
- Maintains system stability

### 4. Emergency Backup
- Critical loads prioritized
- BITS mode extends backup time
- Prevents complete blackout
- Graceful degradation

---

## 🔧 Configuration

### Adjustable Parameters

Currently hardcoded but can be made configurable:

```typescript
const SAFE_DISCHARGE_LIMIT = 20; // % - Can be adjusted
const CRITICAL_SOC_LIMIT = 10; // % - Can be adjusted
```

### Future Enhancements

- User-configurable thresholds
- Per-battery settings
- Temperature-based adjustments
- Age-based degradation modeling
- Dynamic limits based on grid conditions

---

## 📊 Monitoring

### Key Metrics to Watch

1. **SOC Trend**
   - Watch for rapid drops
   - Monitor BITS mode entry
   - Track STOP events

2. **Discharge Power**
   - Observe gradual reduction
   - Correlate with SOC
   - Verify safety limits

3. **Grid Impact**
   - Monitor voltage stability
   - Track load serving capability
   - Assess backup duration

### Alerts (Future)

- SOC < 20%: "Battery entering BITS mode"
- SOC < 10%: "Battery discharge stopped - critical"
- Extended BITS mode: "Battery depleted - consider charging"

---

## ✅ Summary

The battery system now provides:

✅ **Safety-first discharge** - Protects battery from damage  
✅ **Gradual power reduction** - Smooth transition in BITS mode  
✅ **Clear visual indicators** - BITS and STOP labels  
✅ **Real-time status** - Hover tooltips and inspector  
✅ **Mode-aware behavior** - All modes respect limits  
✅ **Professional accuracy** - Mimics real BMS systems  
✅ **User-friendly** - Intuitive indicators and feedback  

**This is not just a simulation - it's a realistic battery management system that protects your investment while providing reliable power.**

---

**GRIDPULSE** - *Intelligent Battery Management for Distribution Grids*
