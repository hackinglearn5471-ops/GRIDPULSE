# Battery Clear/Reset Feature - Complete Guide

## Overview

GRIDPULSE now includes **instant battery clearing and reset functionality** that allows users to immediately change battery state of charge (SOC) without waiting for gradual charging/discharging. This feature is essential for:

- **Scenario testing** - Quickly set up different battery states
- **Emergency simulation** - Test battery failure scenarios
- **System reset** - Return batteries to known states
- **What-if analysis** - Compare different SOC levels instantly

---

## 🎯 Quick Actions Available

### Individual Battery Control

When you select a battery in the Inspector panel, you'll see three quick action buttons:

#### 🗑️ **Clear to 0%**
- **Purpose**: Instantly discharge battery completely
- **Use Case**: Simulate battery depletion, emergency discharge
- **Effect**: SOC → 0%, Power → 0 kW
- **Visual**: Red button with trash icon

#### 🔋 **Charge to 100%**
- **Purpose**: Instantly charge battery to full capacity
- **Use Case**: Start with fully charged battery, test maximum storage
- **Effect**: SOC → 100%, Power → 0 kW
- **Visual**: Green button with battery icon

#### 🔄 **Reset to 50%**
- **Purpose**: Reset battery to default/neutral state
- **Use Case**: Return to baseline configuration, balanced state
- **Effect**: SOC → 50%, Power → 0 kW
- **Visual**: Blue button with refresh icon

### Global Battery Control

In the **Controls** panel, under "Global Battery Actions", you'll find three buttons that affect **all batteries simultaneously**:

#### 🗑️ **Clear All**
- Discharges all batteries to 0% instantly
- Stops all charging/discharging power
- Useful for system-wide reset

#### 🔋 **Charge All**
- Charges all batteries to 100% instantly
- Stops all charging/discharging power
- Useful for maximum storage scenario

#### 🔄 **Reset All**
- Resets all batteries to 50% SOC
- Stops all charging/discharging power
- Useful for balanced baseline

---

## 📍 Where to Find These Features

### Individual Battery Actions

1. **Click on a battery** in the circuit diagram or equipment table
2. **Inspector panel** opens on the right
3. Scroll down to see **"Quick Actions"** section
4. Click any of the three buttons:
   - 🗑️ Clear to 0%
   - 🔋 Charge to 100%
   - 🔄 Reset to 50%

### Global Battery Actions

1. Click **"Controls"** tab in the right panel
2. Scroll to **"Global Battery Actions"** section
3. Click any of the three buttons:
   - 🗑️ Clear All
   - 🔋 Charge All
   - 🔄 Reset All

---

## 💡 Use Cases & Examples

### Use Case 1: Emergency Battery Depletion Test

**Scenario**: Test how the grid responds when batteries are completely drained

**Steps**:
1. Start with batteries at normal SOC (e.g., 70%)
2. Click on Battery 1 in circuit diagram
3. Click **"🗑️ Clear to 0%"** button
4. Observe:
   - Battery SOC drops to 0% instantly
   - Power output stops (0 kW)
   - Grid must supply all load
   - Voltage may drop if battery was supporting grid
   - BITS mode indicator shows "🛑 DISCHARGE STOPPED"

**Result**: See grid behavior without battery support

---

### Use Case 2: Maximum Storage Scenario

**Scenario**: Test grid with fully charged batteries

**Steps**:
1. Click **"Controls"** tab
2. Click **"🔋 Charge All"** button
3. Observe:
   - All batteries jump to 100% SOC
   - Maximum energy available for discharge
   - Grid health may improve
   - Batteries can support peak loads

**Result**: Maximum battery support capacity

---

### Use Case 3: Balanced Baseline

**Scenario**: Reset all batteries to neutral state for fair comparison

**Steps**:
1. Click **"Controls"** tab
2. Click **"🔄 Reset All"** button
3. All batteries now at 50% SOC
4. Set as baseline for comparison
5. Apply different scenarios
6. Compare results

**Result**: Consistent starting point for analysis

---

### Use Case 4: Individual Battery Testing

**Scenario**: Test specific battery behavior

**Steps**:
1. Select Battery 1 (BESS1)
2. Click **"🔋 Charge to 100%"**
3. Select Battery 2 (BESS2)
4. Click **"🗑️ Clear to 0%"**
5. Observe different behaviors:
   - BESS1: Full discharge capability
   - BESS2: No discharge capability (BITS mode stopped)
   - Different power contributions
   - Different grid support levels

**Result**: Compare battery states and their impact

---

### Use Case 5: Solar + Battery Coordination

**Scenario**: Test solar self-consumption with different battery states

**Steps**:
1. Set all batteries to **"Solar Self-Consumption"** mode
2. Click **"🗑️ Clear All"** - batteries empty
3. Run simulation at noon (high solar)
4. Observe batteries charging from excess solar
5. Click **"🔋 Charge All"** - batteries full
6. Run simulation at evening (no solar)
7. Observe batteries discharging to support load

**Result**: See complete charge/discharge cycle

---

## ⚡ Technical Details

### What Happens When You Clear a Battery

**Instant Changes**:
```
Before: SOC = 72%, Power = -45 kW
After:  SOC = 0%,  Power = 0 kW
```

**System Recalculation**:
- Power flow recalculates immediately (<100ms)
- All bus voltages update
- All line currents update
- Grid import/export adjusts
- Losses recalculate
- Grid health score updates

**Visual Updates**:
- Battery SOC indicator changes color (green → amber → red)
- Power display shows 0 kW
- BITS mode status updates
- Circuit diagram reflects new state

### What Happens When You Charge a Battery

**Instant Changes**:
```
Before: SOC = 30%, Power = +50 kW
After:  SOC = 100%, Power = 0 kW
```

**System Recalculation**:
- Available energy increases
- Battery can now support more load
- Grid import may decrease
- Voltage support improves

### What Happens When You Reset a Battery

**Instant Changes**:
```
Before: SOC = 85%, Power = -30 kW
After:  SOC = 50%, Power = 0 kW
```

**System Recalculation**:
- Battery at neutral state
- Balanced charge/discharge capability
- Good starting point for scenarios

---

## 🎨 Visual Indicators

### Battery SOC Colors

| SOC Range | Color | Meaning |
|-----------|-------|---------|
| 80-100% | 🟢 Green | Fully charged, ready for discharge |
| 50-79% | 🟢 Green | Good charge level |
| 20-49% | 🟡 Amber | Moderate charge, monitor closely |
| 10-19% | 🟡 Amber | Low charge, BITS mode active |
| 0-9% | 🔴 Red | Critical, discharge stopped |

### Button States

**Active Buttons**:
- Colored background (red/green/blue)
- Clear icon (🗑️/🔋/🔄)
- Hover effect (darker background)
- Tooltip on hover

**After Click**:
- Instant visual feedback
- SOC value updates immediately
- Power display changes to 0 kW
- Status indicators update

---

## 🔧 Integration with BITS Mode

### BITS Mode Behavior After Clearing

When you clear a battery to 0%:

1. **Immediate Effect**:
   - SOC = 0%
   - Power = 0 kW (stopped)
   - BITS mode: "🛑 DISCHARGE STOPPED"

2. **Protection Active**:
   - Battery cannot discharge (below 10% critical limit)
   - Battery can charge if excess solar available
   - System protects battery from damage

3. **Recovery**:
   - Wait for solar generation or grid charging
   - SOC increases above 10%
   - BITS mode changes to "⚡ BITS MODE ACTIVE"
   - Discharge gradually resumes

### BITS Mode Behavior After Charging

When you charge a battery to 100%:

1. **Immediate Effect**:
   - SOC = 100%
   - Power = 0 kW
   - BITS mode: "✅ NORMAL OPERATION"

2. **Full Capability**:
   - Maximum discharge power available
   - No BITS mode restrictions
   - Full grid support capability

3. **Usage**:
   - Battery discharges based on mode
   - SOC decreases over time
   - Eventually enters BITS mode at 20%
   - Stops at 10% for protection

---

## 📊 Comparison: Before vs After

### Example: Peak Shaving Scenario

**Before Clearing**:
```
Battery 1: SOC = 72%, Power = -45 kW
Battery 2: SOC = 55%, Power = -30 kW
Grid Import: 1,650 kW
Min Voltage: 0.947 pu
Grid Health: 94/100
```

**After "Clear All"**:
```
Battery 1: SOC = 0%, Power = 0 kW
Battery 2: SOC = 0%, Power = 0 kW
Grid Import: 1,725 kW (increased)
Min Voltage: 0.938 pu (decreased)
Grid Health: 87/100 (decreased)
```

**Impact**:
- Grid must supply all load
- Voltage drops slightly
- Grid health decreases
- No battery support available

---

**After "Charge All"**:
```
Battery 1: SOC = 100%, Power = 0 kW
Battery 2: SOC = 100%, Power = 0 kW
Grid Import: 1,650 kW
Min Voltage: 0.952 pu (improved)
Grid Health: 96/100 (improved)
```

**Impact**:
- Maximum battery support available
- Voltage improves
- Grid health increases
- Ready for peak demand

---

## 🎯 Best Practices

### When to Use Clear/Reset

✅ **Good Times to Clear**:
- Testing emergency scenarios
- Simulating battery failure
- Starting fresh analysis
- Comparing with/without battery

✅ **Good Times to Charge**:
- Testing maximum storage
- Preparing for peak demand
- Starting with full capacity
- Solar self-consumption studies

✅ **Good Times to Reset**:
- Setting baseline for comparison
- Returning to neutral state
- Balanced starting point
- Fair scenario comparison

### When NOT to Use

❌ **Avoid During**:
- Active simulation running (pause first)
- Critical system analysis (may affect results)
- When studying gradual charging/discharging
- When testing time-based behavior

---

## 🚀 Advanced Workflows

### Workflow 1: Battery Sizing Study

**Objective**: Determine optimal battery capacity

**Steps**:
1. Start with "🔄 Reset All" (50% SOC baseline)
2. Set baseline
3. Try different battery capacities
4. For each capacity:
   - Click "🔋 Charge All" (start full)
   - Run 24-hour simulation
   - Record min SOC, grid health, losses
   - Click "🔄 Reset All" (reset for next test)
5. Compare results
6. Select optimal capacity

**Result**: Data-driven battery sizing decision

---

### Workflow 2: Renewable Integration Study

**Objective**: Assess impact of high solar penetration

**Steps**:
1. Increase solar capacity
2. Click "🗑️ Clear All" (empty batteries)
3. Run simulation at noon (high solar)
4. Observe battery charging from excess solar
5. Click "🔋 Charge All" (ensure full)
6. Run simulation at evening (no solar)
7. Observe battery discharging to support load
8. Compare with/without battery scenarios

**Result**: Understand battery role in renewable integration

---

### Workflow 3: Grid Resilience Testing

**Objective**: Test grid behavior during battery outage

**Steps**:
1. Set batteries to "Grid Support" mode
2. Click "🔋 Charge All" (full capacity)
3. Apply "Peak Summer Load" scenario
4. Observe battery support
5. Click "🗑️ Clear All" (simulate battery failure)
6. Observe grid response:
   - Voltage drops
   - Grid import increases
   - Losses increase
   - Grid health decreases
7. Document resilience metrics

**Result**: Quantify battery importance for grid resilience

---

## 📝 Summary

The **Battery Clear/Reset Feature** provides:

✅ **Instant State Changes** - No waiting for gradual charging/discharging  
✅ **Individual Control** - Configure each battery independently  
✅ **Global Control** - Reset all batteries at once  
✅ **Scenario Testing** - Quickly set up different conditions  
✅ **Emergency Simulation** - Test battery failure scenarios  
✅ **Baseline Management** - Return to known states  
✅ **What-If Analysis** - Compare different SOC levels  
✅ **BITS Mode Integration** - Works seamlessly with safety features  

**Total Quick Actions**: 6 buttons (3 individual + 3 global)  
**Response Time**: <100ms for instant updates  
**Use Cases**: Unlimited scenario testing possibilities  

---

**GRIDPULSE** - *Complete Battery Control for Professional Grid Analysis*
